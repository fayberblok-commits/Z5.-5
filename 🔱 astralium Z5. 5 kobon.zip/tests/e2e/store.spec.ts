import { test, expect } from '@playwright/test';
const viewports = [{width:320,height:568},{width:375,height:667},{width:768,height:1024},{width:1024,height:768},{width:1280,height:800},{width:1440,height:900},{width:1920,height:1080}];
for (const vp of viewports){
  test(`store home ${vp.width}x${vp.height}`, async ({ page }) => {
    await page.setViewportSize(vp);
    await page.goto('http://localhost:8000/pages/home.html');
    await expect(page.locator('h1')).toContainText('Astralium');
    await expect(page.getByRole('button', { name: 'تصفح' })).toBeVisible();
    // no horizontal overflow at this viewport
    const overflow = await page.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth);
    expect(overflow).toBeLessThanOrEqual(1);
  });
}
test('cart flow + live region', async ({ page }) => {
  await page.goto('http://localhost:8000/pages/home.html');
  await expect(page.locator('#cartCount')).toHaveText('0');
  await page.getByRole('button', { name: 'أضف للسلة' }).first().click();
  await expect(page.locator('#cartCount')).toHaveText('1');
  await page.getByRole('button', { name: 'أضف للسلة' }).nth(1).click();
  await expect(page.locator('#cartCount')).toHaveText('2');
  await expect(page.locator('#cartStatus')).toHaveAttribute('aria-label', /2/);
});
test('all 17 pages render with h1', async ({ page }) => {
  const pages = ['home-full','catalog-full','category-full','product-full','cart-full','checkout-full','thankyou-full','account-full','login-full','about-full','contact-full','faq-full','blog-full','landing-full','404-full','maintenance-full','track-full'];
  for (const p of pages) {
    await page.goto(`http://localhost:8000/pages/${p}.html`);
    await expect(page.locator('h1')).toBeVisible();
  }
});
