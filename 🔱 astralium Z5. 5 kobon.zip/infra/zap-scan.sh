#!/bin/bash
# DAST OWASP ZAP على كل الواجهات بعد كل مرحلة
docker run --network host zaproxy/zap-stable zap-baseline.py -t http://localhost:8000 -r zap-report.html || true
echo "ZAP done — review zap-report.html"
