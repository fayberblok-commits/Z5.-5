// K6 — حمل حقيقي قصير على الواجهة الحيّة (نسخة قابلة للتشغيل هنا؛ نسخة الساعة في k6-load.js).
// التشغيل: k6 run -e BASE=http://127.0.0.1:8200 infra/k6-smoke.js
import http from 'k6/http';
import { check, sleep } from 'k6';

const BASE = __ENV.BASE || 'http://127.0.0.1:8200';

export const options = {
  scenarios: {
    steady: {
      executor: 'constant-vus',
      vus: Number(__ENV.VUS || 20),
      duration: __ENV.DURATION || '20s',
    },
  },
  thresholds: {
    http_req_failed: ['rate<0.01'],
    http_req_duration: ['p(95)<500', 'p(99)<1000'],
  },
  summaryTrendStats: ['avg', 'min', 'med', 'p(90)', 'p(95)', 'p(99)', 'max'],
};

export default function () {
  const r = http.get(`${BASE}/health`, { tags: { name: 'health' } });
  check(r, { 'health 200': (res) => res.status === 200 });
  const root = http.get(`${BASE}/`, { tags: { name: 'storefront' } });
  check(root, { 'storefront 200': (res) => res.status === 200 });
  sleep(0.2);
}
