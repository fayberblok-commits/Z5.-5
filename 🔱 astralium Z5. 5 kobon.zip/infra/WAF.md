> **تنبيه مراجعة 2026-10-20:** هذا وصف تصميم/عرض سابق، وليس دليل تنفيذ إنتاجي. المرجع الحاكم للميزات والجاهزية هو FINAL-QA-REPORT.md وARCHITECTURE.md. ادعاءات اكتمال أو عزل أو امتثال هنا غير معتمدة ما لم يسندها تقرير الجولة الحالية.

# WAF — ModSecurity + OWASP CRS + CrowdSec
- Paranoia 1, Anomaly inbound 5
- Rules: SQLi, XSS, RCE, LFI, SSRF
- CrowdSec bouncer for IP reputation
- Logs to Loki, alerts to admin
