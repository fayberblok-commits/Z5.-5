import http from 'k6/http'; import { sleep, check } from 'k6';
export let options = { stages: [{duration:'10m', target:50},{duration:'40m', target:50},{duration:'10m', target:0}], thresholds:{http_req_failed:['rate<0.01']} };
export default function(){ let r=http.get('http://web:8000/health'); check(r,{'200':(r)=>r.status===200}); sleep(1); }
