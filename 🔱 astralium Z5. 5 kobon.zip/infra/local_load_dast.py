"""حمل + DAST مصغّر محلي (ليس بديلاً عن k6 ساعة وZAP كامل).

يشغّل: حمل متزامن على /health و/orders، ثم فحوصات DAST سلبية/إيجابية.
"""
from __future__ import annotations

import json
import statistics
import threading
import time
import urllib.error
import urllib.request

BASE = "http://localhost:8002"
DURATION = 45
WORKERS = 50
results: list[float] = []
errors: list[int] = []
lock = threading.Lock()


def call(path: str, data: dict | None = None, headers: dict | None = None) -> tuple[int, float, dict]:
    body = json.dumps(data).encode() if data is not None else None
    h = {"content-type": "application/json"} if data is not None else {}
    h.update(headers or {})
    req = urllib.request.Request(BASE + path, data=body, headers=h, method="POST" if data is not None else "GET")
    t0 = time.perf_counter()
    try:
        with urllib.request.urlopen(req, timeout=10) as r:
            r.read()
            return r.status, (time.perf_counter() - t0) * 1000, dict(r.headers)
    except urllib.error.HTTPError as e:
        e.read()
        return e.code, (time.perf_counter() - t0) * 1000, dict(e.headers or {})


def worker(stop_at: float) -> None:
    n = 0
    while time.perf_counter() < stop_at:
        if n % 5 == 0:
            code, ms, _ = call("/orders", {"store_id": "s1", "amount_cents": 2000})
        else:
            code, ms, _ = call("/health")
        with lock:
            results.append(ms)
            if code >= 400:
                errors.append(code)
        n += 1


def load_test() -> dict:
    start = time.perf_counter()
    stop_at = start + DURATION
    threads = [threading.Thread(target=worker, args=(stop_at,)) for _ in range(WORKERS)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()
    elapsed = time.perf_counter() - start
    s = sorted(results)
    pct = lambda p: s[min(len(s) - 1, int(len(s) * p))]  # noqa: E731
    return {
        "duration_s": round(elapsed, 1),
        "workers": WORKERS,
        "requests": len(results),
        "rps": round(len(results) / elapsed, 1),
        "errors": len(errors),
        "error_rate_pct": round(100 * len(errors) / max(1, len(results)), 3),
        "p50_ms": round(statistics.median(s), 2),
        "p95_ms": round(pct(0.95), 2),
        "p99_ms": round(pct(0.99), 2),
        "max_ms": round(max(s), 2),
    }


def dast() -> list[dict]:
    checks: list[dict] = []

    def add(name: str, ok: bool, detail: str) -> None:
        checks.append({"check": name, "pass": ok, "detail": detail})

    code, _, h = call("/health")
    hdr = {k.lower(): v for k, v in h.items()}
    add("HSTS", "max-age=" in hdr.get("strict-transport-security", ""), hdr.get("strict-transport-security", "missing"))
    add("CSP", "default-src" in hdr.get("content-security-policy", ""), hdr.get("content-security-policy", "missing")[:60])
    add("X-Frame-Options", hdr.get("x-frame-options") == "DENY", hdr.get("x-frame-options", "missing"))
    add("nosniff", hdr.get("x-content-type-options") == "nosniff", "ok")
    add("no-store", "no-store" in hdr.get("cache-control", ""), hdr.get("cache-control", "missing"))
    add("COOP/CORP", "cross-origin-opener-policy" in hdr and "cross-origin-resource-policy" in hdr, "present")

    code, _, _ = call("/admin/overview")
    add("admin بدون مصادقة → 401", code == 401, f"status={code}")

    code, _, _ = call("/orders", {"store_id": "s1", "amount_cents": -500})
    add("مبلغ سالب مرفوض", code == 422, f"status={code}")

    code, _, _ = call("/orders", {"store_id": "s1", "amount_cents": 2000, "coupon_cents": 99999})
    add("كوبون > المبلغ مرفوض", code == 422, f"status={code}")

    code, _, _ = call("/orders", {"store_id": "s1'; DROP TABLE orders;--", "amount_cents": 100})
    add("حقن SQL في store_id لا ينفّذ", code in (200, 422), f"status={code}")

    code, _, _ = call("/files/verify?bucket=../etc&key=passwd&buyer=x&exp=1&sig=bad")
    add("path traversal في bucket", code in (400, 422, 403), f"status={code}")

    code, _, _ = call("/no-such-route")
    add("مسار غير موجود → 404", code == 404, f"status={code}")

    req = urllib.request.Request(BASE + "/health", method="TRACE")
    try:
        with urllib.request.urlopen(req, timeout=5) as r:
            trace_code = r.status
    except urllib.error.HTTPError as e:
        trace_code = e.code
    except Exception:
        trace_code = 0
    add("TRACE مرفوض", trace_code >= 400, f"status={trace_code}")

    code, _, _ = call("/orders", {"store_id": "s1", "amount_cents": 2**63})
    add("تجاوز عدد صحيح مرفوض", code == 422, f"status={code}")

    return checks


if __name__ == "__main__":
    d = dast()
    print("=== DAST ===")
    for c in d:
        print(("PASS" if c["pass"] else "FAIL"), "|", c["check"], "|", c["detail"])
    print(f"\nDAST: {sum(c['pass'] for c in d)}/{len(d)} ناجح")
    print("\n=== LOAD ===")
    out = load_test()
    print(json.dumps(out, ensure_ascii=False, indent=2))
    json.dump({"dast": d, "load": out}, open("/home/user/load-dast-results.json", "w"), ensure_ascii=False, indent=2)
