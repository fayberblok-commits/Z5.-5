"""Astralium Fibonix Z5.5 — تطبيق FastAPI الموحّد (fail-closed).

كل المسارات المالية تعمل على PostgreSQL حقيقي مع RLS، وكل مسار محمي يتحقق من
الجلسة والصلاحية قبل أي عمل. أي خطأ متوقع يُترجم إلى 4xx صريح، ولا تُسرَّب
تفاصيل داخلية في الاستجابة.
"""

from __future__ import annotations

import hmac
import uuid
import os
import secrets
from contextlib import asynccontextmanager
from typing import Annotated, Any

from fastapi import FastAPI, Header, HTTPException, Request, Response
from fastapi.responses import HTMLResponse, JSONResponse
from pydantic import BaseModel, Field, model_validator

from .core.audit import audit_append, verify_chain
from .core.config import ConfigError, get_settings
from .core.db import Conn, atomic, one, ping, raw
from .core.http_body import read_limited_body
from .core.permissions import enforce
from .core.rate_limit import limiter
from .modules.auth import service as auth
from .modules.auth.service import AuthError
from .modules.files import secure_upload as up
from .modules.files.secure_upload import ScanUnavailable, StorageUnavailable, UploadRejected
from .modules.ledger import repository as ledger_repo
from .modules.payments import service as pay
from .modules.payments.stripe_connect import StripeConnectClient, StripeError
from .modules.payments.service import PaymentError

MAX_ORDER_CENTS = 100_000_000  # 1,000,000.00 عملة


# ---------------------------------------------------------------- lifespan
@asynccontextmanager
async def lifespan(app: FastAPI):
    """يفشل الإقلاع فورًا إذا كانت الإعدادات ناقصة أو القاعدة/Redis غير متاحة."""
    get_settings()
    if not ping():
        raise ConfigError("database unreachable at startup")
    limiter.assert_ready()
    yield


app = FastAPI(title="Astralium Fibonix", version="5.5.0", lifespan=lifespan,
              docs_url=None, redoc_url=None, openapi_url=None)


# ---------------------------------------------------------------- middleware
@app.middleware("http")
async def security_middleware(request: Request, call_next):
    settings = get_settings()
    client_ip = request.client.host if request.client else "unknown"
    if not limiter.allow(f"{client_ip}:{request.url.path}", settings.rate_limit_per_min, 60):
        return JSONResponse(status_code=429, content={"detail": "rate limit exceeded"})
    response = await call_next(request)
    # إخفاء بصمات إضافية قد تضيفها طبقات أخرى (uvicorn نفسه يُخفى عبر --no-server-header)
    for fingerprint in ("x-powered-by",):
        if fingerprint in response.headers:
            del response.headers[fingerprint]
    response.headers["Strict-Transport-Security"] = "max-age=63072000; includeSubDomains; preload"
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
    response.headers["Permissions-Policy"] = "camera=(), microphone=(), geolocation=()"
    response.headers["Cross-Origin-Opener-Policy"] = "same-origin"
    response.headers["Cross-Origin-Resource-Policy"] = "same-origin"
    response.headers["Cache-Control"] = "no-store"
    response.headers["Content-Security-Policy"] = (
        "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; "
        "object-src 'none'; base-uri 'none'; frame-ancestors 'none'; form-action 'self'"
    )
    return response


# ---------------------------------------------------------------- error mapping
@app.exception_handler(AuthError)
async def _auth_error(_: Request, exc: AuthError):
    return JSONResponse(status_code=exc.status, content={"detail": str(exc)})


@app.exception_handler(PermissionError)
async def _permission_error(_: Request, exc: PermissionError):
    return JSONResponse(status_code=403, content={"detail": str(exc)})


@app.exception_handler(PaymentError)
async def _payment_error(_: Request, exc: PaymentError):
    return JSONResponse(status_code=400, content={"detail": str(exc)})


@app.exception_handler(UploadRejected)
async def _upload_error(_: Request, exc: UploadRejected):
    return JSONResponse(status_code=400, content={"detail": str(exc)})


@app.exception_handler(StorageUnavailable)
async def _storage_error(_: Request, exc: StorageUnavailable):
    return JSONResponse(status_code=503, content={"detail": "file storage unavailable"})


@app.exception_handler(ScanUnavailable)
async def _scan_error(_: Request, exc: ScanUnavailable):
    # fail-closed: لا نسمح بملف غير مفحوص
    return JSONResponse(status_code=503, content={"detail": "file scanning unavailable"})


@app.exception_handler(StripeError)
async def _stripe_error(_: Request, exc: StripeError):
    return JSONResponse(status_code=502, content={"detail": "payment provider error"})


@app.exception_handler(ConfigError)
async def _config_error(_: Request, exc: ConfigError):
    return JSONResponse(status_code=503, content={"detail": "service misconfigured"})


# ---------------------------------------------------------------- helpers
def _client_fp(request: Request) -> tuple[str, str, str]:
    return (
        request.headers.get("user-agent", ""),
        request.headers.get("accept-language", ""),
        request.headers.get("x-device-hint", ""),
    )


def _csrf_ok(request: Request, session_token: str | None) -> None:
    """حماية CSRF مزدوجة للطلبات المتغيرة القائمة على الكوكي."""
    if request.method in ("GET", "HEAD", "OPTIONS"):
        return
    header_token = request.headers.get("x-csrf-token")
    cookie_token = request.cookies.get("__Host-csrf")
    if not header_token or not cookie_token or not hmac.compare_digest(header_token, cookie_token):
        raise AuthError("csrf token missing or invalid", status=403)


def current_session(request: Request, conn: Conn, *, rotate: bool = False) -> dict:
    """الجلسة من كوكي __Host-session (مع CSRF) أو من Bearer.

    Bearer يقبل نوعين:
      * توكن جلسة عشوائي (له جلسة في قاعدة البيانات ⇒ يدعم step-up/التدوير)
      * JWT وصول قصير العمر (للـ API؛ لا يدعم step-up لأنه بلا جلسة)
    """
    authz = request.headers.get("authorization", "")
    if authz.startswith("Bearer "):
        token = authz[7:]
        if token.count(".") == 2:  # JWT
            payload = auth.decode_access_token(conn, token)
            account = conn.execute(
                "SELECT id, email, role, store_id FROM accounts WHERE id=%s", (payload["sub"],)
            ).fetchone()
            if not account:
                raise AuthError("unknown account")
            return {
                "session_id": None,
                "account_id": str(account["id"]),
                "email": account["email"],
                "role": account["role"],
                "store_id": str(account["store_id"]) if account["store_id"] else None,
                "via": "jwt",
            }
        token = token
    else:
        cookie_token = request.cookies.get("__Host-session")
        if not cookie_token:
            raise AuthError("authentication required")
        _csrf_ok(request, cookie_token)
        token = cookie_token

    ua, al, hint = _client_fp(request)
    session = auth.resolve_session(conn, token=token, user_agent=ua, accept_language=al,
                                   client_hint=hint, rotate=rotate)
    session["via"] = "cookie"
    return session


def require_role(session: dict, *roles: str) -> None:
    if session["role"] not in roles:
        raise PermissionError(f"role {session['role']} not permitted")


def _session_dep(request: Request) -> Any:
    """Depends: يفتح معاملة واحدة لكل طلب ويُمرّر الجلسة."""
    with atomic() as conn:
        yield conn, current_session(request, conn)


# ---------------------------------------------------------------- models
class RegisterIn(BaseModel):
    email: str = Field(min_length=3, max_length=254)
    password: str = Field(min_length=12, max_length=256)
    store_name: str = Field(default="My Store", max_length=120)


class LoginIn(BaseModel):
    email: str = Field(min_length=3, max_length=254)
    password: str = Field(min_length=1, max_length=256)
    totp_code: str | None = Field(default=None, max_length=8)


class OrderIn(BaseModel):
    store_id: uuid.UUID
    amount_cents: int = Field(ge=0, le=MAX_ORDER_CENTS)
    currency: str = Field(default="USD", pattern=r"^[A-Z]{3}$")
    coupon_cents: int = Field(default=0, ge=0, le=MAX_ORDER_CENTS)
    buyer_email: str | None = Field(default=None, max_length=254)

    @model_validator(mode="after")
    def _coupon(self):
        if self.coupon_cents > self.amount_cents:
            raise ValueError("coupon cannot exceed amount")
        return self


class ProductIn(BaseModel):
    title: str = Field(min_length=1, max_length=200)
    price_minor: int = Field(ge=0, le=MAX_ORDER_CENTS)
    currency: str = Field(default="USD", pattern=r"^[A-Z]{3}$")


# ---------------------------------------------------------------- public
@app.get("/health")
def health():
    return {"status": "ok" if ping() else "degraded", "version": "5.5.0"}


@app.get("/", response_class=HTMLResponse)
def storefront():
    return """<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width"><title>Astralium Fibonix — متجر فاخر</title>
<style>body{margin:0;font-family:system-ui;background:#0a0a0f;color:#f5f0e6}
header{padding:24px;background:linear-gradient(135deg,#1a1a2e,#d4af37);color:#fff}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:16px;padding:24px}
.card{background:#16162a;border-radius:16px;padding:16px;border:1px solid #d4af3733}</style></head>
<body><header><h1>Astralium Fibonix Z5.5</h1><p>منصة مجانية للتجار — عمولة 2$ ثابتة</p></header>
<div class="grid"><div class="card"><h3>كتاب رقمي — أسرار الفلك</h3><p>29$ — تحميل آمن بروابط موقّعة</p></div>
<div class="card"><h3>دورة تصميم</h3><p>49$ — وصول فوري</p></div>
<div class="card"><h3>عطر فاخر</h3><p>89$ — شحن عالمي</p></div></div>
<footer style="padding:24px;text-align:center;opacity:.7">© 2026 Astralium Fibonix — Z5.5</footer></body></html>"""


# ---------------------------------------------------------------- auth
@app.post("/auth/register")
def register(data: RegisterIn):
    with atomic() as conn:
        return auth.register(conn, email=data.email, password=data.password, store_name=data.store_name)


@app.post("/auth/login")
def login(data: LoginIn, request: Request, response: Response):
    """تسجيل الدخول: عدّاد المحاولات يُثبَّت حتى عند الفشل (منع القفل غير الفعّال)."""
    ua, al, hint = _client_fp(request)
    with raw() as conn:
        try:
            result = auth.login(conn, email=data.email, password=data.password, user_agent=ua,
                                accept_language=al, client_hint=hint, totp_code=data.totp_code)
            token = auth.issue_access_token(conn, account_id=result["account_id"], role=result["role"],
                                            store_id=result["store_id"])
            conn.commit()
        except AuthError:
            conn.commit()  # نُثبّت failed_logins/locked_until والتدقيق قبل رفض الطلب
            raise
        except Exception:
            conn.rollback()
            raise
    csrf = secrets.token_urlsafe(24)
    response.set_cookie("__Host-session", result["session_token"], httponly=True, secure=True,
                        samesite="strict", path="/", max_age=get_settings().session_ttl_minutes * 60)
    response.set_cookie("__Host-csrf", csrf, httponly=False, secure=True, samesite="strict",
                        path="/", max_age=get_settings().session_ttl_minutes * 60)
    return {"role": result["role"], "store_id": result["store_id"], "csrf_token": csrf, **token}


@app.post("/auth/logout")
def logout(request: Request):
    """يُبطل كل ما يحمله الطلب: صف الجلسة (كوكي) و/أو الـ JWT."""
    revoked = {"session": False, "jwt": False}
    with atomic() as conn:
        authz = request.headers.get("authorization", "")
        if authz.startswith("Bearer ") and authz[7:].count(".") == 2:
            payload = auth.decode_access_token(conn, authz[7:])
            auth.revoke_jti(conn, payload["jti"], int(payload["exp"]))
            revoked["jwt"] = True
        cookie_token = request.cookies.get("__Host-session")
        if cookie_token:
            _csrf_ok(request, cookie_token)
            try:
                s = auth.resolve_session(conn, token=cookie_token, user_agent=request.headers.get("user-agent", ""),
                                         accept_language=request.headers.get("accept-language", ""),
                                         client_hint=request.headers.get("x-device-hint", ""))
                auth.revoke_session(conn, s["session_id"])
                revoked["session"] = True
            except AuthError:
                pass
        if not revoked["jwt"] and not revoked["session"]:
            raise AuthError("authentication required")
    return {"status": "logged_out", **revoked}


@app.post("/auth/logout-all")
def logout_all(request: Request):
    with atomic() as conn:
        s = current_session(request, conn)
        n = auth.revoke_all_sessions(conn, s["account_id"])
    return {"revoked_sessions": n}


@app.post("/auth/totp/enroll")
def totp_enroll(request: Request):
    with atomic() as conn:
        s = current_session(request, conn)
        data = auth.enroll_totp(conn, s["account_id"], s["email"])
    return data


@app.post("/auth/totp/confirm")
def totp_confirm(request: Request, code: str):
    with atomic() as conn:
        s = current_session(request, conn)
        auth.confirm_totp(conn, s["account_id"], code)
    return {"status": "confirmed"}


@app.get("/me")
def me(request: Request):
    with atomic() as conn:
        s = current_session(request, conn)
    return {"email": s["email"], "role": s["role"], "store_id": s["store_id"]}


# ---------------------------------------------------------------- products
@app.post("/stores/{store_id}/products")
def create_product(store_id: str, data: ProductIn, request: Request):
    with atomic() as conn:
        s = current_session(request, conn)
        require_role(s, "merchant", "merchant_staff", "owner")
        if s["store_id"] != store_id and s["role"] != "owner":
            raise PermissionError("cross-store write denied")
        conn.execute("SELECT set_config('app.store_id', %s, true)", (store_id,))
        enforce(s["role"], "product", "create")
        row = one(
            conn.execute(
                """INSERT INTO products (store_id, title, price_minor, currency)
                   VALUES (%s,%s,%s,%s) RETURNING id, title, price_minor, currency""",
                (store_id, data.title, data.price_minor, data.currency),
            ).fetchone(),
            context="created product",
        )
        audit_append(conn, actor=s["email"], action="product_created", resource=f"product:{row['id']}",
                     store_id=store_id, meta={"price_minor": data.price_minor})
    return dict(row)


@app.get("/stores/{store_id}/products")
def list_products(store_id: str, request: Request):
    with atomic() as conn:
        s = current_session(request, conn)
        if s["store_id"] != store_id and s["role"] != "owner":
            raise PermissionError("cross-store read denied (RLS)")
        enforce(s["role"], "product", "list")
        conn.execute("SELECT set_config('app.store_id', %s, true)", (store_id,))
        rows = conn.execute(
            "SELECT id, title, price_minor, currency FROM products WHERE store_id=%s ORDER BY created_at DESC",
            (store_id,),
        ).fetchall()
    return {"store_id": store_id, "products": rows}


# ---------------------------------------------------------------- orders
@app.post("/orders")
def create_order(data: OrderIn, request: Request, idempotency_key: Annotated[str | None, Header()] = None):
    with atomic() as conn:
        s = current_session(request, conn)
        store_id = str(data.store_id)
        if s["store_id"] != store_id and s["role"] not in ("owner",):
            raise PermissionError("orders can only be created for your own store")
        conn.execute("SELECT set_config('app.store_id', %s, true)", (store_id,))
        key = idempotency_key or f"auto-{secrets.token_hex(12)}"
        buyer = data.buyer_email or s["email"]

        def _create(c: Conn) -> dict:
            existing = c.execute(
                "SELECT id, status, amount_minor, coupon_minor FROM orders WHERE store_id=%s AND idempotency_key=%s",
                (store_id, key),
            ).fetchone()
            if existing:
                return {"order_id": str(existing["id"]), "status": existing["status"], "reused": True,
                        "net_minor": existing["amount_minor"] - existing["coupon_minor"]}
            row = one(
                c.execute(
                    """INSERT INTO orders (store_id, buyer_email, amount_minor, coupon_minor, currency, idempotency_key)
                       VALUES (%s,%s,%s,%s,%s,%s) RETURNING id""",
                    (store_id, buyer, data.amount_cents, data.coupon_cents, data.currency, key),
                ).fetchone(),
                context="created order",
            )
            net = data.amount_cents - data.coupon_cents
            audit_append(c, actor=s["email"], action="order_created", resource=f"order:{row['id']}",
                         store_id=store_id, meta={"gross": data.amount_cents, "net": net})
            return {"order_id": str(row["id"]), "status": "pending", "net_minor": net}

        result = pay.idempotent(conn, f"order:{store_id}", key, data.model_dump(mode="json"), _create)

    if result["net_minor"] == 0:
        return {**result, "platform_fee_minor": 0, "merchant_minor": 0, "note": "free order — no payment needed"}
    fee = min(get_settings().platform_fee_minor, result["net_minor"])
    return {**result, "platform_fee_minor": fee, "merchant_minor": result["net_minor"] - fee}


@app.post("/orders/{order_id}/pay")
def pay_order(order_id: str, request: Request):
    settings = get_settings()
    with atomic() as conn:
        s = current_session(request, conn)
        # سياق المتجر أولًا حتى تعمل RLS، ثم نتحقق أن الطلب يخص هذا المتجر
        if not s["store_id"]:
            raise PermissionError("no store bound to session")
        conn.execute("SELECT set_config('app.store_id', %s, true)", (s["store_id"],))
        order = conn.execute(
            "SELECT store_id, amount_minor, coupon_minor, currency, buyer_email FROM orders WHERE id=%s",
            (order_id,),
        ).fetchone()
        if not order:
            raise HTTPException(404, "order not found")
        store_id = str(order["store_id"])
        if s["store_id"] != store_id and s["role"] != "owner":
            raise PermissionError("cross-store access denied")

    client = StripeConnectClient(settings.stripe_secret_key.get_secret_value(),
                                 transport=_stripe_transport())
    return pay.start_payment(
        client=client,
        store_id=store_id,
        order_id=order_id,
        amount_minor=int(order["amount_minor"]) - int(order["coupon_minor"]),
        currency=order["currency"],
        buyer_email=order["buyer_email"],
    )


def _stripe_transport():
    """MockTransport is explicitly restricted to APP_ENV=test."""
    if os.environ.get("STRIPE_MOCK_TRANSPORT") == "1":
        if get_settings().app_env != "test":
            raise ConfigError("mock payments forbidden outside test")
        from .modules.payments.mock_transport import mock_transport

        return mock_transport()
    return None


@app.post("/stores/{store_id}/payments/onboard")
def onboard_merchant(store_id: str, request: Request, provider_account_id: str, country: str = "US"):
    """ربط حساب Stripe Connect للتاجر (يأتي من OAuth لدى Stripe في الإنتاج)."""
    if not provider_account_id.startswith("acct_"):
        raise HTTPException(422, "provider_account_id must be a Stripe connected account (acct_...)")
    if len(country) != 2 or not country.isalpha():
        raise HTTPException(422, "country must be ISO-3166 alpha-2")
    with atomic() as conn:
        s = current_session(request, conn)
        require_role(s, "merchant", "owner")
        if s["store_id"] != store_id and s["role"] != "owner":
            raise PermissionError("cross-store access denied")
        conn.execute("SELECT set_config('app.store_id', %s, true)", (store_id,))
        pay.ensure_merchant_account(conn, store_id, provider_account_id, country.upper())
        audit_append(conn, actor=s["email"], action="merchant_onboarded", resource=f"store:{store_id}",
                     store_id=store_id, meta={"provider": "stripe"})
    return {"status": "connected", "store_id": store_id}


# ---------------------------------------------------------------- webhooks
@app.post("/webhooks/stripe")
async def stripe_webhook(request: Request, stripe_signature: Annotated[str | None, Header()] = None):
    settings = get_settings()
    if not stripe_signature:
        raise HTTPException(400, "missing signature")
    body = await read_limited_body(request, max_bytes=1024 * 1024)
    client = StripeConnectClient(settings.stripe_secret_key.get_secret_value(), transport=_stripe_transport())
    return pay.process_webhook(
        client=client,
        raw_body=body,
        signature_header=stripe_signature,
        webhook_secret=settings.stripe_webhook_secret.get_secret_value(),
    )


# ---------------------------------------------------------------- files
@app.post("/files/upload")
async def upload_file(request: Request, x_filename: Annotated[str, Header()] = "upload.bin"):
    """رفع ملف: يتطلب جلسة، ويُرفض إن لم يكن الفحص متاحًا (fail-closed)."""
    settings = get_settings()
    # Authenticate before consuming an attacker-controlled stream. Close this
    # transaction before waiting on the network, then recheck after the upload.
    with atomic() as conn:
        initial = current_session(request, conn)
        require_role(initial, "merchant", "merchant_staff", "owner")
        if not initial["store_id"]:
            raise PermissionError("no store bound to session")
    body = await read_limited_body(request, max_bytes=settings.max_upload_bytes)

    with atomic() as conn:
        s = current_session(request, conn)
        require_role(s, "merchant", "merchant_staff", "owner")
        if not s["store_id"]:
            raise PermissionError("no store bound to session")
        conn.execute("SELECT set_config('app.store_id', %s, true)", (s["store_id"],))
        stored = up.store_object(store_id=s["store_id"], order_id=None, content=body, filename=x_filename)
        record = up.register_file(conn, store_id=s["store_id"], file=stored)
        audit_append(conn, actor=s["email"], action="file_uploaded", resource=f"file:{record['file_id']}",
                     store_id=s["store_id"], meta={"size": stored["size"], "sha256": stored["sha256"]})
    return record


@app.post("/files/{file_id}/download-url")
def download_url(file_id: str, request: Request, buyer_id: str | None = None):
    with atomic() as conn:
        s = current_session(request, conn)
        if not s["store_id"]:
            raise PermissionError("no store bound to session")
        conn.execute("SELECT set_config('app.store_id', %s, true)", (s["store_id"],))
        target_buyer = buyer_id or s["email"]
        return up.create_download_url(conn, file_id=file_id, store_id=s["store_id"], buyer_id=target_buyer)


@app.post("/files/download/{jti}")
def consume_download(jti: str, request: Request):
    with atomic() as conn:
        s = current_session(request, conn)
        conn.execute("SELECT set_config('app.store_id', %s, true)", (s["store_id"],))
        file = up.consume_download(conn, jti=jti, buyer_id=s["email"], store_id=s["store_id"])
        # Fetch within the transaction: an object-store failure rolls back redemption.
        # Read is bounded to the configured limit to avoid unbounded memory use.
        content = up.read_private_object(file["object_key"])
    return Response(content=content, media_type=file["content_type"],
                    headers={"Content-Disposition": "attachment", "Cache-Control": "no-store"})


# ---------------------------------------------------------------- ledger / settlement / admin
@app.get("/stores/{store_id}/ledger/verify")
def ledger_verify(store_id: str, request: Request):
    with atomic() as conn:
        s = current_session(request, conn)
        if s["store_id"] != store_id and s["role"] != "owner":
            raise PermissionError("cross-store ledger access denied")
        enforce(s["role"], "ledger", "read")
    return ledger_repo.verify_balanced(store_id)


@app.get("/stores/{store_id}/settlements")
def settlements(store_id: str, request: Request):
    with atomic() as conn:
        s = current_session(request, conn)
        if s["store_id"] != store_id and s["role"] != "owner":
            raise PermissionError("cross-store settlement access denied")
        enforce(s["role"], "order", "read")
    return pay.settlement_summary(store_id)


@app.get("/admin/overview")
def admin_overview(request: Request):
    settings = get_settings()
    ip = request.client.host if request.client else ""
    if ip not in settings.allowed_admin_ips():
        raise PermissionError("admin IP not allowed")
    with atomic() as conn:
        s = current_session(request, conn)
        require_role(s, "owner")
        if not s.get("session_id"):
            raise AuthError("admin access requires an interactive session (cookie)", status=403)
        auth.require_step_up(conn, s["session_id"])
        row = one(
            conn.execute(
                """SELECT (SELECT COUNT(*) FROM stores) AS stores,
                          (SELECT COUNT(*) FROM orders) AS orders,
                          (SELECT COALESCE(SUM(amount_minor),0) FROM platform_fees WHERE status='paid') AS fees_paid"""
            ).fetchone(),
            context="admin overview",
        )
    return dict(row)


@app.get("/admin/audit/verify")
def audit_verify(request: Request):
    settings = get_settings()
    ip = request.client.host if request.client else ""
    if ip not in settings.allowed_admin_ips():
        raise PermissionError("admin IP not allowed")
    with atomic() as conn:
        s = current_session(request, conn)
        require_role(s, "owner")
        return verify_chain(conn)


@app.post("/admin/step-up")
def step_up(request: Request, code: str):
    """إعادة تحقق TOTP لعمليات حساسة — تتطلب جلسة تفاعلية (كوكي) لا JWT."""
    with atomic() as conn:
        s = current_session(request, conn)
        require_role(s, "owner")
        if not s.get("session_id"):
            raise AuthError("step-up requires an interactive session (cookie)", status=403)
        row = conn.execute("SELECT totp_secret_enc FROM accounts WHERE id=%s", (s["account_id"],)).fetchone()
        if not row or not row["totp_secret_enc"]:
            raise AuthError("totp required for step-up", status=403)
        if not auth.verify_totp(row["totp_secret_enc"], code, s["account_id"]):
            raise AuthError("invalid totp", status=401)
        auth.mark_step_up(conn, s["session_id"])
    return {"status": "step_up_ok"}


if __name__ == "__main__":  # pragma: no cover
    import uvicorn

    uvicorn.run(app, host="0.0.0.0", port=8000)  # nosec B104  # noqa: S104 — داخل حاوية، لا واجهة عامة مباشرة
