"""تنسيق المدفوعات والتسويات — كل الأرقام minor units، وكل انتقال حالة موثّق.

الحالات (platform_fees / payments / transfers):
    pending → processing → paid
                    ↘ failed ↘ refunded ↘ disputed

قاعدة ذهبية: لا تصبح العمولة `paid` إلا بعد تأكيد موقّع من المزود
(`transfer.paid` / استعلام حالة موثّق). `create_transfer` ناجح يعني `processing` فقط.
"""

from __future__ import annotations

import hashlib
import json
from datetime import date, datetime, timezone
from typing import Any


from ...core.audit import audit_append
from ...core.db import Conn, atomic
from ...core.db import one
from ..ledger.repository import post_group, post_refund, post_sale
from .stripe_connect import StripeConnectClient, StripeError, verify_webhook


class PaymentError(RuntimeError):
    pass


# ---------------------------------------------------------------- idempotency
def _hash_request(payload: dict) -> str:
    return hashlib.sha256(json.dumps(payload, sort_keys=True, default=str).encode()).hexdigest()


def idempotent(conn: Conn, scope: str, key: str, payload: dict, fn):
    """ينفّذ fn مرة واحدة لكل (scope,key) داخل معاملة المستدعي (ذرّية مع العملية)."""
    req_hash = _hash_request(payload)
    row = conn.execute(
        "SELECT scope, request_hash, response FROM idempotency_keys WHERE key=%s FOR UPDATE", (key,)
    ).fetchone()
    if row:
        if row["scope"] != scope or row["request_hash"] != req_hash:
            raise PaymentError("idempotency key reused with different payload")
        return row["response"]
    result = fn(conn)
    conn.execute(
        "INSERT INTO idempotency_keys (key, scope, request_hash, response) VALUES (%s,%s,%s,%s)",
        (key, scope, req_hash, json.dumps(result, default=str)),
    )
    return result


# ---------------------------------------------------------------- مستخدمون
def ensure_merchant_account(conn: Conn, store_id: str, provider_account_id: str, country: str) -> dict:
    conn.execute(
        """INSERT INTO merchant_accounts (store_id, provider, provider_account_id, payouts_enabled, country)
           VALUES (%s,'stripe',%s,true,%s)
           ON CONFLICT (store_id) DO UPDATE
             SET provider_account_id = EXCLUDED.provider_account_id,
                 payouts_enabled = true""",
        (store_id, provider_account_id, country),
    )
    return {"store_id": store_id, "provider_account_id": provider_account_id}


def get_merchant_account(conn: Conn, store_id: str) -> dict | None:
    return conn.execute(
        "SELECT provider_account_id, payouts_enabled, country FROM merchant_accounts WHERE store_id=%s",
        (store_id,),
    ).fetchone()


def set_tenant(conn: Conn, store_id: str) -> None:
    """يفعّل RLS لمتجر واحد داخل المعاملة الحالية."""
    conn.execute("SELECT set_config('app.store_id', %s, true)", (str(store_id),))


# ---------------------------------------------------------------- دفع
def start_payment(
    *,
    client: StripeConnectClient,
    store_id: str,
    order_id: str,
    amount_minor: int,
    currency: str,
    buyer_email: str,
) -> dict:
    """ينشئ PaymentIntent لدى Stripe ويخزّن payment(pending) + platform_fee(pending)."""
    with atomic() as conn:
        set_tenant(conn, store_id)
        merchant = get_merchant_account(conn, store_id)
        if not merchant or not merchant["payouts_enabled"]:
            raise PaymentError("merchant account missing or payouts disabled — refusing to charge")
        if amount_minor == 0:
            # منتج مجاني: لا دفع، لا عمولة، لا دفتر
            conn.execute("UPDATE orders SET status='paid' WHERE id=%s", (order_id,))
            audit_append(conn, actor="system", action="free_order", resource=f"order:{order_id}", store_id=store_id)
            return {"status": "free", "order_id": order_id}

        intent = client.create_payment_intent(
            amount_minor=amount_minor,
            currency=currency,
            order_id=order_id,
            buyer_email=buyer_email,
            transfer_destination=None,  # Separate Charges & Transfers: never a destination charge.
            idempotency_key=f"pi:{order_id}",
        )
        if not str(intent.get("id", "")).startswith("pi_"):
            raise PaymentError("provider did not return a payment intent id — refusing to continue")

        conn.execute(
            """INSERT INTO payments (order_id, store_id, provider, provider_payment_id,
                                     amount_minor, currency, status)
               VALUES (%s,%s,'stripe',%s,%s,%s,'pending')
               ON CONFLICT (order_id) DO NOTHING""",
            (order_id, store_id, intent["id"], amount_minor, currency),
        )
        conn.execute(
            """INSERT INTO provider_refs (provider, provider_payment_id, store_id, order_id)
               VALUES ('stripe',%s,%s,%s) ON CONFLICT DO NOTHING""",
            (intent["id"], store_id, order_id),
        )
        conn.execute(
            """INSERT INTO platform_fees (order_id, payment_id, store_id, amount_minor, currency, status)
               SELECT %s, p.id, %s, 0, %s, 'pending' FROM payments p WHERE p.order_id=%s
               ON CONFLICT (order_id) DO NOTHING""",
            (order_id, store_id, currency, order_id),
        )
    return {"status": "pending", "payment_intent": intent["id"], "client_secret": intent.get("client_secret")}


# ---------------------------------------------------------------- webhooks
def record_event(conn: Conn, provider: str, event: dict, signature_valid: bool) -> bool:
    """يسجل الحدث. يعيد False إذا كان مكررًا (منع replay)."""
    row = conn.execute(
        """INSERT INTO webhook_events (provider, event_id, event_type, payload, signature_valid, status)
           VALUES (%s,%s,%s,%s,%s,%s)
           ON CONFLICT (provider, event_id) DO NOTHING
           RETURNING id""",
        (provider, event["id"], event["type"], json.dumps(event), signature_valid, "received"),
    ).fetchone()
    return row is not None


def process_webhook(
    *,
    client: StripeConnectClient,
    raw_body: bytes,
    signature_header: str,
    webhook_secret: str,
) -> dict:
    """يعالج حدث Stripe: تحقق توقيع → منع تكرار → تحديث الدفع/العمولة/الدفتر/التحويل."""
    if not verify_webhook(raw_body, signature_header, webhook_secret):
        raise PaymentError("invalid signature — event rejected")
    try:
        event = json.loads(raw_body)
    except (ValueError, RecursionError):
        raise PaymentError("malformed webhook payload") from None
    if not isinstance(event, dict):
        raise PaymentError("malformed webhook payload")
    event_id, event_type = event.get("id"), event.get("type")
    data = event.get("data")
    if (not isinstance(event_id, str) or not 1 <= len(event_id) <= 255
            or not isinstance(event_type, str) or not 1 <= len(event_type) <= 128
            or not isinstance(data, dict) or not isinstance(data.get("object"), dict)):
        raise PaymentError("malformed webhook payload")

    with atomic() as conn:
        if not record_event(conn, "stripe", event, True):
            return {"status": "duplicate", "event": event_id}

        lookup = _resolve_order(conn, event)
        if lookup is None:
            conn.execute("UPDATE webhook_events SET status='failed', processed_at=now() WHERE event_id=%s", (event_id,))
            return {"status": "ignored", "event": event_id, "reason": "no matching payment"}

        store_id, order_id = lookup
        # سياق المتجر أولًا: كل استعلامات payments/orders تخضع لـ RLS
        set_tenant(conn, store_id)
        pay_row = conn.execute("SELECT id FROM payments WHERE order_id=%s", (order_id,)).fetchone()
        if not pay_row:
            conn.execute("UPDATE webhook_events SET status='failed', processed_at=now() WHERE event_id=%s", (event_id,))
            return {"status": "ignored", "event": event_id, "reason": "payment row missing"}
        payment_id = str(pay_row["id"])

        if event_type in ("payment_intent.succeeded", "charge.succeeded"):
            result = _on_payment_succeeded(conn, client, store_id, order_id, payment_id, event)
        elif event_type in ("payment_intent.payment_failed", "charge.failed"):
            result = _on_payment_failed(conn, store_id, order_id, payment_id, event)
        elif event_type in ("transfer.paid", "transfer.updated"):
            result = _on_transfer_update(conn, store_id, order_id, event)
        elif event_type == "transfer.reversed":
            result = _on_transfer_reversed(conn, store_id, order_id, event)
        elif event_type in ("charge.refunded", "refund.updated"):
            result = _on_refund(conn, store_id, order_id, payment_id, event)
        elif event_type in ("charge.dispute.created", "charge.dispute.updated"):
            result = _on_dispute(conn, store_id, order_id, payment_id, event)
        else:
            result = {"status": "ignored", "type": event_type}

        conn.execute("UPDATE webhook_events SET status='processed', processed_at=now() WHERE event_id=%s", (event_id,))
        audit_append(conn, actor="stripe", action=f"webhook:{event_type}", resource=f"order:{order_id}",
                     store_id=store_id, meta={"event": event_id, "result": result})
    return {"status": "processed", "event": event_id, "result": result}


def _resolve_order(conn: Conn, event: dict) -> tuple[str, str] | None:
    """يحوّل معرّف الحدث إلى (store_id, order_id) عبر provider_refs (خارج RLS)."""
    obj = event.get("data", {}).get("object", {})
    candidates = [obj.get("id"), obj.get("payment_intent"), obj.get("transfer"), obj.get("charge")]
    for key in candidates:
        if not key:
            continue
        row = conn.execute(
            "SELECT store_id, order_id FROM provider_refs WHERE provider_payment_id = %s", (key,)
        ).fetchone()
        if row:
            return str(row["store_id"]), str(row["order_id"])
    return None


def _on_payment_succeeded(conn, client, store_id, order_id, payment_id, event) -> dict:
    payment = conn.execute("SELECT status FROM payments WHERE id=%s FOR UPDATE", (payment_id,)).fetchone()
    if not payment:
        raise PaymentError("payment not found")
    # Different event IDs (or payment_intent + charge notifications) describe
    # one business action. Serialize on payment state, not just event identity.
    if payment["status"] not in ("pending", "processing"):
        return {"status": "ignored", "reason": "payment already finalized"}
    obj = event["data"]["object"]
    gateway_fee = int(obj.get("balance_transaction_fee", 0) or 0)
    conn.execute(
        """UPDATE payments SET status='paid', gateway_fee_minor=%s, updated_at=now()
            WHERE id=%s AND status IN ('pending','processing')""",
        (gateway_fee, payment_id),
    )
    conn.execute("UPDATE orders SET status='paid' WHERE id=%s AND status='pending'", (order_id,))

    order = one(
        conn.execute("SELECT amount_minor, coupon_minor, currency FROM orders WHERE id=%s", (order_id,)).fetchone(),
        context="order for webhook",
    )
    gross = int(order["amount_minor"]) - int(order["coupon_minor"])
    if gross <= 0:
        return {"status": "free_order", "gross": 0}

    split = post_sale(
        conn,
        store_id=store_id,
        order_id=order_id,
        gross_minor=gross,
        gateway_fee_minor=gateway_fee,
        currency=order["currency"],
    )
    # العمولة: pending → processing (لم تُحصّل بعد)
    conn.execute(
        """UPDATE platform_fees SET amount_minor=%s, status='processing', updated_at=now()
            WHERE order_id=%s""",
        (split["platform_fee_minor"], order_id),
    )

    # إنشاء تحويل حصة التاجر عبر Stripe (idempotent على مستوى المزود)
    merchant = get_merchant_account(conn, store_id)
    payout_result: dict[str, Any] = {"status": "skipped", "reason": "no merchant account"}
    if merchant and split["merchant_net_minor"] > 0:
        idem = f"payout:{order_id}"
        conn.execute(
            """INSERT INTO transfers (order_id, store_id, kind, amount_minor, currency, status, idempotency_key)
               VALUES (%s,%s,'merchant_payout',%s,%s,'pending',%s)
               ON CONFLICT DO NOTHING""",
            (order_id, store_id, split["merchant_net_minor"], order["currency"], idem),
        )
        existing = conn.execute(
            "SELECT status, provider_transfer_id FROM transfers WHERE order_id=%s AND kind='merchant_payout'",
            (order_id,),
        ).fetchone()
        if existing and existing["status"] in ("processing", "paid"):
            payout_result = {"status": existing["status"], "reused": True}
        else:
            try:
                tr = client.create_transfer(
                    amount_minor=split["merchant_net_minor"],
                    currency=order["currency"],
                    destination=merchant["provider_account_id"],
                    order_id=order_id,
                    kind="merchant_payout",
                    idempotency_key=idem,
                )
                conn.execute(
                    """UPDATE transfers SET status='processing', provider_transfer_id=%s
                        WHERE order_id=%s AND kind='merchant_payout'""",
                    (tr["id"], order_id),
                )
                # ربط معرّف التحويل بالمتجر ليُحلّ حدث transfer.* القادم من المزود
                conn.execute(
                    """INSERT INTO provider_refs (provider, provider_payment_id, store_id, order_id)
                       VALUES ('stripe',%s,%s,%s) ON CONFLICT DO NOTHING""",
                    (tr["id"], store_id, order_id),
                )
                payout_result = {"status": "processing", "transfer": tr["id"]}
            except StripeError as exc:
                conn.execute(
                    """UPDATE transfers SET status='failed', failure_reason=%s
                        WHERE order_id=%s AND kind='merchant_payout'""",
                    (str(exc)[:500], order_id),
                )
                conn.execute(
                    "UPDATE platform_fees SET status='failed', updated_at=now() WHERE order_id=%s", (order_id,)
                )
                payout_result = {"status": "failed", "error": str(exc)}

    _upsert_settlement(conn, store_id, order["currency"])
    return {"status": "paid", "split": split, "payout": payout_result}


def _on_payment_failed(conn, store_id, order_id, payment_id, event) -> dict:
    changed = conn.execute(
        "UPDATE payments SET status='failed', updated_at=now() "
        "WHERE id=%s AND status IN ('pending','processing') RETURNING id", (payment_id,),
    ).fetchone()
    if not changed:
        return {"status": "ignored", "reason": "payment already finalized"}
    conn.execute("UPDATE orders SET status='failed' WHERE id=%s AND status='pending'", (order_id,))
    conn.execute("UPDATE platform_fees SET status='failed', updated_at=now() WHERE order_id=%s", (order_id,))
    conn.execute("UPDATE transfers SET status='failed', failure_reason='payment_failed' WHERE order_id=%s", (order_id,))
    return {"status": "failed"}


def _on_transfer_update(conn, store_id, order_id, event) -> dict:
    # Event-id deduplication alone does not prevent two provider notifications
    # about the same transfer from booking fee recognition twice.
    transfer = conn.execute(
        "SELECT status FROM transfers WHERE order_id=%s AND kind='merchant_payout' FOR UPDATE",
        (order_id,),
    ).fetchone()
    if not transfer:
        raise PaymentError("transfer not found")
    if transfer["status"] == "paid":
        return {"status": "fee_paid", "reused": True}
    if transfer["status"] in ("refunded", "disputed"):
        return {"status": "noop", "reason": "terminal transfer"}
    obj = event["data"]["object"]
    provider_status = obj.get("status")
    if provider_status == "paid" or event["type"] == "transfer.paid":
        conn.execute(
            """UPDATE transfers SET status='paid', confirmed_at=now()
                WHERE order_id=%s AND kind='merchant_payout'""",
            (order_id,),
        )
        # تأكيد استلام العمولة في حساب المنصة: الآن فقط paid
        conn.execute(
            "UPDATE platform_fees SET status='paid', updated_at=now() WHERE order_id=%s", (order_id,)
        )
        post_group(
            conn,
            store_id=store_id,
            order_id=order_id,
            lines=[("platform_fee", "debit", _fee_amount(conn, order_id)),
                   ("platform_earnings", "credit", _fee_amount(conn, order_id))],
            currency=_order_currency(conn, order_id),
        )
        return {"status": "fee_paid"}
    if provider_status == "failed":
        conn.execute("UPDATE transfers SET status='failed' WHERE order_id=%s", (order_id,))
        conn.execute("UPDATE platform_fees SET status='failed' WHERE order_id=%s", (order_id,))
        return {"status": "transfer_failed"}
    return {"status": "noop", "provider_status": provider_status}


def _fee_amount(conn, order_id) -> int:
    row = conn.execute("SELECT amount_minor FROM platform_fees WHERE order_id=%s", (order_id,)).fetchone()
    amount = int(row["amount_minor"]) if row else 0
    return amount if amount > 0 else 1  # لا نسمح بمجموعة صفرية على دفتر حقيقي


def _order_currency(conn, order_id) -> str:
    row = conn.execute("SELECT currency FROM orders WHERE id=%s", (order_id,)).fetchone()
    return row["currency"] if row else "USD"


def _on_transfer_reversed(conn, store_id, order_id, event) -> dict:
    conn.execute("UPDATE transfers SET status='failed' WHERE order_id=%s", (order_id,))
    conn.execute("UPDATE platform_fees SET status='failed' WHERE order_id=%s", (order_id,))
    post_refund(
        conn, store_id=store_id, order_id=order_id,
        amount_minor=_fee_amount(conn, order_id), fee_refunded_minor=0,
        currency=_order_currency(conn, order_id),
    )
    return {"status": "reversed"}


def _on_refund(conn, store_id, order_id, payment_id, event) -> dict:
    obj = event["data"]["object"]
    amount = int(obj.get("amount_refunded") or obj.get("amount") or 0)
    if amount <= 0:
        return {"status": "ignored", "reason": "zero amount"}
    pay = conn.execute("SELECT amount_minor, currency FROM payments WHERE id=%s", (payment_id,)).fetchone()
    full = amount >= int(pay["amount_minor"])
    fee_policy = "fee_refunded" if full else "fee_retained"
    fee = _fee_amount(conn, order_id) if full else 0
    conn.execute(
        """INSERT INTO refunds (payment_id, store_id, amount_minor, reason, provider_refund_id, fee_policy, status)
           VALUES (%s,%s,%s,%s,%s,%s,'succeeded')
           ON CONFLICT (provider_refund_id) DO NOTHING""",
        (payment_id, store_id, amount, obj.get("reason", "requested_by_customer"), obj.get("id"), fee_policy),
    )
    conn.execute("UPDATE payments SET status='refunded', updated_at=now() WHERE id=%s", (payment_id,))
    conn.execute("UPDATE orders SET status='refunded' WHERE id=%s", (order_id,))
    if full:
        conn.execute("UPDATE platform_fees SET status='refunded', updated_at=now() WHERE order_id=%s", (order_id,))
    post_refund(conn, store_id=store_id, order_id=order_id, amount_minor=amount,
                fee_refunded_minor=min(fee, amount), currency=pay["currency"])
    conn.execute(
        "UPDATE settlements SET status='frozen' WHERE store_id=%s AND status='open'", (store_id,)
    )
    return {"status": "refunded", "amount": amount, "fee_policy": fee_policy}


def _on_dispute(conn, store_id, order_id, payment_id, event) -> dict:
    obj = event["data"]["object"]
    conn.execute(
        """INSERT INTO disputes (payment_id, store_id, provider_dispute_id, amount_minor, status)
           VALUES (%s,%s,%s,%s,%s)
           ON CONFLICT (provider_dispute_id) DO UPDATE SET status=EXCLUDED.status""",
        (payment_id, store_id, obj["id"], int(obj.get("amount", 0)), obj.get("status", "needs_response")),
    )
    conn.execute("UPDATE payments SET status='disputed', updated_at=now() WHERE id=%s", (payment_id,))
    conn.execute("UPDATE orders SET status='disputed' WHERE id=%s", (order_id,))
    conn.execute("UPDATE platform_fees SET status='disputed', updated_at=now() WHERE order_id=%s", (order_id,))
    conn.execute("UPDATE settlements SET status='frozen' WHERE store_id=%s AND status='open'", (store_id,))
    post_refund(conn, store_id=store_id, order_id=order_id,
                amount_minor=max(1, int(obj.get("amount", 0))), fee_refunded_minor=0,
                currency=_order_currency(conn, order_id), dispute=True)
    return {"status": "disputed", "dispute": obj["id"]}


# ---------------------------------------------------------------- تسوية
def _upsert_settlement(conn: Conn, store_id: str, currency: str) -> dict:
    today = date.today()
    row = conn.execute(
        """SELECT COALESCE(SUM(p.amount_minor),0) AS gross,
                  COALESCE(SUM(p.gateway_fee_minor),0) AS gateway,
                  COALESCE(SUM(pf.amount_minor),0) AS fee
             FROM payments p
             JOIN platform_fees pf ON pf.payment_id = p.id
            WHERE p.store_id=%s AND p.status='paid'""",
        (store_id,),
    ).fetchone()
    row = one(row, context="settlement aggregate")
    gross, gateway, fee = int(row["gross"]), int(row["gateway"]), int(row["fee"])
    net = gross - gateway - fee
    existing = conn.execute(
        "SELECT id FROM settlements WHERE store_id=%s AND status='open' ORDER BY created_at DESC LIMIT 1",
        (store_id,),
    ).fetchone()
    if existing:
        conn.execute(
            """UPDATE settlements SET gross_minor=%s, platform_fee_minor=%s, gateway_fee_minor=%s,
                      net_to_merchant_minor=%s, period_end=%s
                WHERE id=%s""",
            (gross, fee, gateway, net, today, existing["id"]),
        )
        return {"settlement_id": str(existing["id"]), "updated": True, "net": net}
    new = conn.execute(
        """INSERT INTO settlements (store_id, period_start, period_end, gross_minor, platform_fee_minor,
                                    gateway_fee_minor, net_to_merchant_minor, status)
           VALUES (%s,%s,%s,%s,%s,%s,%s,'open') RETURNING id""",
        (store_id, today, today, gross, fee, gateway, net),
    ).fetchone()
    new = one(new, context="created settlement")
    return {"settlement_id": str(new["id"]), "updated": False, "net": net}


# ---------------------------------------------------------------- استرداد/نزاع يدوي
def refund_payment(*, client: StripeConnectClient, store_id: str, order_id: str, amount_minor: int, reason: str) -> dict:
    with atomic() as conn:
        set_tenant(conn, store_id)
        pay = conn.execute(
            "SELECT id, provider_payment_id, amount_minor, currency FROM payments WHERE order_id=%s", (order_id,)
        ).fetchone()
        if not pay:
            raise PaymentError("payment not found")
        remaining = int(pay["amount_minor"])
        if amount_minor <= 0 or amount_minor > remaining:
            raise PaymentError("invalid refund amount")
        refund = client.create_refund(
            payment_intent=pay["provider_payment_id"],
            amount_minor=amount_minor,
            reason=reason,
            idempotency_key=f"refund:{order_id}:{amount_minor}",
        )
        if not str(refund.get("id", "")).startswith("re_"):
            raise PaymentError("provider did not return a refund id")
        full = amount_minor >= remaining
        fee = _fee_amount(conn, order_id) if full else 0
        conn.execute(
            """INSERT INTO refunds (payment_id, store_id, amount_minor, reason, provider_refund_id, fee_policy, status)
               VALUES (%s,%s,%s,%s,%s,%s,'succeeded')""",
            (pay["id"], store_id, amount_minor, reason, refund["id"],
             "fee_refunded" if full else "fee_retained"),
        )
        if full:
            conn.execute("UPDATE payments SET status='refunded', updated_at=now() WHERE id=%s", (pay["id"],))
            conn.execute("UPDATE orders SET status='refunded' WHERE id=%s", (order_id,))
            conn.execute("UPDATE platform_fees SET status='refunded', updated_at=now() WHERE order_id=%s", (order_id,))
        post_refund(conn, store_id=store_id, order_id=order_id, amount_minor=amount_minor,
                    fee_refunded_minor=min(fee, amount_minor), currency=pay["currency"])
    return {"refund_id": refund["id"], "amount": amount_minor, "fee_policy": "fee_refunded" if full else "fee_retained"}


def settlement_summary(store_id: str) -> dict:
    with atomic() as conn:
        set_tenant(conn, store_id)
        row = conn.execute(
            """SELECT COALESCE(SUM(gross_minor),0) AS gross,
                      COALESCE(SUM(platform_fee_minor),0) AS fee,
                      COALESCE(SUM(gateway_fee_minor),0) AS gateway,
                      COALESCE(SUM(net_to_merchant_minor),0) AS net
                 FROM settlements WHERE store_id=%s""",
            (store_id,),
        ).fetchone()
        fees = conn.execute(
            """SELECT status, COUNT(*) AS n, COALESCE(SUM(amount_minor),0) AS total
                 FROM platform_fees WHERE store_id=%s GROUP BY status""",
            (store_id,),
        ).fetchall()
    row = one(row, context="settlement summary")
    return {
        "gross_minor": int(row["gross"]),
        "platform_fee_minor": int(row["fee"]),
        "gateway_fee_minor": int(row["gateway"]),
        "net_to_merchant_minor": int(row["net"]),
        "fees_by_status": {r["status"]: {"count": r["n"], "minor": int(r["total"])} for r in fees},
        "as_of": datetime.now(timezone.utc).isoformat(),
    }
