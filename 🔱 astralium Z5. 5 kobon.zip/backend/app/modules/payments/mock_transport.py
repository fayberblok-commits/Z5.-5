"""محاكي Stripe (MockTransport) — للاختبارات فقط، ولا يُستخدم في الإنتاج.

* لا يتصل بالشبكة إطلاقًا.
* يُعيد نفس المعرّف لنفس `Idempotency-Key` مثل Stripe الحقيقي، ما يسمح باختبار
  منع تكرار التحويل فعليًا.
* يمكن تهيئته للفشل (`fail_transfers`) لاختبار مسار `failed`.

يُفعّل فقط عند `STRIPE_MOCK_TRANSPORT=1` و`APP_ENV=test`.
"""

from __future__ import annotations

import hashlib
import json
from typing import Any

import httpx


def _stable_id(prefix: str, idem: str) -> str:
    digest = hashlib.sha256(idem.encode()).hexdigest()[:20]
    return f"{prefix}_{digest}"


class StripeMockState:
    fail_transfers = False
    fail_payment_intents = False
    calls: list[dict[str, Any]] = []
    transfers: dict[str, dict[str, Any]] = {}

    @classmethod
    def reset(cls) -> None:
        cls.fail_transfers = False
        cls.fail_payment_intents = False
        cls.calls = []
        cls.transfers = {}


def _error(message: str, code: str, status: int = 402) -> httpx.Response:
    return httpx.Response(status, json={"error": {"message": message, "code": code, "type": "api_error"}})


def handle(request: httpx.Request) -> httpx.Response:
    path = request.url.path
    idem = request.headers.get("idempotency-key", "")
    form = dict(httpx.QueryParams(request.content.decode()))
    StripeMockState.calls.append({"path": path, "idempotency": idem, "form": form})

    if not idem:
        return _error("idempotency key required", "missing_idempotency_key", 400)

    if path == "/v1/payment_intents":
        if StripeMockState.fail_payment_intents:
            return _error("card_declined", "card_declined")
        return httpx.Response(200, json={
            "id": _stable_id("pi", idem),
            "object": "payment_intent",
            "amount": int(form.get("amount", 0)),
            "currency": form.get("currency", "usd"),
            "status": "requires_payment_method",
            "client_secret": f"{_stable_id('pi', idem)}_secret_test",
            "metadata": {"order_id": form.get("metadata[order_id]", "")},
        })

    if path == "/v1/transfers":
        if StripeMockState.fail_transfers:
            return _error("insufficient_funds_in_platform_balance", "balance_insufficient")
        tid = _stable_id("tr", idem)
        record: dict[str, Any] = {
            "id": tid,
            "object": "transfer",
            "amount": int(form.get("amount", 0)),
            "currency": form.get("currency", "usd"),
            "destination": form.get("destination", ""),
            "status": "pending",
            "metadata": {"order_id": form.get("metadata[order_id]", ""), "kind": form.get("metadata[kind]", "")},
        }
        StripeMockState.transfers[tid] = dict(record)
        return httpx.Response(200, json=dict(record))

    if path.startswith("/v1/transfers/"):
        tid = path.rsplit("/", 1)[-1]
        stored = StripeMockState.transfers.get(tid)
        if not stored:
            return _error("no such transfer", "resource_missing", 404)
        return httpx.Response(200, json=stored)

    if path == "/v1/refunds":
        return httpx.Response(200, json={
            "id": _stable_id("re", idem),
            "object": "refund",
            "amount": int(form.get("amount", 0)),
            "status": "succeeded",
        })

    return httpx.Response(404, json={"error": {"message": f"unhandled path {path}"}})


def mock_transport() -> httpx.MockTransport:
    return httpx.MockTransport(handle)


def build_event(*, event_id: str, event_type: str, obj: dict) -> bytes:
    return json.dumps({"id": event_id, "type": event_type, "data": {"object": obj}}).encode()
