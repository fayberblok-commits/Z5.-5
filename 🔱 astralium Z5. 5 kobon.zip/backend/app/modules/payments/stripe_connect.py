"""عميل Stripe Connect — HTTP حقيقي عبر httpx، مع مفاتيح idempotency إلزامية.

لا تُنشأ أي معرّفات محليًا: كل معرّف (`pi_…`, `tr_…`, `re_…`) يأتي من استجابة
Stripe. في الاختبارات يُحقن `httpx.MockTransport` صراحةً، ولا يوجد أي مسار
يُنتج معرّفات وهمية ويسمّيها مالية.
"""

from __future__ import annotations

import hashlib
import hmac
import time
from typing import Any, Protocol
from urllib.parse import urlencode

import httpx

STRIPE_API = "https://api.stripe.com"
DEFAULT_TOLERANCE_SEC = 300


class StripeError(RuntimeError):
    """فشل استدعاء Stripe — يُترجم إلى حالة failed لا إلى نجاح صامت."""

    def __init__(self, message: str, status: int | None = None, code: str | None = None) -> None:
        super().__init__(message)
        self.status = status
        self.code = code


class TransportFactory(Protocol):
    def __call__(self) -> httpx.BaseTransport: ...


def parse_signature_header(header: str) -> tuple[int, list[str]]:
    """يحلّل `t=…,v1=…,v1=…` (Stripe يرسل عدة توقيعات أثناء التدوير)."""
    ts: int | None = None
    sigs: list[str] = []
    for part in header.split(","):
        key, _, value = part.strip().partition("=")
        if key == "t":
            ts = int(value)
        elif key == "v1":
            sigs.append(value)
    if ts is None or not sigs:
        raise ValueError("malformed Stripe-Signature header")
    return ts, sigs


def compute_signature(payload: bytes, secret: str, timestamp: int) -> str:
    signed = f"{timestamp}.".encode() + payload
    return hmac.new(secret.encode(), signed, hashlib.sha256).hexdigest()


def verify_webhook(payload: bytes, header: str, secret: str, tolerance: int = DEFAULT_TOLERANCE_SEC) -> bool:
    try:
        ts, sigs = parse_signature_header(header)
    except (ValueError, TypeError):
        return False
    if abs(time.time() - ts) > tolerance:
        return False
    expected = compute_signature(payload, secret, ts)
    return any(hmac.compare_digest(expected, sig) for sig in sigs)


class StripeConnectClient:
    """عملية Stripe Connect (Separate Charges & Transfers).

    التدفق: PaymentIntent على حساب المنصة → عند التأكيد يُنشأ Transfer بحصة
    التاجر إلى الحساب المتصل، وتبقى عمولة المنصة في حساب المنصة كـ
    `application_fee` غير مستخدمة هنا (لا نُعلنها محصّلة إلا بتأكيد webhook).
    """

    def __init__(
        self,
        secret_key: str,
        *,
        transport: httpx.BaseTransport | None = None,
        base_url: str = STRIPE_API,
        timeout: float = 15.0,
    ) -> None:
        if not secret_key.startswith(("sk_test_", "sk_live_", "rk_test_", "rk_live_")):
            raise StripeError("secret key shape invalid", code="invalid_api_key")
        self._client = httpx.Client(
            base_url=base_url,
            auth=(secret_key, ""),
            timeout=timeout,
            transport=transport,
            headers={"Stripe-Version": "2024-06-20"},
        )

    # ---------- أدوات ----------
    def _request(self, method: str, path: str, *, data: dict[str, Any], idempotency_key: str) -> dict:
        if not idempotency_key:
            raise StripeError("idempotency key is mandatory", code="missing_idempotency_key")
        try:
            resp = self._client.request(
                method,
                path,
                content=urlencode(data, doseq=True),
                headers={
                    "Idempotency-Key": idempotency_key,
                    "Content-Type": "application/x-www-form-urlencoded",
                },
            )
        except httpx.HTTPError as exc:
            raise StripeError(f"transport error: {exc}", code="transport_error") from exc
        if resp.status_code >= 400:
            try:
                err = resp.json().get("error", {})
            except ValueError:
                err = {}
            raise StripeError(
                err.get("message", f"stripe error {resp.status_code}"),
                status=resp.status_code,
                code=err.get("code"),
            )
        return dict(resp.json())

    def close(self) -> None:
        self._client.close()

    # ---------- الدفع ----------
    def create_payment_intent(
        self,
        *,
        amount_minor: int,
        currency: str,
        order_id: str,
        buyer_email: str,
        transfer_destination: str | None,
        idempotency_key: str,
        metadata: dict[str, str] | None = None,
    ) -> dict:
        if amount_minor <= 0:
            raise StripeError("amount must be positive", code="invalid_amount")
        data: dict[str, Any] = {
            "amount": amount_minor,
            "currency": currency.lower(),
            "payment_method_types[]": "card",
            "receipt_email": buyer_email,
            "metadata[order_id]": order_id,
            "transfer_group": order_id,
        }
        for k, v in (metadata or {}).items():
            data[f"metadata[{k}]"] = v
        if transfer_destination:
            data["transfer_data[destination]"] = transfer_destination
        return dict(self._request("POST", "/v1/payment_intents", data=data, idempotency_key=idempotency_key))

    def create_transfer(
        self,
        *,
        amount_minor: int,
        currency: str,
        destination: str,
        order_id: str,
        kind: str,
        idempotency_key: str,
    ) -> dict:
        if amount_minor <= 0:
            raise StripeError("transfer amount must be positive", code="invalid_amount")
        data = {
            "amount": amount_minor,
            "currency": currency.lower(),
            "destination": destination,
            "transfer_group": order_id,
            "metadata[order_id]": order_id,
            "metadata[kind]": kind,
        }
        return self._request("POST", "/v1/transfers", data=data, idempotency_key=idempotency_key)

    def retrieve_transfer(self, transfer_id: str) -> dict:
        resp = self._client.get(f"/v1/transfers/{transfer_id}")
        if resp.status_code >= 400:
            raise StripeError(f"retrieve transfer failed: {resp.status_code}", status=resp.status_code)
        return dict(resp.json())

    def create_refund(self, *, payment_intent: str, amount_minor: int, reason: str, idempotency_key: str) -> dict:
        data = {
            "payment_intent": payment_intent,
            "amount": amount_minor,
            "reason": "requested_by_customer",
            "metadata[reason]": reason,
        }
        return self._request("POST", "/v1/refunds", data=data, idempotency_key=idempotency_key)


def verify_connect_webhook_or_raise(payload: bytes, header: str, secret: str) -> None:
    if not verify_webhook(payload, header, secret):
        raise StripeError("invalid webhook signature", code="signature_verification_failed")
