"""Unified payment adapters — Stripe/PayPal Sandbox, idempotent, signed Webhooks."""

import hmac
import hashlib
import time
from typing import Dict


def stripe_sign_payload(payload: str, secret: str, timestamp: str) -> str:
    msg = f"{timestamp}.{payload}"
    sig = hmac.new(secret.encode(), msg.encode(), hashlib.sha256).hexdigest()
    return f"t={timestamp},v1={sig}"


def verify_stripe_signature(payload: str, header: str, secret: str, tolerance_sec=300) -> bool:
    # header format: t=...,v1=...
    try:
        parts = dict(p.split("=") for p in header.split(","))
        ts = int(parts["t"])
        v1 = parts["v1"]
        if abs(time.time() - ts) > tolerance_sec:
            return False
        expected = hmac.new(secret.encode(), f"{ts}.{payload}".encode(), hashlib.sha256).hexdigest()
        return hmac.compare_digest(expected, v1)
    except Exception:
        return False


class IdempotencyStore:
    def __init__(self):
        self.seen: set[str] = set()

    def check_or_store(self, key: str) -> bool:
        if key in self.seen:
            return False  # duplicate
        self.seen.add(key)
        return True


idempotency = IdempotencyStore()


class StripeAdapter:
    """واجهة قديمة — أُفرغت من التوليد الوهمي.

    كانت تُصنّع `pi_...` بلا أي اتصال بمزوّد، أي أنها تُرجع "نجاح دفع" مزيفًا.
    المسار الحقيقي الوحيد هو `app.modules.payments.stripe_connect.StripeConnectClient`.
    """

    def __init__(self, secret_key: str, webhook_secret: str):
        self.secret_key = secret_key
        self.webhook_secret = webhook_secret

    def create_intent(self, amount_minor: int, currency: str = "usd", idempotency_key: str | None = None) -> Dict:
        raise NotImplementedError(
            "use StripeConnectClient (real HTTP to the provider) — no fabricated payment ids"
        )

    def verify_webhook(self, payload: str, sig_header: str) -> bool:
        return verify_stripe_signature(payload, sig_header, self.webhook_secret)


class PayPalAdapter:
    def __init__(self, client_id: str, secret: str, webhook_id: str, env="sandbox"):
        self.client_id = client_id
        self.secret = secret
        self.webhook_id = webhook_id
        self.env = env

    def create_order(self, amount_minor: int, currency: str = "USD") -> Dict:
        raise NotImplementedError("PayPal payouts are not implemented — refusing to fabricate an order id")

    def verify_webhook(self, payload: str, headers: Dict) -> bool:
        # In prod: verify via PayPal API /webhooks/verify
        # Sandbox stub: check HMAC with webhook_id
        sig = headers.get("paypal-transmission-sig", "")
        expected = hmac.new(self.webhook_id.encode(), payload.encode(), hashlib.sha256).hexdigest()
        return hmac.compare_digest(expected, sig)
