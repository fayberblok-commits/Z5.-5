"""File handling: content-type by magic, ClamAV stub, quarantine, signed URLs."""

import hmac
import hashlib
import time
import os
import re
import mimetypes

ALLOWED_MIME = {"image/jpeg", "image/png", "image/webp", "image/gif", "application/pdf", "text/plain", "video/mp4"}
MAX_SIZE = 50 * 1024 * 1024  # 50MB


def detect_mime(content: bytes, filename: str) -> str:
    # try python-magic, fallback to guess
    try:
        import magic

        m = magic.from_buffer(content, mime=True)
        return m
    except Exception:
        return mimetypes.guess_type(filename)[0] or "application/octet-stream"


def sanitize_filename(name: str) -> str:
    # prevent zip-slip, path traversal
    name = os.path.basename(name)
    name = re.sub(r"[^a-zA-Z0-9._-]", "_", name)
    return name


def is_polyglot(content: bytes) -> bool:
    # naive: detect multiple magic signatures
    if content.startswith(b"\xff\xd8") and b"%PDF" in content[:2048]:
        return True
    if b"<?php" in content.lower():
        return True
    return False


def is_svg_malicious(content: bytes) -> bool:
    if b"<script" in content.lower() or b"onload" in content.lower():
        return True
    return False


def clamav_scan(content: bytes) -> bool:
    # stub: in prod call clamd via socket
    # simulate: reject EICAR
    if b"X5O!P%@AP[4" in content:
        return False
    return True


def quarantine_reason(content: bytes, filename: str) -> str | None:
    mime = detect_mime(content, filename)
    if mime not in ALLOWED_MIME:
        return f"mime not allowed: {mime}"
    if len(content) > MAX_SIZE:
        return "too large"
    if is_polyglot(content):
        return "polyglot detected"
    if filename.endswith(".svg") and is_svg_malicious(content):
        return "svg malicious"
    if not clamav_scan(content):
        return "virus detected"
    # zip-slip check for future archive handling
    if ".." in filename or filename.startswith("/"):
        return "path traversal"
    return None


# Signed URL: HMAC with expiry, bound to buyer/order. النطاق من الإعدادات فقط —
# لا يوجد نطاق وهمي (s3.example) في الكود.
def _endpoint() -> str:
    from ...core.config import get_settings

    return get_settings().s3_endpoint.rstrip("/")


def sign_url(secret: str, bucket: str, key: str, buyer_id: str, expires_sec=600, endpoint: str | None = None) -> str:
    exp = int(time.time()) + expires_sec
    msg = f"{bucket}/{key}:{buyer_id}:{exp}"
    sig = hmac.new(secret.encode(), msg.encode(), hashlib.sha256).hexdigest()
    base = (endpoint or _endpoint()).rstrip("/")
    return f"{base}/{bucket}/{key}?buyer={buyer_id}&exp={exp}&sig={sig}"


def verify_signed_url(secret: str, bucket: str, key: str, buyer_id: str, exp: str, sig: str) -> bool:
    msg = f"{bucket}/{key}:{buyer_id}:{exp}"
    expected = hmac.new(secret.encode(), msg.encode(), hashlib.sha256).hexdigest()
    if not hmac.compare_digest(expected, sig):
        return False
    if int(exp) < int(time.time()):
        return False
    return True
