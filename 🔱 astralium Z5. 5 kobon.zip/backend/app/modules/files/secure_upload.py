"""رفع/تنزيل ملفات آمن — تحقق نوع حقيقي، فحص فيروسات fail-closed، روابط قصيرة العمر.

مبادئ:
* الرفع يتطلب جلسة مصادقة ومتجرًا مطابقًا (لا رفع مجهول).
* نوع المحتوى يُحدَّد من البايتات لا من الامتداد أو الترويسة.
* ClamAV إلزامي: إن تعذّر الوصول إلى clamd يُرفض الرفع (fail-closed)، لا يُقبل.
* الروابط: presigned من S3/MinIO الحقيقي (لا نطاق وهمي)، مقيدة بملف + متجر +
  مشترٍ + صلاحية قصيرة + استخدام واحد عبر جدول `file_download_tokens`.
"""

from __future__ import annotations

import hashlib
import io
import socket
import struct
import uuid
from datetime import datetime, timedelta, timezone


from ...core.db import Conn, one
from ...core.config import get_settings

CHUNK = 64 * 1024
EICAR = b"X5O!P%@AP[4\\PZX54(P^)7CC)7}$EICAR-STANDARD-ANTIVIRUS-TEST-FILE!$H+H*"

# بصمات حقيقية (magic bytes) — لا اعتماد على الامتداد
SIGNATURES: tuple[tuple[bytes, str], ...] = (
    (b"\xff\xd8\xff", "image/jpeg"),
    (b"\x89PNG\r\n\x1a\n", "image/png"),
    (b"GIF87a", "image/gif"),
    (b"GIF89a", "image/gif"),
    (b"%PDF-", "application/pdf"),
    (b"PK\x03\x04", "application/zip"),
    (b"RIFF", "image/webp"),  # يُتحقق لاحقًا من WEBP في الإزاحة 8
)

ALLOWED_TYPES = {
    "image/jpeg",
    "image/png",
    "image/gif",
    "image/webp",
    "application/pdf",
}

EXT_FOR_TYPE = {
    "image/jpeg": ".jpg",
    "image/png": ".png",
    "image/gif": ".gif",
    "image/webp": ".webp",
    "application/pdf": ".pdf",
}


class UploadRejected(ValueError):
    """رفض رفع — برسالة عامة لا تكشف تفاصيل داخلية."""


class StorageUnavailable(RuntimeError):
    """Private object retrieval failed; redemption must roll back."""


class ScanUnavailable(RuntimeError):
    """تعذّر فحص الفيروسات — يُرفض الرفع (fail-closed)."""


# ------------------------------------------------------------------ تحقق
def sniff_type(content: bytes) -> str:
    for magic, mime in SIGNATURES:
        if content.startswith(magic):
            if mime == "image/webp" and content[8:12] != b"WEBP":
                continue
            return mime
    return "application/octet-stream"


def detect_polyglot(content: bytes) -> bool:
    """ملف يصلح لأكثر من نوع (مثال: PDF داخل JPEG، ZIP داخل صورة)."""
    head = content[:4096]
    if head.startswith(b"\xff\xd8\xff") and (b"%PDF" in head or b"PK\x03\x04" in head):
        return True
    if head.startswith(b"\x89PNG") and content[:65536].count(b"%PDF") > 0:
        return True
    if b"<?php" in content[:8192].lower():
        return True
    return False


def svg_has_script(content: bytes) -> bool:
    low = content[:65536].lower()
    return any(tok in low for tok in (b"<script", b"onload=", b"onerror=", b"javascript:", b"<foreignobject"))


def safe_object_name(filename: str, mime: str) -> str:
    """اسم كائن عشوائي بامتداد مشتق من النوع المكتشف (لا من اسم المستخدم)."""
    if "/" in filename or "\\" in filename or ".." in filename or "\x00" in filename:
        raise UploadRejected("invalid filename")
    return f"{uuid.uuid4().hex}{EXT_FOR_TYPE.get(mime, '.bin')}"


def validate(content: bytes, filename: str, max_bytes: int | None = None) -> str:
    settings = get_settings()
    limit = max_bytes or settings.max_upload_bytes
    if not content:
        raise UploadRejected("empty file")
    if len(content) > limit:
        raise UploadRejected(f"file too large (max {limit} bytes)")
    if EICAR in content:
        raise UploadRejected("malware signature detected")
    mime = sniff_type(content)
    if mime not in ALLOWED_TYPES:
        raise UploadRejected("file type not allowed")
    if filename.lower().endswith(".svg") or b"<svg" in content[:2048].lower():
        raise UploadRejected("svg not allowed")
    if detect_polyglot(content):
        raise UploadRejected("polyglot file detected")
    if svg_has_script(content):
        raise UploadRejected("active content detected")
    return mime


# ------------------------------------------------------------------ ClamAV
def clamd_scan(content: bytes, host: str | None = None, port: int | None = None, timeout: float = 10.0) -> bool:
    """INSTREAM إلى clamd. يرفع ScanUnavailable إن لم يوجد الخادم (لا يمرّر بصمت)."""
    settings = get_settings()
    host = host or settings.clamav_host
    port = port or settings.clamav_port
    try:
        with socket.create_connection((host, port), timeout=timeout) as sock:
            sock.sendall(b"zINSTREAM\x00")
            view = memoryview(content)
            for i in range(0, len(view), CHUNK):
                chunk = view[i : i + CHUNK]
                sock.sendall(struct.pack("!I", len(chunk)) + chunk)
            sock.sendall(struct.pack("!I", 0))
            reply = sock.recv(4096).decode("utf-8", "replace").strip()
    except (OSError, socket.timeout) as exc:
        raise ScanUnavailable(f"clamd unreachable: {exc}") from exc
    if "FOUND" in reply:
        return False
    if "OK" not in reply:
        raise ScanUnavailable(f"unexpected clamd reply: {reply[:80]}")
    return True


# ------------------------------------------------------------------ S3
def s3_client():
    """عميل S3/MinIO حقيقي؛ يتم إنشاؤه من الإعدادات فقط (لا مفاتيح في الكود)."""
    import boto3
    from botocore.config import Config

    settings = get_settings()
    return boto3.client(
        "s3",
        endpoint_url=settings.s3_endpoint,
        aws_access_key_id=settings.s3_access_key.get_secret_value(),
        aws_secret_access_key=settings.s3_secret_key.get_secret_value(),
        region_name=settings.s3_region,
        config=Config(signature_version="s3v4", s3={"addressing_style": "path"}),
    )


def store_object(
    *,
    store_id: str,
    order_id: str | None,
    content: bytes,
    filename: str,
    client=None,
    scanner=None,
) -> dict:
    """يرفع كائنًا بعد التحقق والفحص. مسجَّل في جدول files بحالة clean فقط."""
    mime = validate(content, filename)
    scan = scanner or clamd_scan  # يُحقن بديل في الاختبارات فقط
    if not scan(content):
        raise UploadRejected("malware detected")
    settings = get_settings()
    key = f"stores/{store_id}/{safe_object_name(filename, mime)}"
    digest = hashlib.sha256(content).hexdigest()

    client = client or s3_client()
    client.put_object(
        Bucket=settings.s3_bucket_private,
        Key=key,
        Body=io.BytesIO(content),
        ContentType=mime,
        ServerSideEncryption="AES256",
        Metadata={"sha256": digest, "store": store_id},
    )
    return {
        "object_key": key,
        "bucket": settings.s3_bucket_private,
        "content_type": mime,
        "size": len(content),
        "sha256": digest,
        "scan_status": "clean",
        "store_id": store_id,
        "order_id": order_id,
    }


def register_file(conn: Conn, *, store_id: str, file: dict) -> dict:
    row = one(
        conn.execute(
            """INSERT INTO files (store_id, order_id, object_key, content_type, size_bytes, sha256, scan_status)
               VALUES (%s,%s,%s,%s,%s,%s,%s) RETURNING id""",
            (store_id, file["order_id"], file["object_key"], file["content_type"],
             file["size"], file["sha256"], file["scan_status"]),
        ).fetchone(),
        context="created file row",
    )
    return {"file_id": str(row["id"]), **{k: file[k] for k in ("object_key", "content_type", "size", "sha256")}}


# ------------------------------------------------------------------ تنزيل
def create_download_url(
    conn: Conn,
    *,
    file_id: str,
    store_id: str,
    buyer_id: str,
    client=None,
) -> dict:
    settings = get_settings()
    file_row = conn.execute(
        "SELECT object_key, scan_status FROM files WHERE id=%s AND store_id=%s", (file_id, store_id)
    ).fetchone()
    if not file_row:
        raise UploadRejected("file not found")
    if file_row["scan_status"] != "clean":
        raise UploadRejected("file not available")

    expires = datetime.now(timezone.utc) + timedelta(seconds=settings.file_url_ttl_seconds)
    jti = one(
        conn.execute(
            """INSERT INTO file_download_tokens (file_id, store_id, buyer_id, expires_at)
               VALUES (%s,%s,%s,%s) RETURNING jti""",
            (file_id, store_id, buyer_id, expires),
        ).fetchone(),
        context="created download token",
    )["jti"]

    # Never issue a reusable S3 bearer capability: all access passes through the
    # authenticated atomic redemption endpoint, including bytes retrieval.
    return {"url": f"/files/download/{jti}", "jti": str(jti),
            "expires_at": expires.isoformat(), "ttl_seconds": settings.file_url_ttl_seconds}



def consume_download(conn: Conn, *, jti: str, buyer_id: str, store_id: str) -> dict:
    """استخدام واحد: يقفل الصف، يتحقق من المشتري/المتجر/الصلاحية، ثم يعلّمه مستخدمًا."""
    row = conn.execute(
        """SELECT t.file_id, t.buyer_id, t.store_id, t.expires_at, t.used_at, f.object_key, f.content_type, f.scan_status
             FROM file_download_tokens t JOIN files f ON f.id=t.file_id
            WHERE t.jti=%s FOR UPDATE OF t""",
        (jti,),
    ).fetchone()
    if not row:
        raise UploadRejected("invalid link")
    if str(row["buyer_id"]) != str(buyer_id) or str(row["store_id"]) != str(store_id):
        raise UploadRejected("link not issued for this user")
    if row["scan_status"] != "clean":
        raise UploadRejected("file not available")
    if row["used_at"] is not None:
        raise UploadRejected("link already used")
    if row["expires_at"] < datetime.now(timezone.utc):
        raise UploadRejected("link expired")
    conn.execute("UPDATE file_download_tokens SET used_at=now() WHERE jti=%s", (jti,))
    return {"object_key": row["object_key"], "file_id": str(row["file_id"]),
            "content_type": row["content_type"]}


def read_private_object(key: str) -> bytes:
    from botocore.exceptions import BotoCoreError, ClientError
    try:
        obj = s3_client().get_object(Bucket=get_settings().s3_bucket_private, Key=key)
        stream = obj["Body"]
        try:
            content = stream.read(get_settings().max_upload_bytes + 1)
        finally:
            stream.close()
    except (OSError, BotoCoreError, ClientError):
        raise StorageUnavailable("object retrieval unavailable") from None
    if len(content) > get_settings().max_upload_bytes:
        raise UploadRejected("file too large")
    return bytes(content)
