"""قوالب سياسات قانونية عربية/إنجليزية — تُملأ تلقائيًا مع إشعار."""

LEGAL_TEMPLATES = {
    "privacy_ar": "سياسة الخصوصية لـ {{store_name}} — تاريخ {{date}} — هذه القوالب تُملأ تلقائيًا وليست بديلاً عن مراجعة قانونية.",
    "privacy_en": "Privacy Policy for {{store_name}} — {{date}} — auto-filled, not a substitute for legal review.",
    "terms_ar": "شروط الاستخدام لـ {{store_name}} — {{date}} — راجع محاميك.",
    "refund_ar": "سياسة الاسترداد — حتى 14 يومًا حسب نوع المنتج الرقمي/الفعلي.",
}


def render_legal(key: str, ctx: dict) -> str:
    from .engine import render_template

    tpl = LEGAL_TEMPLATES.get(key, "")
    return render_template(tpl, ctx)
