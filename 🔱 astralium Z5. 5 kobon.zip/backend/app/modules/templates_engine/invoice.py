"""قوالب فواتير — HTML+PDF، ترقيم تسلسلي."""


def render_invoice(order_id: str, items: list, total_minor: int, currency: str = "USD") -> str:
    rows = "".join(f"<tr><td>{it['title']}</td><td>{it['price'] / 100:.2f} {currency}</td></tr>" for it in items)
    return f"""<!doctype html><html><head><meta charset="utf-8"><title>فاتورة {order_id}</title></head><body>
    <h1>فاتورة #{order_id}</h1><table border=1 cellpadding=8><tr><th>المنتج</th><th>السعر</th></tr>{rows}</table>
    <p><strong>الإجمالي: {total_minor / 100:.2f} {currency}</strong></p><p>لا تظهر العمولة للعميل</p></body></html>"""
