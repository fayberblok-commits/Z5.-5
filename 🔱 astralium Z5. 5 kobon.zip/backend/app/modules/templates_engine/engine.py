"""محرك قوالب بلا منطق — قائمة سماح، تنقية، منع SSTI."""

import re
import nh3

ALLOWED_TAGS = {
    "p",
    "h1",
    "h2",
    "h3",
    "h4",
    "div",
    "span",
    "a",
    "ul",
    "ol",
    "li",
    "img",
    "section",
    "header",
    "footer",
    "nav",
    "main",
    "article",
    "strong",
    "em",
    "br",
}
ALLOWED_ATTRS = {"a": {"href", "title"}, "img": {"src", "alt", "width", "height"}}
MAX_HTML = 500 * 1024


def sanitize_html(html: str) -> str:
    if len(html) > MAX_HTML:
        raise ValueError("template too large")
    if re.search(r"<script|on\w+\s*=|javascript:", html, re.I):
        raise ValueError("JS not allowed in templates")
    clean = nh3.clean(html, tags=ALLOWED_TAGS, attributes=ALLOWED_ATTRS, strip_comments=True)
    return clean


def render_template(template: str, context: dict) -> str:
    if "{{" in template and "}}" in template:
        for k, v in context.items():
            if not re.match(r"^[a-zA-Z_][a-zA-Z0-9_]*$", k):
                raise ValueError("bad var name")
            template = template.replace("{{" + k + "}}", str(v))
    if "{{" in template or "{%" in template or "<%" in template:
        raise ValueError("template logic not allowed")
    return sanitize_html(template)


THEMES = {
    "astralium-dark": {
        "name": "Astralium Dark",
        "css": "--gold:#d4af37;--bg:#0a0a0f",
        "pages": [
            "home",
            "catalog",
            "product",
            "cart",
            "checkout",
            "thankyou",
            "account",
            "login",
            "about",
            "contact",
            "faq",
            "blog",
            "landing",
            "404",
            "maintenance",
            "track",
        ],
    },
    "novel-nook": {"name": "Novel Nook", "pages": ["home", "catalog", "product", "cart", "checkout"]},
    "coursecraft": {"name": "Coursecraft", "pages": ["home", "catalog", "product"]},
    "vogue-line": {"name": "Vogue Line", "pages": ["home", "catalog", "product"]},
    "scent-atelier": {"name": "Scent Atelier", "pages": ["home", "catalog", "product"]},
    "circuit-hub": {"name": "Circuit Hub", "pages": ["home", "catalog", "product"]},
    "asset-forge": {"name": "Asset Forge", "pages": ["home", "catalog", "product"]},
    "service-booking": {"name": "Service & Booking", "pages": ["home", "catalog", "product"]},
    "subscribe-pro": {"name": "Subscribe Pro", "pages": ["home", "catalog", "product"]},
}
