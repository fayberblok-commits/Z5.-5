from pydantic import BaseModel, field_validator
from typing import Literal

ProductType = Literal["digital", "physical", "subscription", "course", "service", "gift_card", "bundle", "variant"]


class ProductCreate(BaseModel):
    title: str
    description: str
    type: ProductType = "digital"
    price_minor: int
    currency: str = "USD"
    stock: int | None = None
    sku: str | None = None

    @field_validator("price_minor")
    @classmethod
    def price_ok(cls, v):
        if v < 0:
            raise ValueError("price cannot be negative")
        if v > 1_000_000_00:
            raise ValueError("price too large")
        return v

    @field_validator("title")
    @classmethod
    def title_ok(cls, v):
        if len(v.strip()) < 3:
            raise ValueError("title too short")
        return v.strip()


class ProductOut(ProductCreate):
    id: str
    store_id: str
