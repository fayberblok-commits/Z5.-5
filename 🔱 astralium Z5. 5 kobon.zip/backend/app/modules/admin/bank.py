"""بيانات بنكية — تشفير Envelope + عرض مقنع."""

from app.core.encryption import encrypt_field


def store_bank(kek: bytes, wrapped, iban: str, swift: str, holder: str) -> dict:
    return {
        "iban": encrypt_field(kek, wrapped, iban, "bank:iban"),
        "swift": encrypt_field(kek, wrapped, swift, "bank:swift"),
        "holder": encrypt_field(kek, wrapped, holder, "bank:holder"),
    }


def mask_iban(iban: str) -> str:
    return "****" + iban[-4:] if len(iban) > 4 else "****"
