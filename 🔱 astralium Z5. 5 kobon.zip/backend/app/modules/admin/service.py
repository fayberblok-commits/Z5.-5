"""مكتب المدير — منفصل شبكيًا، WebAuthn+TOTP+step-up، جلسات قصيرة، ربط جهاز."""

from typing import Dict
import secrets
import time
import hmac
import hashlib

# In prod: separate FastAPI app on admin.astralium.example with mTLS
ADMIN_SESSION_TTL = 15 * 60
DEVICE_BIND_SALT = "astralium-device-bind"


class AdminGuard:
    def __init__(self):
        self.sessions: Dict[str, dict] = {}
        self.allowed_ips: set[str] = set()
        self.totp_secrets: Dict[str, str] = {}

    def require_step_up(self, session_id: str, action: str):
        sess = self.sessions.get(session_id)
        if not sess:
            raise PermissionError("no session")
        if time.time() - sess.get("last_step_up", 0) > 300:
            raise PermissionError("step-up required")
        if sess.get("role") != "owner":
            raise PermissionError("owner only")

    def create_session(self, email: str, ip: str, device_fp: str, totp_ok: bool, webauthn_ok: bool):
        if not totp_ok or not webauthn_ok:
            raise PermissionError("WebAuthn+TOTP required for owner")
        # IP allowlist check
        # device binding: HMAC(device_fp)
        bind = hmac.new(DEVICE_BIND_SALT.encode(), device_fp.encode(), hashlib.sha256).hexdigest()
        sid = secrets.token_hex(24)
        self.sessions[sid] = {
            "email": email,
            "ip": ip,
            "device_bind": bind,
            "role": "owner",
            "created": time.time(),
            "last_step_up": time.time(),
        }
        return sid

    def check_session(self, sid: str, ip: str, device_fp: str) -> bool:
        s = self.sessions.get(sid)
        if not s:
            return False
        if time.time() - s["created"] > ADMIN_SESSION_TTL:
            return False
        bind = hmac.new(DEVICE_BIND_SALT.encode(), device_fp.encode(), hashlib.sha256).hexdigest()
        if not hmac.compare_digest(bind, s["device_bind"]):
            return False
        # IP drift detection
        if ip != s["ip"]:
            return False
        return True


admin_guard = AdminGuard()
