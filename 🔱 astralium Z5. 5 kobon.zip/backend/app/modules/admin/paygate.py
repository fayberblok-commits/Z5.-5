"""إدارة بوابات الدفع — Stripe/PayPal/تحويل بنكي يدوي."""

GATEWAYS: dict[str, dict] = {
    "stripe": {"enabled": False, "countries": ["US", "SA"]},
    "paypal": {"enabled": False, "countries": ["US", "DE"]},
    "bank_transfer": {"enabled": False, "countries": ["SA", "EG"]},
}


def toggle(gateway: str, enabled: bool):
    if gateway not in GATEWAYS:
        raise ValueError("unknown gateway")
    GATEWAYS[gateway]["enabled"] = enabled
    return GATEWAYS[gateway]


def check_connection(gateway: str) -> bool:
    # في الإنتاج: ping حقيقي لـ Stripe/PayPal API
    return GATEWAYS.get(gateway, {}).get("enabled", False) or True
