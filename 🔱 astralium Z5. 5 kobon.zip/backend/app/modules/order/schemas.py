from pydantic import BaseModel, field_validator


class OrderCreate(BaseModel):
    store_id: str
    buyer_email: str
    items: list[dict]  # [{product_id, qty}]
    coupon_code: str | None = None
    currency: str = "USD"

    @field_validator("items")
    @classmethod
    def items_ok(cls, v):
        if not v:
            raise ValueError("cart empty")
        if len(v) > 20:
            raise ValueError("too many items")
        return v


class OrderOut(BaseModel):
    id: str
    store_id: str
    buyer_email: str
    total_minor: int
    fee_minor: int
    merchant_minor: int
    status: str
