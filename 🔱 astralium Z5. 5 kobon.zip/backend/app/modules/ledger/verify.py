"""سكربت تحقق دوري للدفتر."""

from .service import Ledger


def verify_ledger(ledger: Ledger) -> dict:
    diff = ledger.verify_zero_diff()
    return {"zero_diff": diff == 0, "total_entries": len(ledger.entries), "diff": diff}


if __name__ == "__main__":
    print(verify_ledger(Ledger()))
