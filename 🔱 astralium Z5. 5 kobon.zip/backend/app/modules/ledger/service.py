"""سياسة العمولة + دفتر في الذاكرة للاختبارات الوحدية فقط.

الدفتر الإنتاجي هو `repository.py` (PostgreSQL). النسخة هنا تحاكي نفس القواعد
وتُستخدم للاختبارات السريعة، لكنها **تحقق فعليًا** — لا تُعيد صفرًا بلا فحص.
"""

from __future__ import annotations

from dataclasses import dataclass

PLATFORM_FEE_CENTS = 200  # 2$ ثابتة (minor units)

ACCOUNTS = {
    "buyer_payment",
    "merchant_receivable",
    "platform_fee",
    "gateway_fee",
    "refund_payable",
    "dispute_hold",
    "platform_earnings",
}


def split_sale(total_cents: int, fee_cents: int = PLATFORM_FEE_CENTS) -> tuple[int, int]:
    """(حصة التاجر، عمولة المنصة) — كلاهما minor units.

    السياسة (ADR-009):
    * total <= 0            → (0, 0)              منتج مجاني: لا حركة مالية.
    * 0 < total < fee       → (0, total)          منتج < 2$: العمولة = كامل المبلغ.
    * total >= fee          → (total - fee, fee)  العمولة 2$ ثابتة.
    """
    if total_cents <= 0:
        return (0, 0)
    if total_cents < fee_cents:
        return (0, total_cents)
    return (total_cents - fee_cents, fee_cents)


@dataclass(frozen=True)
class Entry:
    id: str
    store_id: str
    order_id: str
    account: str
    direction: str
    amount_minor: int
    currency: str
    entry_group: str


class Ledger:
    """دفتر مزدوج في الذاكرة — للاختبارات الوحدية فقط (ليس مسار الإنتاج)."""

    def __init__(self) -> None:
        self.entries: list[Entry] = []
        self._n = 0

    # واجهة متوافقة: post(debit, credit, amount) تُنشئ سطرين داخل مجموعة واحدة
    def post(
        self,
        store_id: str,
        order_id: str,
        debit: str,
        credit: str,
        amount_minor: int,
        currency: str = "USD",
    ) -> Entry:
        if not isinstance(amount_minor, int) or isinstance(amount_minor, bool):
            raise ValueError("amount must be int minor units")
        if amount_minor <= 0:
            raise ValueError("amount must be positive")
        if debit not in ACCOUNTS or credit not in ACCOUNTS:
            raise ValueError("unknown account")
        if debit == credit:
            raise ValueError("debit and credit must differ")
        self._n += 1
        group = f"grp_{self._n}"
        d = self._add(store_id, order_id, debit, "debit", amount_minor, currency, group)
        self._add(store_id, order_id, credit, "credit", amount_minor, currency, group)
        return d

    def _add(
        self,
        store_id: str,
        order_id: str,
        account: str,
        direction: str,
        amount: int,
        currency: str,
        group: str,
    ) -> Entry:
        e = Entry(
            id=f"ent_{len(self.entries) + 1}",
            store_id=store_id,
            order_id=order_id,
            account=account,
            direction=direction,
            amount_minor=amount,
            currency=currency,
            entry_group=group,
        )
        self.entries.append(e)
        return e

    # ---------- تحقق فعلي ----------
    def group_diffs(self) -> dict[str, int]:
        acc: dict[str, int] = {}
        for e in self.entries:
            sign = 1 if e.direction == "debit" else -1
            acc[e.entry_group] = acc.get(e.entry_group, 0) + sign * e.amount_minor
        return acc

    def verify_zero_diff(self) -> int:
        """يعيد أكبر فرق مطلق (بايت/سنت). صفر يعني متوازن فعلًا."""
        diffs = self.group_diffs()
        per_account = {a: self.balance(a) for a in ACCOUNTS}
        total = abs(sum(per_account.values()))
        return max([abs(v) for v in diffs.values()] + [total] + [0])

    def balance(self, account: str) -> int:
        bal = 0
        for e in self.entries:
            if e.account == account:
                bal += e.amount_minor if e.direction == "debit" else -e.amount_minor
        return bal
