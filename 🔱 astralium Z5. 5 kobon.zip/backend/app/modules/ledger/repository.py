"""دفتر مزدوج حقيقي (PostgreSQL) — مدين = دائن، بلا قيد ناقص، بلا تعديل بعد التثبيت.

قواعد صارمة:
* كل قيد مجموعة (entry_group) داخل معاملة واحدة، ويُتحقق من توازنها قبل التثبيت.
* إن انهارت العملية في المنتصف تُلغى المعاملة كاملة (لا قيد ناقص).
* السطور إلزامية append-only (trigger في قاعدة البيانات).
* `verify_balanced()` تحسب فعليًا ولا تُعيد صفرًا بلا فحص.
"""

from __future__ import annotations

import uuid
from collections.abc import Iterable


from ...core.db import Conn, tenant
from ...core.db import one
from .service import split_sale  # noqa: F401  (سياسة العمولة المشتركة)

ACCOUNTS = {
    "buyer_payment",
    "merchant_receivable",
    "platform_fee",
    "gateway_fee",
    "refund_payable",
    "dispute_hold",
    "platform_earnings",
}


class LedgerError(RuntimeError):
    pass


def post_group(
    conn: Conn,
    *,
    store_id: str | uuid.UUID,
    order_id: str | uuid.UUID | None,
    lines: Iterable[tuple[str, str, int]],
    currency: str,
) -> uuid.UUID:
    """يكتب مجموعة قيود ويضمن توازنها. `lines` = (account, direction, amount_minor)."""
    group = uuid.uuid4()
    lines = list(lines)
    if not lines:
        raise LedgerError("empty entry group")
    debits = credits = 0
    for account, direction, amount in lines:
        if account not in ACCOUNTS:
            raise LedgerError(f"unknown account {account!r}")
        if direction not in ("debit", "credit"):
            raise LedgerError(f"bad direction {direction!r}")
        if not isinstance(amount, int) or isinstance(amount, bool) or amount <= 0:
            raise LedgerError("amount must be a positive int (minor units)")
        if direction == "debit":
            debits += amount
        else:
            credits += amount
    if debits != credits:
        raise LedgerError(f"unbalanced group: debit={debits} credit={credits}")

    for account, direction, amount in lines:
        conn.execute(
            """INSERT INTO ledger_entries
                   (entry_group, store_id, order_id, account, direction, amount_minor, currency)
               VALUES (%s,%s,%s,%s,%s,%s,%s)""",
            (group, store_id, order_id, account, direction, amount, currency),
        )
    _assert_group_balanced(conn, group)
    return group


def _assert_group_balanced(conn: Conn, group: uuid.UUID) -> None:
    row = conn.execute(
        """SELECT COALESCE(SUM(CASE WHEN direction='debit' THEN amount_minor END),0) AS d,
                  COALESCE(SUM(CASE WHEN direction='credit' THEN amount_minor END),0) AS c,
                  COUNT(*) AS n
           FROM ledger_entries WHERE entry_group = %s""",
        (group,),
    ).fetchone()
    if row is None or row["n"] == 0 or row["d"] != row["c"]:
        raise LedgerError(f"entry group {group} not balanced at commit time: {row}")


def _store_ids() -> list[str]:
    """قائمة المتاجر — تُقرأ بصلاحيات المالك (جدول stores غير خاضع لـ RLS)."""
    from ...core.db import connect, fetch_all

    with connect(app_role=False) as conn:
        return [str(r["id"]) for r in fetch_all(conn, "SELECT id FROM stores ORDER BY created_at")]


def verify_balanced(store_id: str | uuid.UUID | None = None) -> dict:
    """تحقق فعلي: لكل مجموعة، ولكل عملة. يُرجع الفروق الحقيقية لا صفرًا ثابتًا."""
    stores = [str(store_id)] if store_id else _store_ids()
    bad_groups: list[str] = []
    single_line = 0
    non_positive = 0
    diff: dict[str, int] = {}
    groups_checked = 0
    rows_checked = 0

    for sid in stores:
        with tenant(sid) as conn:
            for row in conn.execute(
                """SELECT entry_group,
                          SUM(CASE WHEN direction='debit' THEN amount_minor ELSE 0 END) AS d,
                          SUM(CASE WHEN direction='credit' THEN amount_minor ELSE 0 END) AS c,
                          COUNT(*) AS n
                     FROM ledger_entries GROUP BY entry_group"""
            ).fetchall():
                groups_checked += 1
                rows_checked += row["n"]
                if row["d"] != row["c"]:
                    bad_groups.append(str(row["entry_group"]))
                if row["n"] < 2:
                    single_line += 1
            for row in conn.execute(
                """SELECT currency,
                          SUM(CASE WHEN direction='debit' THEN amount_minor ELSE 0 END) AS d,
                          SUM(CASE WHEN direction='credit' THEN amount_minor ELSE 0 END) AS c
                     FROM ledger_entries GROUP BY currency"""
            ).fetchall():
                diff[row["currency"]] = diff.get(row["currency"], 0) + (row["d"] - row["c"])
            non_positive += one(
                conn.execute("SELECT COUNT(*) AS n FROM ledger_entries WHERE amount_minor <= 0").fetchone(),
                context="ledger non-positive count",
            )["n"]

    return {
        "balanced": not bad_groups and all(v == 0 for v in diff.values()) and single_line == 0 and non_positive == 0,
        "per_currency_diff": diff,
        "unbalanced_groups": bad_groups,
        "single_line_groups": single_line,
        "non_positive_entries": non_positive,
        "groups_checked": groups_checked,
        "rows_checked": rows_checked,
        "stores_checked": len(stores),
    }


def balance(account: str, store_id: str | uuid.UUID | None = None) -> int:
    """رصيد حساب: مدين - دائن (موجب = أصل/ذمّة لنا)."""
    stores = [str(store_id)] if store_id else _store_ids()
    total = 0
    for sid in stores:
        with tenant(sid) as conn:
            row = one(
                conn.execute(
                    """SELECT COALESCE(SUM(CASE WHEN direction='debit' THEN amount_minor
                                                ELSE -amount_minor END), 0) AS bal
                         FROM ledger_entries WHERE account = %s""",
                    (account,),
                ).fetchone(),
                context="account balance",
            )
        total += int(row["bal"])
    return total


def post_sale(
    conn: Conn,
    *,
    store_id: str | uuid.UUID,
    order_id: str | uuid.UUID,
    gross_minor: int,
    gateway_fee_minor: int,
    currency: str = "USD",
    platform_fee_minor: int = 200,
) -> dict:
    """قيد بيع: مدين buyer_payment بالإجمالي، دائن التاجر/المنصة/البوابة.

    سياسة العمولة: 2$ ثابتة إن كان الإجمالي >= 2$، وإلا كل المبلغ للمنصة
    (منتجات < 2$ والمجانية) — موثقة في ADR-009.
    """
    merchant, fee = split_sale(gross_minor, platform_fee_minor)
    gateway = min(gateway_fee_minor, merchant)
    merchant_net = merchant - gateway
    if gross_minor != fee + gateway + merchant_net:
        raise LedgerError("sale split does not reconcile with gross")

    lines: list[tuple[str, str, int]] = [("buyer_payment", "debit", gross_minor)]
    if fee:
        lines.append(("platform_fee", "credit", fee))
    if gateway:
        lines.append(("gateway_fee", "credit", gateway))
    if merchant_net:
        lines.append(("merchant_receivable", "credit", merchant_net))
    group = post_group(conn, store_id=store_id, order_id=order_id, lines=lines, currency=currency)
    return {
        "entry_group": str(group),
        "gross_minor": gross_minor,
        "platform_fee_minor": fee,
        "gateway_fee_minor": gateway,
        "merchant_net_minor": merchant_net,
    }


def post_refund(
    conn: Conn,
    *,
    store_id: str | uuid.UUID,
    order_id: str | uuid.UUID,
    amount_minor: int,
    fee_refunded_minor: int,
    currency: str = "USD",
    dispute: bool = False,
) -> str:
    """قيد استرداد/نزاع: يعكس مدين التاجر/المنصة إلى refund_payable أو dispute_hold."""
    if amount_minor <= 0:
        raise LedgerError("refund must be positive")
    fee_refunded_minor = max(0, min(fee_refunded_minor, amount_minor))
    merchant_part = amount_minor - fee_refunded_minor
    target = "dispute_hold" if dispute else "refund_payable"
    lines: list[tuple[str, str, int]] = []
    if merchant_part:
        lines.append(("merchant_receivable", "debit", merchant_part))
    if fee_refunded_minor:
        lines.append(("platform_fee", "debit", fee_refunded_minor))
    lines.append((target, "credit", amount_minor))
    group = post_group(conn, store_id=store_id, order_id=order_id, lines=lines, currency=currency)
    return str(group)
