"""تحليلات — مبيعات/زيارات/تحويل/أفضل المنتجات (مجمعة ومنقحة)."""

from collections import Counter

EVENTS: list[dict] = []


def track(event: str, store_id: str, meta: dict | None = None):
    EVENTS.append({"event": event, "store_id": store_id, "meta": meta or {}})


def report(store_id: str) -> dict:
    sales = sum(1 for e in EVENTS if e["event"] == "sale" and e["store_id"] == store_id)
    visits = sum(1 for e in EVENTS if e["event"] == "visit" and e["store_id"] == store_id)
    conv = (sales / visits * 100) if visits else 0
    top = Counter(
        e["meta"].get("product_id") for e in EVENTS if e["event"] == "sale" and e["store_id"] == store_id
    ).most_common(3)
    return {"sales": sales, "visits": visits, "conversion": round(conv, 2), "top_products": top}
