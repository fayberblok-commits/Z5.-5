from pydantic import BaseModel, field_validator
import re


class StoreCreate(BaseModel):
    name: str
    slug: str
    locale: str = "ar"
    currency: str = "USD"
    domain_custom: str | None = None

    @field_validator("slug")
    @classmethod
    def slug_ok(cls, v):
        if not re.match(r"^[a-z0-9-]{3,40}$", v):
            raise ValueError("slug must be 3-40 lowercase a-z0-9-")
        return v

    @field_validator("currency")
    @classmethod
    def cur_ok(cls, v):
        if v not in ("USD", "EUR", "SAR", "AED", "EGP", "GBP"):
            raise ValueError("unsupported currency")
        return v


class StoreOut(StoreCreate):
    id: str
    owner_email: str
    is_active: bool
