"""خدمات وحجوزات — تقويم ومنع تضارب."""

import secrets

BOOKINGS: dict[str, dict] = {}


def book_service(store_id: str, service: str, buyer_email: str, slot: str) -> dict:
    # slot ISO datetime
    for b in BOOKINGS.values():
        if b["slot"] == slot and b["service"] == service:
            raise ValueError("slot taken")
    bid = secrets.token_hex(8)
    BOOKINGS[bid] = {"store_id": store_id, "service": service, "buyer": buyer_email, "slot": slot}
    return {"id": bid, "slot": slot}
