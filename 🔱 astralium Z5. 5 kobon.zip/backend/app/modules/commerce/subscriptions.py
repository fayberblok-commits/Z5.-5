"""اشتراكات — فوترة دورية بـ integers."""

import time
import secrets

SUBS: dict[str, dict] = {}


def create_subscription(store_id: str, buyer_email: str, price_minor: int, interval: str = "month") -> dict:
    if interval not in ("month", "year", "week"):
        raise ValueError("bad interval")
    sid = secrets.token_hex(8)
    SUBS[sid] = {
        "store_id": store_id,
        "buyer": buyer_email,
        "price": price_minor,
        "interval": interval,
        "status": "active",
        "next_bill": int(time.time()) + 30 * 86400,
    }
    return {"id": sid, **SUBS[sid]}


def cancel_subscription(sid: str):
    if sid not in SUBS:
        raise ValueError("not found")
    SUBS[sid]["status"] = "canceled"
    return SUBS[sid]
