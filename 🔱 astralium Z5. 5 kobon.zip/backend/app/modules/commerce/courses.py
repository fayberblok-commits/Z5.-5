"""دورات — وصول تدريجي، تقدم."""

COURSES: dict[str, dict] = {}


def create_course(store_id: str, title: str, lessons: list[str]) -> dict:
    import secrets

    cid = secrets.token_hex(8)
    COURSES[cid] = {"store_id": store_id, "title": title, "lessons": lessons, "enrollments": {}}
    return {"id": cid, "title": title}


def enroll(course_id: str, buyer_email: str):
    COURSES[course_id]["enrollments"][buyer_email] = 0


def progress(course_id: str, buyer_email: str, lesson: int):
    COURSES[course_id]["enrollments"][buyer_email] = lesson
    return lesson
