"""بطاقات هدية — رصيد integers، استرداد آمن."""

import secrets

CARDS: dict[str, dict] = {}


def issue_card(amount_minor: int, currency: str = "USD") -> dict:
    code = secrets.token_hex(8).upper()
    CARDS[code] = {"amount": amount_minor, "currency": currency, "balance": amount_minor}
    return {"code": code, **CARDS[code]}


def redeem(code: str, amount_minor: int) -> int:
    c = CARDS.get(code)
    if not c:
        raise ValueError("invalid card")
    if c["balance"] < amount_minor:
        raise ValueError("insufficient balance")
    c["balance"] -= amount_minor
    return c["balance"]
