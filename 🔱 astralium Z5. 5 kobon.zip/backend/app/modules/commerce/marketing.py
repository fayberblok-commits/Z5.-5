"""تسويق — كوبونات، خصومات، سلال متروكة، شريط إعلان، SEO."""

import re

COUPONS: dict[str, dict] = {}


def create_coupon(code: str, discount_minor: int, max_uses: int = 100):
    if not re.match(r"^[A-Z0-9-]{4,20}$", code):
        raise ValueError("bad coupon")
    COUPONS[code] = {"discount": discount_minor, "uses": 0, "max": max_uses}
    return COUPONS[code]


def apply_coupon(code: str, amount_minor: int) -> int:
    c = COUPONS.get(code)
    if not c:
        raise ValueError("coupon not found")
    if c["uses"] >= c["max"]:
        raise ValueError("coupon exhausted")
    # race condition protection: atomic increment in prod (Redis INCR)
    c["uses"] += 1
    return max(0, amount_minor - c["discount"])


def seo_meta(title: str, description: str) -> dict:
    return {
        "title": title[:60],
        "description": description[:160],
        "og_title": title,
        "og_description": description,
        "sitemap": "/sitemap.xml",
    }
