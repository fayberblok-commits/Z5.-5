"""ضرائب وشحن — حسب الدولة."""

TAX_RATES = {"SA": 0.15, "AE": 0.05, "EG": 0.14, "US-CA": 0.0725, "DE": 0.19}
SHIPPING_ZONES = {"MENA": 500, "EU": 800, "US": 1000, "WORLD": 1500}  # cents


def calc_tax(amount_minor: int, country: str) -> int:
    rate = TAX_RATES.get(country, 0)
    return int(amount_minor * rate)


def shipping_cost(zone: str) -> int:
    return SHIPPING_ZONES.get(zone, 1500)
