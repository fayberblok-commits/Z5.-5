"""سلال متروكة ونشرات."""

CARTS: dict[str, dict] = {}


def save_cart(cart_id: str, store_id: str, items: list, email: str | None = None):
    import time

    CARTS[cart_id] = {"store_id": store_id, "items": items, "email": email, "ts": int(time.time())}


def abandoned(hours: int = 2) -> list[str]:
    import time

    now = int(time.time())
    return [k for k, v in CARTS.items() if now - v["ts"] > hours * 3600 and not v.get("converted")]
