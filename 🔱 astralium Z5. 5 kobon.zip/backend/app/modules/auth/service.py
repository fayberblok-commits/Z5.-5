"""المصادقة والجلسات — Argon2id، قفل تدريجي، تدوير جلسات، TOTP، ربط جهاز.

قواعد:
* كلمة المرور: ≥12 حرفًا مع أحرف كبيرة/صغيرة/رقم، Argon2id، وإعادة تجزئة تلقائية.
* لا تعداد حسابات: نفس الرد/نفس الزمن تقريبًا لحالة «مستخدم غير موجود».
* قفل تدريجي بعد `login_max_attempts` لمدة `login_lockout_minutes`.
* الجلسة: توكن عشوائي 32 بايت يُخزَّن كـ SHA-256 فقط، مرتبط ببصمة الجهاز،
  ينتهي بعد `session_ttl_minutes`، ويُدوَّر عند الاستخدام الحسّاس.
* JWT للوصول فقط مع `jti` قابل للإبطال (جدول revoked_jtis).
"""

from __future__ import annotations

import base64
import hashlib
import hmac
import os
import re
import secrets
import uuid
from datetime import datetime, timedelta, timezone

import jwt
import pyotp
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

from ...core.audit import audit_append
from ...core.config import get_settings
from ...core.db import Conn, atomic
from ...core.db import one
from ...core.security import hash_password, needs_rehash, ph, verify_password

_EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[A-Za-z]{2,}$")
MAX_SESSION_PER_ACCOUNT = 10


class AuthError(RuntimeError):
    def __init__(self, message: str, status: int = 401) -> None:
        super().__init__(message)
        self.status = status


# ------------------------------------------------------------------ helpers
def normalize_email(email: str) -> str:
    email = email.strip().lower()
    if not _EMAIL_RE.match(email) or len(email) > 254:
        raise AuthError("invalid email", status=400)
    return email


def hash_token(token: str) -> str:
    return hashlib.sha256(token.encode()).hexdigest()


def device_fingerprint(user_agent: str, accept_language: str, client_hint: str) -> str:
    raw = f"{user_agent}|{accept_language}|{client_hint}"
    return hashlib.sha256(raw.encode()).hexdigest()


def _kek() -> bytes:
    raw = get_settings().encryption_kek.get_secret_value()
    return hashlib.sha256(raw.encode()).digest()


def encrypt_secret(plaintext: str, context: str) -> str:
    nonce = os.urandom(12)
    ct = AESGCM(_kek()).encrypt(nonce, plaintext.encode(), context.encode())
    return base64.b64encode(nonce + ct).decode()


def decrypt_secret(blob: str, context: str) -> str:
    raw = base64.b64decode(blob)
    nonce, ct = raw[:12], raw[12:]
    return AESGCM(_kek()).decrypt(nonce, ct, context.encode()).decode()


def _now() -> datetime:
    return datetime.now(timezone.utc)


# ------------------------------------------------------------------ register
def register(conn: Conn, *, email: str, password: str, store_name: str, role: str = "merchant") -> dict:
    email = normalize_email(email)
    if role not in ("merchant", "buyer"):
        raise AuthError("role not self-assignable", status=403)
    try:
        pw_hash = hash_password(password)
    except ValueError as exc:  # كلمة مرور ضعيفة → 400 لا 500
        raise AuthError(f"weak password: {exc}", status=400) from exc

    exists = conn.execute("SELECT 1 FROM accounts WHERE lower(email)=%s", (email,)).fetchone()
    if exists:
        # لا نكشف وجود الحساب: نفس زمن الاستجابة تقريبًا
        ph.hash(password)
        raise AuthError("registration failed", status=400)

    store_id = None
    account = one(
        conn.execute(
            """INSERT INTO accounts (email, password_hash, role) VALUES (%s,%s,%s) RETURNING id""",
            (email, pw_hash, role),
        ).fetchone(),
        context="created account",
    )
    if role == "merchant":
        store = conn.execute(
            "INSERT INTO stores (name, owner_id) VALUES (%s,%s) RETURNING id",
            (store_name.strip()[:120] or "My Store", account["id"]),
        ).fetchone()
        store_id = one(store, context="created store")["id"]
        conn.execute("UPDATE accounts SET store_id=%s WHERE id=%s", (store_id, account["id"]))
    # لا نكتب أبدًا أي مادة سرية في سجل التدقيق: لا كلمة مرور ولا هاش ولا توكن.
    audit_append(conn, actor=email, action="register", resource="account", store_id=store_id,
                 meta={"role": role})
    return {"account_id": str(account["id"]), "store_id": str(store_id) if store_id else None, "role": role}


# ------------------------------------------------------------------ login
def login(
    conn: Conn,
    *,
    email: str,
    password: str,
    user_agent: str = "",
    accept_language: str = "",
    client_hint: str = "",
    totp_code: str | None = None,
) -> dict:
    settings = get_settings()
    email = normalize_email(email)
    acct = conn.execute(
        """SELECT id, email, password_hash, role, store_id, failed_logins, locked_until, totp_secret_enc
             FROM accounts WHERE lower(email)=%s""",
        (email,),
    ).fetchone()

    if acct is None:
        # تكافؤ زمني مع حالة «مستخدم غير موجود» — ليست كلمة مرور مخزّنة
        verify_password(ph.hash("dummy-password-for-timing-Aa1"), password)  # nosec B105
        raise AuthError("invalid credentials")

    locked_until = acct["locked_until"]
    if locked_until and locked_until > _now():
        raise AuthError("account temporarily locked", status=423)

    if not verify_password(acct["password_hash"], password):
        fails = int(acct["failed_logins"]) + 1
        lock_until = None
        if fails >= settings.login_max_attempts:
            lock_until = _now() + timedelta(minutes=settings.login_lockout_minutes)
            fails = 0  # يُصفَّر بعد القفل، مع الاحتفاظ بمدة القفل
        conn.execute(
            "UPDATE accounts SET failed_logins=%s, locked_until=%s WHERE id=%s",
            (fails, lock_until, acct["id"]),
        )
        audit_append(conn, actor=email, action="login_failed", resource="account",
                     meta={"attempts": fails, "locked": bool(lock_until)}, result="denied")
        raise AuthError("invalid credentials")

    if acct["totp_secret_enc"]:
        if not totp_code:
            raise AuthError("totp required", status=401)
        if not verify_totp(acct["totp_secret_enc"], totp_code, str(acct["id"])):
            audit_append(conn, actor=email, action="totp_failed", resource="account", result="denied")
            raise AuthError("invalid totp", status=401)

    # نجاح: تصفير المحاولات + إعادة تجزئة إن تغيّرت المعايير
    conn.execute("UPDATE accounts SET failed_logins=0, locked_until=NULL WHERE id=%s", (acct["id"],))
    if needs_rehash(acct["password_hash"]):
        conn.execute("UPDATE accounts SET password_hash=%s WHERE id=%s", (ph.hash(password), acct["id"]))

    session = create_session(
        conn,
        account_id=str(acct["id"]),
        user_agent=user_agent,
        accept_language=accept_language,
        client_hint=client_hint,
    )
    audit_append(conn, actor=email, action="login", resource="account",
                 store_id=str(acct["store_id"]) if acct["store_id"] else None,
                 meta={"role": acct["role"], "session": session["session_id"]})
    return {
        "session_token": session["token"],
        "session_id": session["session_id"],
        "role": acct["role"],
        "store_id": str(acct["store_id"]) if acct["store_id"] else None,
        "account_id": str(acct["id"]),
    }


def create_session(conn: Conn, *, account_id: str, user_agent: str, accept_language: str,
                   client_hint: str, rotated_from: str | None = None) -> dict:
    settings = get_settings()
    token = secrets.token_urlsafe(32)
    fp = device_fingerprint(user_agent, accept_language, client_hint)
    expires = _now() + timedelta(minutes=settings.session_ttl_minutes)
    row = one(
        conn.execute(
            """INSERT INTO sessions (account_id, token_hash, device_fp_hash, expires_at, rotated_from)
               VALUES (%s,%s,%s,%s,%s) RETURNING id""",
            (account_id, hash_token(token), fp, expires, rotated_from),
        ).fetchone(),
        context="created session",
    )
    # حدّ أقصى للجلسات المتزامنة: نُبطل الأقدم
    conn.execute(
        """UPDATE sessions SET revoked_at=now()
            WHERE account_id=%s AND revoked_at IS NULL
              AND id NOT IN (SELECT id FROM sessions WHERE account_id=%s
                              ORDER BY created_at DESC LIMIT %s)""",
        (account_id, account_id, MAX_SESSION_PER_ACCOUNT),
    )
    return {"token": token, "session_id": str(row["id"]), "expires_at": expires.isoformat()}


# ------------------------------------------------------------------ resolve
def resolve_session(
    conn: Conn,
    *,
    token: str,
    user_agent: str = "",
    accept_language: str = "",
    client_hint: str = "",
    rotate: bool = False,
) -> dict:
    settings = get_settings()
    row = conn.execute(
        """SELECT s.id, s.account_id, s.device_fp_hash, s.expires_at, s.revoked_at,
                  a.email, a.role, a.store_id
             FROM sessions s JOIN accounts a ON a.id = s.account_id
            WHERE s.token_hash=%s""",
        (hash_token(token),),
    ).fetchone()
    if not row or row["revoked_at"] or row["expires_at"] < _now():
        raise AuthError("session invalid or expired")
    fp = device_fingerprint(user_agent, accept_language, client_hint)
    if not hmac.compare_digest(fp, row["device_fp_hash"]):
        conn.execute("UPDATE sessions SET revoked_at=now() WHERE id=%s", (row["id"],))
        raise AuthError("device mismatch — session revoked")

    conn.execute("UPDATE sessions SET last_used_at=now() WHERE id=%s", (row["id"],))
    result = {
        "session_id": str(row["id"]),
        "account_id": str(row["account_id"]),
        "email": row["email"],
        "role": row["role"],
        "store_id": str(row["store_id"]) if row["store_id"] else None,
    }
    if rotate:
        conn.execute("UPDATE sessions SET revoked_at=now() WHERE id=%s", (row["id"],))
        new = create_session(
            conn,
            account_id=str(row["account_id"]),
            user_agent=user_agent,
            accept_language=accept_language,
            client_hint=client_hint,
            rotated_from=str(row["id"]),
        )
        result["rotated_token"] = new["token"]
        result["session_id"] = new["session_id"]
    _ = settings
    return result


def revoke_session(conn: Conn, session_id: str) -> None:
    conn.execute("UPDATE sessions SET revoked_at=now() WHERE id=%s", (session_id,))


def revoke_all_sessions(conn: Conn, account_id: str) -> int:
    cur = conn.execute(
        "UPDATE sessions SET revoked_at=now() WHERE account_id=%s AND revoked_at IS NULL", (account_id,)
    )
    return cur.rowcount


# ------------------------------------------------------------------ step-up
def mark_step_up(conn: Conn, session_id: str) -> None:
    conn.execute("UPDATE sessions SET step_up_at=now() WHERE id=%s", (session_id,))


def require_step_up(conn: Conn, session_id: str, ttl_seconds: int | None = None) -> None:
    settings = get_settings()
    ttl = ttl_seconds or settings.step_up_ttl_seconds
    row = conn.execute("SELECT step_up_at, revoked_at FROM sessions WHERE id=%s", (session_id,)).fetchone()
    if not row or row["revoked_at"] or not row["step_up_at"]:
        raise AuthError("step-up authentication required", status=403)
    if (_now() - row["step_up_at"]).total_seconds() > ttl:
        raise AuthError("step-up expired", status=403)


# ------------------------------------------------------------------ TOTP
def enroll_totp(conn: Conn, account_id: str, email: str) -> dict:
    secret = pyotp.random_base32()
    conn.execute(
        "UPDATE accounts SET totp_secret_enc=%s, totp_confirmed_at=NULL WHERE id=%s",
        (encrypt_secret(secret, f"totp:{account_id}"), account_id),
    )
    uri = pyotp.TOTP(secret).provisioning_uri(name=email, issuer_name="Astralium Fibonix")
    return {"otpauth_uri": uri, "secret": secret}


def confirm_totp(conn: Conn, account_id: str, code: str) -> bool:
    row = conn.execute("SELECT totp_secret_enc FROM accounts WHERE id=%s", (account_id,)).fetchone()
    if not row or not row["totp_secret_enc"]:
        raise AuthError("totp not enrolled", status=400)
    secret = decrypt_secret(row["totp_secret_enc"], f"totp:{account_id}")
    if not pyotp.TOTP(secret).verify(code, valid_window=1):
        raise AuthError("invalid totp code", status=401)
    conn.execute("UPDATE accounts SET totp_confirmed_at=now() WHERE id=%s", (account_id,))
    audit_append(conn, actor=account_id, action="totp_confirmed", resource="account")
    return True


def verify_totp(blob: str, code: str, account_id: str) -> bool:
    secret = decrypt_secret(blob, f"totp:{account_id}")
    return pyotp.TOTP(secret).verify(code, valid_window=1)


# ------------------------------------------------------------------ JWT
def issue_access_token(conn: Conn, *, account_id: str, role: str, store_id: str | None) -> dict:
    settings = get_settings()
    jti = uuid.uuid4().hex
    exp = _now() + timedelta(minutes=settings.access_token_ttl_minutes)
    token = jwt.encode(
        {"sub": account_id, "role": role, "store_id": store_id, "jti": jti,
         "iat": _now(), "exp": exp, "iss": settings.app_base_url},
        settings.jwt_secret.get_secret_value(),
        algorithm="HS256",
    )
    return {"access_token": token, "jti": jti, "expires_at": exp.isoformat()}


def decode_access_token(conn: Conn, token: str) -> dict:
    settings = get_settings()
    try:
        payload = jwt.decode(
            token,
            settings.jwt_secret.get_secret_value(),
            algorithms=["HS256"],
            issuer=settings.app_base_url,
            options={"require": ["exp", "sub"]},
        )
    except jwt.InvalidTokenError as exc:
        raise AuthError("invalid token") from exc
    revoked = conn.execute("SELECT 1 FROM revoked_jtis WHERE jti=%s", (payload.get("jti"),)).fetchone()
    if revoked:
        raise AuthError("token revoked")
    return payload


def revoke_jti(conn: Conn, jti: str, exp_epoch: int) -> None:
    conn.execute(
        "INSERT INTO revoked_jtis (jti, expires_at) VALUES (%s, to_timestamp(%s)) ON CONFLICT DO NOTHING",
        (jti, exp_epoch),
    )


def admin_ip_allowed(client_ip: str) -> bool:
    allowed = get_settings().allowed_admin_ips()
    return client_ip in allowed


def with_auth(fn):
    """ديكوريتر مساعد للاختبارات: يفتح معاملة ويحوّل AuthError إلى رد منظم."""

    def wrapper(*args, **kwargs):
        with atomic() as conn:
            return fn(conn, *args, **kwargs)

    return wrapper
