"""فريق المتجر — أدوار مخصصة بصلاحيات دقيقة."""

from typing import Dict, Set

STAFF: Dict[str, Set[str]] = {}  # email -> permissions set


def add_staff(email: str, perms: Set[str]):
    STAFF[email] = perms


def can_staff(email: str, perm: str) -> bool:
    return perm in STAFF.get(email, set())


def list_staff() -> Dict[str, Set[str]]:
    return STAFF
