"""دورة حياة الطلب — حالات متعددة، استرداد، نزاع، تسليم رقمي."""

from app.modules.files.service import sign_url

STATES = ["pending", "paid", "fulfilled", "shipped", "delivered", "refunded", "disputed", "canceled"]
TRANSITIONS = {
    "pending": ["paid", "canceled"],
    "paid": ["fulfilled", "refunded", "disputed", "shipped"],
    "fulfilled": ["delivered"],
    "shipped": ["delivered"],
    "delivered": [],
    "refunded": [],
    "disputed": ["refunded", "delivered"],
    "canceled": [],
}


def can_transition(frm: str, to: str) -> bool:
    return to in TRANSITIONS.get(frm, [])


# تسليم رقمي بروابط موقعة

def deliver_digital(store_id: str, order_id: str, buyer_email: str, file_key: str, secret: str) -> str:
    return sign_url(secret, "private-uploads", file_key, buyer_email, 600)
