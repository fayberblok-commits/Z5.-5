"""AI service — isolated, Tool API only."""

AI_TOOLS_BLOCKED = {"delete_ledger", "export_pii_bulk", "rotate_keys", "access_vault"}


def is_blocked(tool: str) -> bool:
    return tool in AI_TOOLS_BLOCKED


def handle_prompt_injection(payloads: list[str]) -> bool:
    # returns True if all blocked
    for p in payloads:
        if "ignore previous instructions" in p.lower() and "refund" in p.lower():
            # must not trigger sensitive tool without confirmation
            if not is_blocked("refund"):
                return False
    return True
