"""طبقة تجريد مزودين — OpenAI / Anthropic / Meta Llama عبر Together.ai، موثقة رسميًا."""

from typing import Dict, Literal

Provider = Literal["openai", "anthropic", "meta"]


class ProviderAdapter:
    def __init__(self, name: Provider, api_key_env: str):
        self.name = name
        self.api_key_env = api_key_env
        self.usage_cents: int = 0
        self.daily_limit_cents = 5000  # 50$
        self.monthly_limit_cents = 50000

    def check_limits(self, cost_cents: int):
        if self.usage_cents + cost_cents > self.daily_limit_cents:
            raise RuntimeError(f"daily limit exceeded for {self.name}")
        self.usage_cents += cost_cents

    def generate(self, prompt: str, max_tokens=500) -> str:
        # In prod: real SDK calls with official docs
        # openai: client.chat.completions.create(model="gpt-4o", ...)
        # anthropic: client.messages.create(model="claude-3-5-sonnet-20241022", ...)
        # meta: together client with meta-llama/Meta-Llama-3.1-70B-Instruct-Turbo
        # Here: stub that returns safe placeholder, but counts cost
        self.check_limits(10)
        return f"[{self.name} generated] {prompt[:80]} — safe content"

    def mask_key(self, key: str) -> str:
        return "****" + key[-4:] if len(key) > 8 else "****"


providers: Dict[Provider, ProviderAdapter] = {
    "openai": ProviderAdapter("openai", "OPENAI_API_KEY"),
    "anthropic": ProviderAdapter("anthropic", "ANTHROPIC_API_KEY"),
    "meta": ProviderAdapter("meta", "TOGETHER_API_KEY"),
}

emergency_stop = False


def trigger_stop():
    global emergency_stop
    emergency_stop = True


def is_stopped():
    return emergency_stop
