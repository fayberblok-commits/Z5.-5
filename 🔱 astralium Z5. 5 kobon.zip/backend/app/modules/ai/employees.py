"""موظفو AI المحددون — 5 للمدير + 7 للعملاء."""

MANAGER_EMPLOYEES = [
    "مساعد التصميم",
    "مساعد الأخطاء (سجلات منقحة)",
    "مساعد الكود (يقترح فقط)",
    "مساعد المصاريف (مجمع)",
    "مساعد المدفوعات (حالة مجمعة)",
]
MERCHANT_EMPLOYEES = [
    "مساعد القوالب",
    "مساعد المنتجات",
    "مساعد التسويق",
    "مساعد الكتب",
    "مساعد الفيديو",
    "مساعد الإعداد",
    "مساعد الدعم",
]


def list_employees(scope: str) -> list[str]:
    return MANAGER_EMPLOYEES if scope == "manager" else MERCHANT_EMPLOYEES


def generate_book_outline(topic: str) -> dict:
    return {"title": f"كتاب {topic}", "chapters": ["مقدمة", "الفصل 1", "الخاتمة"]}


def generate_video_script(topic: str) -> str:
    return f"فيديو ترويجي عن {topic} — 30 ثانية — فحص أمني قبل الحفظ"
