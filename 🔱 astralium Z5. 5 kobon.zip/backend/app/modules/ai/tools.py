"""أدوات AI — تصنيف المخاطر + سياسة افتراضية بالرفض (default-deny).

قاعدة أساسية: أي أداة غير مسجّلة في ``TOOLS`` تُرفض. لا يوجد مسار "افتراضي مسموح".
"""

from __future__ import annotations

import re
import unicodedata
from typing import Dict, Literal

ToolRisk = Literal["read", "draft", "sensitive", "blocked"]

TOOLS: Dict[str, ToolRisk] = {
    "read_catalog": "read",
    "read_faq": "read",
    "draft_product_description": "draft",
    "draft_campaign": "draft",
    "draft_template": "draft",
    "generate_book": "draft",
    "generate_video": "draft",
    # sensitive — تتطلب تأكيدًا بشريًا + step-up
    "send_bulk_email": "sensitive",
    "bulk_price_update": "sensitive",
    "delete_product": "sensitive",
    "refund_order": "sensitive",
    "update_payment_settings": "sensitive",
    # blocked forever — لا يوجد أي دور أو تأكيد يسمح بها
    "delete_ledger": "blocked",
    "export_pii_bulk": "blocked",
    "rotate_keys": "blocked",
    "access_vault": "blocked",
    "read_audit_log": "blocked",
    "access_bank_account": "blocked",
}

# الأدوار التي يجوز لها تشغيل أدوات "sensitive" بعد التأكيد + step-up
_HUMAN_ROLES = {"owner", "admin", "merchant"}


def normalize_tool_name(tool: str) -> str:
    """توحيد اسم الأداة: منع الالتفاف عبر حالة الأحرف/المسافات/محارف العرض الصفري."""
    if not isinstance(tool, str):
        return ""
    cleaned = unicodedata.normalize("NFKC", tool)
    cleaned = "".join(ch for ch in cleaned if unicodedata.category(ch) != "Cf")
    # توحيد الفواصل: الشرطة السفلية/المائلة/الشرطة العادية كلها نفس الفاصل
    cleaned = re.sub(r"[\s/\-]+", "_", cleaned.strip())
    return cleaned.lower().strip("_")


def can_execute(tool: str, role: str, confirmed: bool = False, step_up: bool = False) -> bool:
    """سياسة الرفض الافتراضي.

    - ``blocked``: رفض دائم.
    - ``sensitive``: تحتاج تأكيدًا + step-up + دورًا بشريًا (لا ``ai_service``).
    - ``read``/``draft``: مسموحة للبشر ولوكيل AI.
    - أي اسم غير مسجّل (بما فيه التمويه بحالة الأحرف) → رفض.
    """
    name = normalize_tool_name(tool)
    risk = TOOLS.get(name)
    if risk is None:
        return False
    if risk == "blocked":
        return False
    if risk == "sensitive":
        if not (confirmed and step_up):
            return False
        if role not in _HUMAN_ROLES:
            return False
        return True
    # read/draft فقط
    return role in _HUMAN_ROLES or role == "ai_service"


# ---------------------------------------------------------------- كشف الحقن
_ZERO_WIDTH_RE = re.compile(r"[\u200b-\u200f\u202a-\u202e\u2060-\u206f\ufeff]")
_TRIGGER_PATTERNS = [
    r"ignore\s+(\w+\s+){0,3}(previous|prior|above|all)\s+(\w+\s+){0,2}(instruction|rule|polic)",
    r"disregard\s+(\w+\s+){0,3}(instruction|rule|polic)",
    r"system\s*(prompt|message)?\s*:",
    r"you\s+are\s+now\s+(an?\s+)?(admin|owner|root|developer)",
    r"reveal\s+(\w+\s+){0,2}(secret|credential|key|token)",
    r"(print|dump|show|export)\s+(\w+\s+){0,2}(secret|api[\s_-]?key|vault)",
    r"exfiltrat",
    r"delete\s+(all\s+)?(the\s+)?(ledger|audit|log|product|order)",
    r"refund\s+(all|every|كل)",
    r"rotate[_\s-]?keys",
    r"access[_\s-]?vault",
    r"export[_\s-]?pii",
    r"bypass\s+(\w+\s+){0,2}(confirmation|step[-\s]?up|rbac|approval)",
    # عربي
    r"(أهمل|تجاهل|تجاوز)\s+(\w+\s+){0,3}(التعليمات|القواعد|السياسات)",
    r"(اكشف|أظهر|اطبع)\s+(\w+\s+){0,3}(الأسرار|المفاتيح|كلمة\s+المرور)",
    r"(احذف|امسح)\s+(\w+\s+){0,3}(الدفتر|السجل|كل\s+المنتجات)",
    r"(حوّل|أرسل)\s+(\w+\s+){0,3}(كل\s+الأموال|كل\s+العملاء)",
]
_COMPILED = [re.compile(p) for p in _TRIGGER_PATTERNS]


def _canonical(text: str) -> str:
    """تطبيع: NFKC (يطوي المحارف كاملة العرض/الأرقام)، إزالة المحارف الخفية، ضغط المسافات."""
    if not isinstance(text, str):
        return ""
    t = unicodedata.normalize("NFKC", text)
    t = _ZERO_WIDTH_RE.sub("", t)
    t = t.casefold()
    # إزالة التشكيل العربي
    t = "".join(ch for ch in t if not ("\u064b" <= ch <= "\u0652"))
    # "i g n o r e" -> "ignore" (تمويه بأحرف متباعدة)
    t = re.sub(r"(?<=\w)\s(?=\w)", "", t) if re.search(r"\b(?:\w\s){3,}\w\b", t) else t
    return re.sub(r"\s+", " ", t).strip()


def is_injection(text: str) -> bool:
    """كشف حقن التعليمات بعد التطبيع (محارف خفية/كاملة العرض/متباعدة/عربية)."""
    canon = _canonical(text)
    if not canon:
        return False
    return any(p.search(canon) for p in _COMPILED)
