"""الحارس — مراقبة سلامة، كشف شذوذ، honeytokens، استجابة آلية."""

import hashlib
import time
from typing import List, Dict
from pathlib import Path


class FileIntegrity:
    def __init__(self, root: Path):
        self.root = root
        self.baseline: Dict[str, str] = {}

    def snapshot(self):
        for p in self.root.rglob("*.py"):
            self.baseline[str(p)] = hashlib.sha256(p.read_bytes()).hexdigest()

    def verify(self) -> list[str]:
        tampered = []
        for path, h in self.baseline.items():
            try:
                cur = hashlib.sha256(Path(path).read_bytes()).hexdigest()
                if cur != h:
                    tampered.append(path)
            except FileNotFoundError:
                tampered.append(f"missing:{path}")
        return tampered


class AnomalyDetector:
    def __init__(self):
        self.login_fail: Dict[str, int] = {}
        self.download_counts: Dict[str, int] = {}

    def record_login_fail(self, ip: str):
        self.login_fail[ip] = self.login_fail.get(ip, 0) + 1
        return self.login_fail[ip]

    def is_bruteforce(self, ip: str) -> bool:
        return self.login_fail.get(ip, 0) >= 5

    def record_download(self, buyer: str):
        c = self.download_counts.get(buyer, 0) + 1
        self.download_counts[buyer] = c
        return c > 20  # abnormal bulk


class Honeytokens:
    def __init__(self):
        self.tokens: Dict[str, str] = {"honey_admin@example.com": "trap", "sk_test_honey_1234567890abcdef": "trap"}
        self.alerts: List[dict] = []

    def touch(self, identifier: str):
        if identifier in self.tokens:
            self.alerts.append({"ts": int(time.time()), "token": identifier, "action": "honeytoken touched"})
            return True
        return False


class AutoResponse:
    def __init__(self, detector: AnomalyDetector, honey: Honeytokens):
        self.detector = detector
        self.honey = honey
        self.frozen_stores: set[str] = set()
        self.revoked_sessions: set[str] = set()

    def on_event(self, event: dict):
        if event.get("type") == "bruteforce":
            self.revoked_sessions.add(event["ip"])
        if event.get("type") == "honey":
            self.frozen_stores.add(event.get("store_id", "unknown"))
            # rotate keys signal
        return {"frozen": list(self.frozen_stores), "revoked": list(self.revoked_sessions)}


# Global
detector = AnomalyDetector()
honey = Honeytokens()
responder = AutoResponse(detector, honey)
integrity = FileIntegrity(Path("."))
