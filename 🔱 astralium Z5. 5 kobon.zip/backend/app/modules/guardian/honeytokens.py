"""Honeytokens — حسابات/مفاتيح وهمية مراقبة."""

HONEY_ACCOUNTS = {"honey_admin@astralium.local", "trap_user@example.com"}
HONEY_KEYS = {"sk_test_honey_51H1234567890abcdef", "whsec_honey_1234567890abcdef"}


def check_honey(identifier: str) -> bool:
    return identifier in HONEY_ACCOUNTS or identifier in HONEY_KEYS
