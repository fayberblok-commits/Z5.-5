"""مكتبة وسائط ومساحات مشاريع."""

import secrets
import time

MEDIA: dict[str, dict] = {}
PROJECTS: dict[str, dict] = {}


def upload_media(store_id: str, filename: str, size: int, mime: str) -> dict:
    key = f"{store_id}/{secrets.token_hex(8)}_{filename}"
    MEDIA[key] = {"store_id": store_id, "filename": filename, "size": size, "mime": mime, "ts": int(time.time())}
    return {"key": key}


def create_project(store_id: str, name: str) -> dict:
    pid = secrets.token_hex(8)
    PROJECTS[pid] = {"store_id": store_id, "name": name, "templates": [], "created": int(time.time())}
    return {"id": pid, "name": name}
