"""تهيئة قاعدة البيانات: ينشئ دور التطبيق (غير مالك، RLS مفعّل) ثم يشغّل الترحيلات.

يُشغَّل مرة واحدة بصلاحيات المالك. لا كلمات مرور ثابتة: تُقرأ من البيئة.
"""
from __future__ import annotations

import os
import sys

import psycopg
from psycopg import sql


def main() -> int:
    owner_url = os.environ.get("DATABASE_URL")
    app_password = os.environ.get("DATABASE_APP_PASSWORD")
    role = os.environ.get("DATABASE_APP_ROLE", "fibonix_app")
    if not owner_url or not app_password:
        print("DATABASE_URL and DATABASE_APP_PASSWORD are required", file=sys.stderr)
        return 2
    if len(app_password) < 24:
        print("DATABASE_APP_PASSWORD must be >= 24 chars", file=sys.stderr)
        return 3

    with psycopg.connect(owner_url, autocommit=True) as conn:
        exists = conn.execute("SELECT 1 FROM pg_roles WHERE rolname = %s", (role,)).fetchone()
        role_id = sql.Identifier(role)
        if not exists:
            # NOBYPASSRLS + NOSUPERUSER: الدور لا يستطيع تجاوز سياسات العزل
            conn.execute(sql.SQL("CREATE ROLE {} LOGIN NOSUPERUSER NOBYPASSRLS NOCREATEDB NOCREATEROLE").format(role_id))
        conn.execute(sql.SQL("ALTER ROLE {} PASSWORD {}").format(role_id, sql.Literal(app_password)))
        conn.execute(sql.SQL("GRANT CONNECT ON DATABASE {} TO {}").format(sql.Identifier(conn.info.dbname), role_id))
        print(f"role {role} ready (NOSUPERUSER, NOBYPASSRLS)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
