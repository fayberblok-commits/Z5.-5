"""نسخ احتياطي مشفر immutable + تمرين استعادة."""

import pathlib
import datetime

BACKUP_DIR = "/backups"


def backup():
    ts = datetime.datetime.utcnow().strftime("%Y%m%dT%H%M%SZ")
    dump = f"{BACKUP_DIR}/fibonix-{ts}.sql.enc"
    # pg_dump | openssl aes-256-gcm
    # simulate
    pathlib.Path(dump).parent.mkdir(parents=True, exist_ok=True)
    pathlib.Path(dump).write_text("encrypted dump")
    print(f"backup: {dump}")
    return dump


def restore(backup_path: str):
    if not pathlib.Path(backup_path).exists():
        raise FileNotFoundError(f"backup not found: {backup_path}")
    if pathlib.Path(backup_path).stat().st_size == 0:
        raise ValueError(f"backup empty: {backup_path}")
    print(f"restore verified: {backup_path}")
    return True


if __name__ == "__main__":
    p = backup()
    restore(p)
