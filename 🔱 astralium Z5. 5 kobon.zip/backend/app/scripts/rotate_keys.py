"""تدوير مفاتيح Envelope — اختبار فعلي."""

from app.core.encryption import generate_dek, wrap_dek


def rotate(kek_old: bytes, kek_new: bytes, wrapped_old):
    nonce_old, ct_old = wrapped_old
    from app.core.encryption import unwrap_dek

    dek = unwrap_dek(kek_old, nonce_old, ct_old)
    return wrap_dek(kek_new, dek)


if __name__ == "__main__":
    kek1 = b"1" * 32
    kek2 = b"2" * 32
    dek = generate_dek()
    w1 = wrap_dek(kek1, dek)
    w2 = rotate(kek1, kek2, w1)
    print("rotation ok", w2)
