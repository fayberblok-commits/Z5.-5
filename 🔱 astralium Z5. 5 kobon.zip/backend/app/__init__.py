"""Astralium Fibonix Z5.5"""

__version__ = "5.5.0"
