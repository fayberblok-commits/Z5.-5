"""عامل الملفات — خدمة صيانة حقيقية (لا حلقة نائمة).

ماذا يفعل فعليًا في كل دورة (كل ما يفعله قابل للقياس ويُعاد كعدّادات):

1. **حذف روابط التنزيل المنتهية/المستخدمة**: صفوف `file_download_tokens` التي
   انتهت صلاحيتها أو استُخدمت تُزال، فلا تتراكم توكينات ميتة قابلة لإعادة الاستخدام.
2. **إغلاق الملفات المعلّقة (fail-closed)**: أي `files.scan_status='pending'` أقدم من
   `PENDING_GRACE` يُحوّل إلى `error` — لا يُخدم ملف لم يكتمل فحصه أبدًا.
3. **تنظيف `revoked_jtis` و`idempotency_keys` القديمة** خارج نافذة الاحتفاظ.
4. إنهاء لطيف عند SIGTERM: يكمل الدورة الحالية ثم يخرج بـ 0.

لا شبكة، ولا مفاتيح S3: العامل يعمل على قاعدة البيانات فقط.
"""

from __future__ import annotations

import logging
import os
import signal
import time
from dataclasses import dataclass

from ..core.db import Conn, atomic

log = logging.getLogger("fibonix.worker.files")

PENDING_GRACE = "15 minutes"   # مهلة قصوى لبقاء ملف بحالة pending
EXPIRED_LINK_RETENTION = "1 hour"   # احتفاظ بالروابط المنتهية للمراجعة
JTI_RETENTION = "30 days"
IDEMPOTENCY_RETENTION = "7 days"
DEFAULT_INTERVAL = 30.0


@dataclass(frozen=True)
class SweepResult:
    expired_tokens: int
    stale_pending_files: int
    old_jtis: int
    old_idempotency: int

    @property
    def total(self) -> int:
        return self.expired_tokens + self.stale_pending_files + self.old_jtis + self.old_idempotency


def _close_stale_pending(conn: Conn, pending_grace: str) -> int:
    """يُغلق الملفات المعلّقة عبر كل المتاجر.

    جدول `files` محمي بـ RLS، لذلك لا يمكن لعامل واحد رؤية كل المتاجر في استعلام
    واحد: نُثبّت `app.store_id` لكل متجر على حدة (نفس مسار التطبيق، لا تجاوز للـ RLS).
    """
    stores = conn.execute("SELECT id FROM stores ORDER BY id").fetchall()
    closed = 0
    for store in stores:
        conn.execute("SELECT set_config('app.store_id', %s, true)", (str(store["id"]),))
        rows = conn.execute(
            "UPDATE files SET scan_status='error' "
            "WHERE scan_status='pending' AND created_at < now() - %s::interval RETURNING id",
            (pending_grace,),
        ).fetchall()
        closed += len(rows)
    conn.execute("SELECT set_config('app.store_id', '', true)")
    return closed


def run_once(conn: Conn, *, pending_grace: str = PENDING_GRACE) -> SweepResult:
    """دورة صيانة واحدة داخل معاملة واحدة. تُعيد عدّادات حقيقية (قد تكون صفرًا لا محالة)."""
    expired = conn.execute(
        "DELETE FROM file_download_tokens "
        "WHERE (used_at IS NOT NULL OR expires_at < now() - %s::interval) RETURNING jti",
        (EXPIRED_LINK_RETENTION,),
    ).fetchall()
    stale_closed = _close_stale_pending(conn, pending_grace)
    jtis = conn.execute(
        "DELETE FROM revoked_jtis WHERE expires_at < now() - %s::interval RETURNING jti",
        (JTI_RETENTION,),
    ).fetchall()
    idem = conn.execute(
        "DELETE FROM idempotency_keys WHERE created_at < now() - %s::interval RETURNING key",
        (IDEMPOTENCY_RETENTION,),
    ).fetchall()
    return SweepResult(len(expired), stale_closed, len(jtis), len(idem))


_stop = False


def _handle_signal(signum: int, _frame: object) -> None:
    global _stop
    log.info("signal %s received — finishing current sweep", signum)
    _stop = True


def run(interval: float | None = None) -> None:
    """حلقة الخدمة. تتوقف عند SIGTERM/SIGINT بعد إتمام الدورة الجارية."""
    interval = interval or float(os.environ.get("FILE_WORKER_INTERVAL", DEFAULT_INTERVAL))
    signal.signal(signal.SIGTERM, _handle_signal)
    signal.signal(signal.SIGINT, _handle_signal)
    log.info("file worker started, interval=%ss", interval)
    while not _stop:
        try:
            with atomic() as conn:
                result = run_once(conn)
            if result.total:
                log.info(
                    "sweep: tokens=%d stale_pending=%d jtis=%d idempotency=%d",
                    result.expired_tokens,
                    result.stale_pending_files,
                    result.old_jtis,
                    result.old_idempotency,
                )
        except Exception:  # noqa: BLE001 - العامل لا يموت على خطأ عابر، يُسجّل ويعيد المحاولة
            log.exception("sweep failed — retrying next cycle")
        deadline = time.monotonic() + interval
        while not _stop and time.monotonic() < deadline:
            time.sleep(min(0.1, interval))
    log.info("file worker stopped cleanly")


if __name__ == "__main__":  # pragma: no cover - entrypoint
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s %(message)s")
    run()
