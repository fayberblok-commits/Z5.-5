"""عامل بريد — قوالب HTML+نص، منع حقن ترويسات."""

import re


def send_email(to: str, subject: str, html: str, text: str):
    if "\n" in subject or "\r" in subject:
        raise ValueError("header injection")
    if not re.match(r"^[^@]+@[^@]+\.[^@]+$", to):
        raise ValueError("bad email")
    # في الإنتاج: SES/SendGrid عبر egress
    return {"to": to, "subject": subject, "sent": True}
