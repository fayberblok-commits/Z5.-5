"""عامل فيديو معزول — بلا شبكة وبلا أسرار DB."""


def generate_video(prompt: str) -> str:
    # في الإنتاج: استدعاء خدمة توليد فيديو رسمية (Runway/Pika) عبر egress proxy
    # فحص أمني قبل الحفظ: فيروسات، حدود HTML، نقاء
    if len(prompt) > 2000:
        raise ValueError("prompt too long")
    return f"video://{prompt[:20]}.mp4"
