"""DB base with RLS helper."""

from sqlalchemy.orm import DeclarativeBase
from sqlalchemy import MetaData

convention = {
    "ix": "ix_%(column_0_label)s",
    "uq": "uq_%(table_name)s_%(column_0_name)s",
    "ck": "ck_%(table_name)s_%(constraint_name)s",
    "fk": "fk_%(table_name)s_%(column_0_name)s_%(referred_table_name)s",
    "pk": "pk_%(table_name)s",
}
metadata = MetaData(naming_convention=convention)


class Base(DeclarativeBase):
    metadata = metadata


# RLS helper to be executed per request
RLS_SET = "SELECT set_config('app.current_store_id', :sid, true)"
RLS_POLICY_TPL = """
ALTER TABLE {table} ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS {table}_isolate ON {table};
CREATE POLICY {table}_isolate ON {table} USING (store_id = current_setting('app.current_store_id')::uuid);
"""
