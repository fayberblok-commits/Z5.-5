# Migrations — Alembic
`alembic upgrade head` لإنشاء جداول stores, products, orders مع RLS policies.
سياسات RLS: كل جدول فيه store_id يُقارَن مع current_setting('app.current_store_id')
