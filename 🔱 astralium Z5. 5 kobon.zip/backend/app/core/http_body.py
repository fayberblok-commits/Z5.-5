"""Bounded raw-body reads: enforce limits while consuming, not after buffering."""
from __future__ import annotations

import asyncio

from fastapi import HTTPException, Request
from starlette.requests import ClientDisconnect


async def read_limited_body(request: Request, *, max_bytes: int, timeout_seconds: float = 30.0) -> bytes:
    lengths = request.headers.getlist('content-length')
    declared: int | None = None
    if lengths:
        raw = lengths[0]
        if len(lengths) != 1 or not raw or not raw.isascii() or not raw.isdigit():
            raise HTTPException(400, 'invalid content length')
        if request.headers.get('transfer-encoding'):
            raise HTTPException(400, 'ambiguous request framing')
        digits = raw.lstrip('0') or '0'
        # Avoid Python's large-integer conversion limit, without trusting framing.
        if len(digits) > len(str(max_bytes)):
            raise HTTPException(413, 'request body too large')
        declared = int(digits)
        if declared > max_bytes:
            raise HTTPException(413, 'request body too large')
    body = bytearray()
    try:
        async with asyncio.timeout(timeout_seconds):
            async for chunk in request.stream():
                if len(chunk) > max_bytes - len(body):
                    raise HTTPException(413, 'request body too large')
                body.extend(chunk)
    except ClientDisconnect:
        raise HTTPException(400, 'request interrupted') from None
    except TimeoutError:
        raise HTTPException(408, 'request body timeout') from None
    if declared is not None and len(body) != declared:
        raise HTTPException(400, 'content length mismatch')
    return bytes(body)
