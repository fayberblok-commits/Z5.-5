"""طبقة قاعدة البيانات — اتصال psycopg3، معاملات صريحة، وعزل متاجر عبر RLS.

كل استعلام يمر عبر جلسة تحمل `app.store_id` (GUC) بحيث تُطبّق سياسات RLS في
PostgreSQL نفسه. لا يوجد أي «فلترة في بايثون» تُغني عن RLS.
"""

from __future__ import annotations

import contextlib
import uuid
from collections.abc import Iterator
from typing import Any, TypeAlias

import psycopg
from psycopg.rows import dict_row

from .config import get_settings

Row: TypeAlias = dict[str, Any]
Conn: TypeAlias = psycopg.Connection[Row]


def dsn() -> str:
    return get_settings().database_url.get_secret_value()


@contextlib.contextmanager
def connect(app_role: bool = True, autocommit: bool = False) -> Iterator[Conn]:
    """اتصال واحد. `app_role=True` يستخدم دور التطبيق غير المالك (RLS مفعّل)."""
    settings = get_settings()
    with psycopg.connect(dsn(), row_factory=dict_row, autocommit=autocommit) as conn:
        if app_role:
            conn.execute(f"SET ROLE {settings.database_app_role}")
        yield conn


@contextlib.contextmanager
def tenant(store_id: str | uuid.UUID, app_role: bool = True) -> Iterator[Conn]:
    """اتصال مقيّد بمتجر واحد داخل معاملة. RLS تمنع أي صف خارج هذا المتجر."""
    store_uuid = uuid.UUID(str(store_id))
    with connect(app_role=app_role) as conn, conn.transaction():
        conn.execute("SELECT set_config('app.store_id', %s, true)", (str(store_uuid),))
        yield conn


@contextlib.contextmanager
def raw() -> Iterator[Conn]:
    """اتصال خام بلا معاملة تلقائية — للسيناريوهات التي تحتاج تثبيت جزء ثم الفشل
    (مثل عدّاد محاولات الدخول: يجب أن يُحفظ حتى عند رفض الطلب)."""
    settings = get_settings()
    conn = psycopg.connect(dsn(), row_factory=dict_row)
    try:
        conn.execute(f"SET ROLE {settings.database_app_role}")
        yield conn
    finally:
        conn.close()


@contextlib.contextmanager
def atomic() -> Iterator[Conn]:
    """معاملة واحدة: إما تُثبّت كل الكتابات أو تُلغى كلها (لا قيود ناقصة)."""
    with connect() as conn, conn.transaction():
        yield conn


def one(row: Row | None, *, context: str = "row") -> Row:
    """يفكّ `fetchone()` مع رفع خطأ صريح بدل الانهيار بغموض إن غاب الصف."""
    if row is None:
        raise LookupError(f"expected {context}, found none")
    return row


def fetch_one(conn: Conn, sql: str, params: tuple[Any, ...] = ()) -> Row | None:
    return conn.execute(sql, params).fetchone()


def fetch_all(conn: Conn, sql: str, params: tuple[Any, ...] = ()) -> list[Row]:
    return conn.execute(sql, params).fetchall()


def scalar(conn: Conn, sql: str, params: tuple[Any, ...] = ()) -> Any:
    row = conn.execute(sql, params).fetchone()
    return next(iter(row.values())) if row else None


def ping() -> bool:
    with connect(app_role=False) as conn:
        return conn.execute("SELECT 1").fetchone() is not None
