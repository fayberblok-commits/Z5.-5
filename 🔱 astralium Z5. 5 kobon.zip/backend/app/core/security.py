from argon2 import PasswordHasher
from argon2.exceptions import VerifyMismatchError
import hmac
import hashlib
import time
import secrets
import re
import jwt
from datetime import datetime, timedelta, timezone

ph = PasswordHasher(time_cost=3, memory_cost=65536, parallelism=4, hash_len=32, salt_len=16)


def hash_password(pw: str) -> str:
    if len(pw) < 12:
        raise ValueError("password too weak: min 12")
    if not re.search(r"[A-Z]", pw) or not re.search(r"[a-z]", pw) or not re.search(r"[0-9]", pw):
        raise ValueError("password needs upper/lower/digit")
    return ph.hash(pw)


def verify_password(hash: str, pw: str) -> bool:
    try:
        ph.verify(hash, pw)
        return True
    except VerifyMismatchError:
        return False


def needs_rehash(hash: str) -> bool:
    return ph.check_needs_rehash(hash)


def create_access_token(sub: str, store_id: str | None, role: str, secret: str, ttl_minutes: int = 15) -> str:
    payload = {
        "sub": sub,
        "store_id": store_id,
        "role": role,
        "iat": datetime.now(timezone.utc),
        "exp": datetime.now(timezone.utc) + timedelta(minutes=ttl_minutes),
        "jti": secrets.token_hex(16),
    }
    return jwt.encode(payload, secret, algorithm="HS256")


def verify_token(token: str, secret: str) -> dict:
    # PyJWT: القائمة المغلقة للخوارزميات تمنع هجمات alg-confusion و alg=none.
    return jwt.decode(token, secret, algorithms=["HS256"], options={"require": ["exp"]})


def secure_compare(a: str, b: str) -> bool:
    return hmac.compare_digest(a, b)


def sign_hmac(key: str, msg: str) -> str:
    return hmac.new(key.encode(), msg.encode(), hashlib.sha256).hexdigest()


def anti_enumeration_delay():
    time.sleep(0.08)


def rate_limit_key(ip: str, path: str) -> str:
    return f"rl:{ip}:{path}"
