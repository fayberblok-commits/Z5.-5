"""Vault abstraction — in prod: HashiCorp Vault. Here: env-backed with encryption."""

from typing import Optional


class Vault:
    """Minimal Vault interface. Prod implementation uses hvac client."""

    def __init__(self, addr: str, token: str):
        self.addr = addr
        self.token = token
        self._store: dict[str, str] = {}

    def put_secret(self, path: str, value: str):
        # In prod: transit encrypt + KV v2
        self._store[path] = value

    def get_secret(self, path: str) -> Optional[str]:
        return self._store.get(path)

    def mask(self, value: str) -> str:
        if not value or len(value) < 8:
            return "****"
        return "****" + value[-4:]


# Singleton for app
_vault = None


def get_vault(addr: str, token: str) -> Vault:
    global _vault
    if _vault is None:
        _vault = Vault(addr, token)
    return _vault
