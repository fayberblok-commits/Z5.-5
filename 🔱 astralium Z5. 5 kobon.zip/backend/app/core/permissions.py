"""Central RBAC matrix: role × resource × action = single source of truth."""

from enum import Enum
from typing import Dict, Tuple


class Role(str, Enum):
    owner = "owner"
    merchant = "merchant"
    merchant_staff = "merchant_staff"
    buyer = "buyer"
    ai_service = "ai_service"


class Resource(str, Enum):
    store = "store"
    product = "product"
    order = "order"
    ledger = "ledger"
    payment_config = "payment_config"
    bank_account = "bank_account"
    file = "file"
    template = "template"
    ai_tool = "ai_tool"
    audit_log = "audit_log"
    security_center = "security_center"


class Action(str, Enum):
    create = "create"
    read = "read"
    update = "update"
    delete = "delete"
    list = "list"
    export = "export"
    refund = "refund"
    manage = "manage"


# Matrix: (role, resource, action) -> allowed
MATRIX: Dict[Tuple[Role, Resource, Action], bool] = {}


def allow(role: Role, resource: Resource, action: Action):
    MATRIX[(role, resource, action)] = True


# Owner: all
for res in Resource:
    for act in Action:
        allow(Role.owner, res, act)

# Merchant: owns store/products/orders/files/templates, no ledger/payment_config/bank
for res in [Resource.store, Resource.product, Resource.order, Resource.file, Resource.template]:
    for act in [Action.create, Action.read, Action.update, Action.delete, Action.list]:
        allow(Role.merchant, res, act)
allow(Role.merchant, Resource.ai_tool, Action.create)
allow(Role.merchant, Resource.ai_tool, Action.read)
allow(Role.merchant, Resource.audit_log, Action.read)  # own store only

# Staff: subset (read/list, create product/order, no delete store)
for res in [Resource.product, Resource.order, Resource.file]:
    for act in [Action.create, Action.read, Action.list, Action.update]:
        allow(Role.merchant_staff, res, act)
allow(Role.merchant_staff, Resource.store, Action.read)

# Buyer: read products, create orders, read own orders
allow(Role.buyer, Resource.product, Action.read)
allow(Role.buyer, Resource.product, Action.list)
allow(Role.buyer, Resource.order, Action.create)
allow(Role.buyer, Resource.order, Action.read)

# AI service: very limited
allow(Role.ai_service, Resource.product, Action.read)
allow(Role.ai_service, Resource.template, Action.read)
allow(Role.ai_service, Resource.ai_tool, Action.create)


def is_allowed(role: Role, resource: Resource, action: Action) -> bool:
    return MATRIX.get((role, resource, action), False)


def enforce(role: str, resource: str, action: str):
    try:
        r = Role(role)
        res = Resource(resource)
        act = Action(action)
    except ValueError as exc:
        raise PermissionError("unknown role/resource/action") from exc
    if not is_allowed(r, res, act):
        raise PermissionError(f"denied: {role} cannot {action} {resource}")
    return True
