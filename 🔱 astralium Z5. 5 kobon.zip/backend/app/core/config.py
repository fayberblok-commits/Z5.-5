"""إعدادات التطبيق — fail-closed: لا قيم افتراضية لأي سر، ولا fallback.

كل قيمة حساسة يجب أن تأتي من البيئة (أو من مدير أسرار في الإنتاج). إن نقص أي
مفتاح إلزامي يفشل التطبيق عند الإقلاع برسالة صريحة، ولا يعمل بقيمة افتراضية.
"""

from __future__ import annotations

import re
import os
from functools import lru_cache

from pydantic import SecretStr, ValidationInfo, field_validator, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

# أنماط تدل على قيمة افتراضية/مؤقتة — تُرفض دائمًا
_PLACEHOLDER_PATTERNS = (
    "change-me",
    "changeme",
    "change_me",
    "replace-me",
    "your-",
    "example",
    "placeholder",
    "dummy",
    "fallback",
    "test-secret",
    "password",
    "secret-key-here",
    "xxx",
    "todo",
)
_MIN_SECRET_LEN = 32


class ConfigError(RuntimeError):
    """يُرفع عند إعدادات ناقصة أو ضعيفة — التطبيق يجب أن يفشل إقلاعه."""


class Settings(BaseSettings):
    # --- البيئة ---
    app_env: str = "production"
    app_base_url: str
    admin_base_url: str

    # --- أسرار إلزامية (بلا قيم افتراضية) ---
    app_secret_key: SecretStr
    jwt_secret: SecretStr
    audit_hmac_key: SecretStr
    encryption_kek: SecretStr
    stripe_secret_key: SecretStr
    stripe_webhook_secret: SecretStr
    stripe_connect_client_id: SecretStr

    # --- بنية تحتية إلزامية ---
    database_url: SecretStr
    database_app_role: str = "fibonix_app"
    redis_url: SecretStr
    s3_endpoint: str
    s3_region: str = "us-east-1"
    s3_access_key: SecretStr
    s3_secret_key: SecretStr
    s3_bucket_private: str
    s3_bucket_public: str
    clamav_host: str
    clamav_port: int = 3310

    # --- اختيارية بحدود آمنة ---
    admin_allowed_ips: str = ""
    rate_limit_per_min: int = 60
    login_max_attempts: int = 5
    login_lockout_minutes: int = 15
    session_ttl_minutes: int = 30
    access_token_ttl_minutes: int = 15
    step_up_ttl_seconds: int = 300
    file_url_ttl_seconds: int = 600
    max_upload_bytes: int = 25 * 1024 * 1024
    ai_emergency_stop: bool = False
    ai_monthly_budget_usd: float = 50.0
    platform_fee_minor: int = 200
    currency: str = "USD"

    model_config = SettingsConfigDict(
        env_file=None,  # لا نقرأ .env تلقائيًا: البيئة هي المصدر الوحيد
        env_file_encoding="utf-8",
        extra="forbid",
        case_sensitive=False,
        hide_input_in_errors=True,
    )

    # ---------- تحقق ----------
    @field_validator(
        "app_secret_key",
        "jwt_secret",
        "audit_hmac_key",
        "encryption_kek",
        "stripe_secret_key",
        "stripe_webhook_secret",
        "stripe_connect_client_id",
        "s3_secret_key",
    )
    @classmethod
    def _strong_secret(cls, v: SecretStr, info: ValidationInfo) -> SecretStr:
        raw = v.get_secret_value()
        if len(raw) < _MIN_SECRET_LEN:
            raise ValueError(f"{info.field_name}: must be >= {_MIN_SECRET_LEN} chars")
        low = raw.lower()
        for pat in _PLACEHOLDER_PATTERNS:
            if pat in low:
                raise ValueError(f"{info.field_name}: placeholder value rejected (fail-closed)")
        if len(set(raw)) < 8:
            raise ValueError(f"{info.field_name}: insufficient entropy")
        return v

    @field_validator("stripe_secret_key")
    @classmethod
    def _stripe_key_shape(cls, v: SecretStr) -> SecretStr:
        raw = v.get_secret_value()
        if not re.match(r"^(sk|rk)_(test|live)_[A-Za-z0-9]{8,}$", raw):
            raise ValueError("stripe_secret_key: expected sk_test_/sk_live_ format")
        if raw.startswith(("sk_live_", "rk_live_")) and self_env() == "production":
            raise ValueError("live Stripe key in non-payment-enabled environment")
        return v

    @field_validator("stripe_webhook_secret")
    @classmethod
    def _stripe_webhook_shape(cls, v: SecretStr) -> SecretStr:
        if not v.get_secret_value().startswith("whsec_"):
            raise ValueError("stripe_webhook_secret: expected whsec_ prefix")
        return v

    @field_validator("database_url", "redis_url")
    @classmethod
    def _url_secret(cls, v: SecretStr, info: ValidationInfo) -> SecretStr:
        raw = v.get_secret_value()
        scheme = raw.split(":", 1)[0]
        allowed = {"postgresql": {"postgresql", "postgres"}, "redis": {"redis", "rediss"}}
        key = "postgresql" if info.field_name == "database_url" else "redis"
        if scheme not in allowed[key]:
            raise ValueError(f"{info.field_name}: unsupported scheme {scheme!r}")
        if "password=" in raw and re.search(r"password=(changeme|password|secret)", raw, re.I):
            raise ValueError(f"{info.field_name}: placeholder password rejected")
        return v

    @model_validator(mode="after")
    def _environment_consistency(self) -> Settings:
        if os.environ.get("STRIPE_MOCK_TRANSPORT") == "1" and self.app_env != "test":
            raise ValueError("mock payment transport is allowed only in the test environment")
        if self.app_env not in ("development", "test", "staging", "production"):
            raise ValueError("app_env must be development|test|staging|production")
        if self.app_env == "production":
            if not self.admin_allowed_ips:
                raise ValueError("production requires admin_allowed_ips (owner office IP allowlist)")
            if not self.app_base_url.startswith("https://"):
                raise ValueError("production requires https app_base_url")
            if not self.s3_endpoint.startswith("https://"):
                raise ValueError("production requires https s3_endpoint")
            if "@" in self.database_url.get_secret_value() and "sslmode" not in self.database_url.get_secret_value():
                raise ValueError("production database_url must set sslmode")
        if self.app_env == "test" and self.s3_endpoint.startswith("https://"):
            raise ValueError("test environment must not point at a live object store")
        if self.platform_fee_minor < 0 or self.platform_fee_minor > 100_000:
            raise ValueError("platform_fee_minor out of range")
        if self.max_upload_bytes > 200 * 1024 * 1024:
            raise ValueError("max_upload_bytes too large")
        return self

    # ---------- مساعدات ----------
    def secret(self, field: str) -> str:
        value = getattr(self, field)
        return value.get_secret_value() if isinstance(value, SecretStr) else str(value)

    def allowed_admin_ips(self) -> tuple[str, ...]:
        return tuple(ip.strip() for ip in self.admin_allowed_ips.split(",") if ip.strip())


def self_env() -> str:
    import os

    return os.environ.get("APP_ENV", "production")


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    """يقرأ البيئة مرة واحدة. أي نقص ⇒ ConfigError يوقف الإقلاع."""
    try:
        return Settings()  # type: ignore[call-arg]
    except Exception:  # Never render validation inputs or chain a secret-bearing exception.
        raise ConfigError("invalid or missing configuration — refusing to start") from None


def reset_settings_cache() -> None:
    get_settings.cache_clear()
