"""Envelope encryption: AES-256-GCM via cryptography only. No custom crypto."""

from cryptography.hazmat.primitives.ciphers.aead import AESGCM
import os
import base64
import hashlib
from typing import Tuple


def generate_dek() -> bytes:
    return AESGCM.generate_key(bit_length=256)


def encrypt_aes_gcm(key: bytes, plaintext: bytes, aad: bytes | None = None) -> Tuple[bytes, bytes]:
    aesgcm = AESGCM(key)
    nonce = os.urandom(12)
    ct = aesgcm.encrypt(nonce, plaintext, aad)
    return nonce, ct


def decrypt_aes_gcm(key: bytes, nonce: bytes, ct: bytes, aad: bytes | None = None) -> bytes:
    aesgcm = AESGCM(key)
    return aesgcm.decrypt(nonce, ct, aad)


# Envelope: DEK wrapped by KEK (also AES-GCM for demo; in prod: Vault Transit/HSM)
def wrap_dek(kek: bytes, dek: bytes) -> Tuple[bytes, bytes]:
    return encrypt_aes_gcm(kek, dek, aad=b"dek-wrap")


def unwrap_dek(kek: bytes, nonce: bytes, wrapped: bytes) -> bytes:
    return decrypt_aes_gcm(kek, nonce, wrapped, aad=b"dek-wrap")


# Field-level example
def encrypt_field(kek: bytes, store_dek_wrapped: Tuple[bytes, bytes], plaintext: str, aad_context: str) -> dict:
    # In prod: fetch KEK from Vault, unwrap DEK, then encrypt field
    # Here we simulate correctly
    nonce_w, wrapped = store_dek_wrapped
    dek = unwrap_dek(kek, nonce_w, wrapped)
    nonce, ct = encrypt_aes_gcm(dek, plaintext.encode(), aad=aad_context.encode())
    # blind index for searchable without decrypt: HMAC-SHA256 with separate key
    blind = hashlib.sha256((aad_context + plaintext.lower()).encode()).hexdigest()[
        :16
    ]  # demo; prod uses HMAC with blind-index key
    return {"nonce": base64.b64encode(nonce).decode(), "ct": base64.b64encode(ct).decode(), "blind": blind}


def decrypt_field(kek: bytes, store_dek_wrapped: Tuple[bytes, bytes], data: dict, aad_context: str) -> str:
    nonce_w, wrapped = store_dek_wrapped
    dek = unwrap_dek(kek, nonce_w, wrapped)
    nonce = base64.b64decode(data["nonce"])
    ct = base64.b64decode(data["ct"])
    pt = decrypt_aes_gcm(dek, nonce, ct, aad=aad_context.encode())
    return pt.decode()
