"""محدّد معدل: Redis في كل بيئة غير الاختبار، وذاكرة محلية في الاختبار فقط.

* في الإنتاج/الـ staging: إن تعذّر الوصول إلى Redis عند الإقلاع يفشل التطبيق
  (`assert_ready`)، ولا يوجد تجاوز صامت.
* في الاختبار: backend في الذاكرة مع تصريح صريح (لا يقلّد Redis في الإنتاج).
"""

from __future__ import annotations

import threading
import time
from collections import defaultdict, deque

from .config import get_settings


class MemoryBackend:
    """للاختبار فقط — لا يُستخدم عندما APP_ENV != test."""

    name = "memory"

    def __init__(self) -> None:
        self._hits: dict[str, deque[float]] = defaultdict(deque)
        self._lock = threading.Lock()

    def allow(self, key: str, limit: int, window: int) -> bool:
        now = time.time()
        with self._lock:
            dq = self._hits[key]
            while dq and dq[0] <= now - window:
                dq.popleft()
            if len(dq) >= limit:
                return False
            dq.append(now)
            return True

    def ready(self) -> bool:
        return True

    def reset(self) -> None:
        with self._lock:
            self._hits.clear()


class RedisBackend:
    """نافذة زمنية منزلقة باستخدام ZSET + EXPIRE، ذرّية عبر Lua."""

    name = "redis"
    _SCRIPT = """
    local key = KEYS[1]
    local now = tonumber(ARGV[1])
    local window = tonumber(ARGV[2])
    local limit = tonumber(ARGV[3])
    redis.call('ZREMRANGEBYSCORE', key, 0, now - window)
    local count = redis.call('ZCARD', key)
    if count >= limit then return 0 end
    redis.call('ZADD', key, now, ARGV[4])
    redis.call('EXPIRE', key, window + 1)
    return 1
    """

    def __init__(self, url: str) -> None:
        import redis

        self._client = redis.Redis.from_url(url, socket_timeout=2, socket_connect_timeout=2)
        self._script = self._client.register_script(self._SCRIPT)

    def allow(self, key: str, limit: int, window: int) -> bool:
        now = time.time()
        member = f"{now}:{time.perf_counter_ns()}"
        return bool(self._script(keys=[f"rl:{key}"], args=[now, window, limit, member]))

    def ready(self) -> bool:
        try:
            return bool(self._client.ping())
        except Exception:  # noqa: BLE001 — أي فشل = غير جاهز
            return False

    def reset(self) -> None:  # pragma: no cover - يُستخدم في الاختبارات فقط
        for key in self._client.scan_iter("rl:*"):
            self._client.delete(key)


class RateLimiter:
    def __init__(self, backend=None) -> None:
        self._backend = backend

    @property
    def backend(self):
        if self._backend is None:
            settings = get_settings()
            if settings.app_env == "test":
                self._backend = MemoryBackend()
            else:
                self._backend = RedisBackend(settings.redis_url.get_secret_value())
        return self._backend

    def allow(self, key: str, limit: int, window_sec: int) -> bool:
        return self.backend.allow(key, limit, window_sec)

    def allow_many(self, keys: list[str], limit: int, window_sec: int) -> bool:
        return all(self.allow(k, limit, window_sec) for k in keys)

    def assert_ready(self) -> None:
        if not self.backend.ready():
            raise RuntimeError(f"rate-limiter backend {self.backend.name!r} not ready — refusing to start")

    def reset(self) -> None:
        self.backend.reset()


limiter = RateLimiter()
