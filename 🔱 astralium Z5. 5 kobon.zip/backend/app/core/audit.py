"""سجل تدقيق دائم: سلسلة تجزئة + MAC بمفتاح مستقل، غير قابل للتعديل، وقابل للتحقق.

* كل صف يحمل `prev_hash` (تجزئة الصف السابق) و`hash` (تجزئة المحتوى) و`mac`
  (HMAC-SHA256 بمفتاح `AUDIT_HMAC_KEY`). بدون المفتاح لا يمكن تزوير سلسلة
  متسقة بعد تعديل صف، وتغيير/حذف صف يكسر السلسلة أو يُنتج فجوة في التسلسل.
* الجدول append-only عبر trigger في قاعدة البيانات (UPDATE/DELETE/TRUNCATE ممنوعة).
* لا تُسجّل أسرار: `redact()` تُنظّف المفاتيح الحساسة قبل الكتابة.
"""

from __future__ import annotations

import hashlib
import hmac
import json
from typing import Any


from .db import Conn, one

SENSITIVE_KEYS = {
    "password",
    "password_hash",
    "secret",
    "token",
    "authorization",
    "cookie",
    "card",
    "cvc",
    "iban",
    "api_key",
    "client_secret",
    "totp_secret",
    "webauthn",
    "private_key",
}


def redact(meta: dict[str, Any] | None) -> dict[str, Any]:
    """يخفي أي قيمة حساسة قبل الحفظ في السجل (المفاتيح المتداخلة أيضًا)."""
    if not meta:
        return {}

    def _walk(value: Any) -> Any:
        if isinstance(value, dict):
            return {
                k: ("[redacted]" if any(s in k.lower() for s in SENSITIVE_KEYS) else _walk(v))
                for k, v in value.items()
            }
        if isinstance(value, list):
            return [_walk(v) for v in value]
        return value

    return dict(_walk(meta))


def canonical(entry: dict) -> bytes:
    return json.dumps(entry, sort_keys=True, separators=(",", ":"), ensure_ascii=False, default=str).encode()


def hash_entry(prev_hash: str, entry: dict) -> str:
    h = hashlib.sha256()
    h.update(prev_hash.encode())
    h.update(canonical(entry))
    return h.hexdigest()


def mac_hash(key: str, digest: str) -> str:
    return hmac.new(key.encode(), digest.encode(), hashlib.sha256).hexdigest()


def audit_append(
    conn: Conn,
    *,
    actor: str,
    action: str,
    resource: str,
    store_id: str | None = None,
    meta: dict | None = None,
    result: str = "ok",
) -> dict:
    """يُضيف صفًا للسجل داخل معاملة القفل الحالية (سلسلة خطية بلا سباقات)."""
    from .config import get_settings

    key = get_settings().audit_hmac_key.get_secret_value()
    safe_meta = redact(meta)
    conn.execute("SELECT pg_advisory_xact_lock(hashtext('audit_chain'))")
    last = conn.execute("SELECT hash FROM audit_log ORDER BY id DESC LIMIT 1").fetchone()
    prev = last["hash"] if last else "0" * 64
    entry = {
        "actor": actor,
        "action": action,
        "resource": resource,
        "result": result,
        "store_id": str(store_id) if store_id else None,
        "meta": safe_meta,
    }
    digest = hash_entry(prev, entry)
    mac = mac_hash(key, digest)
    row = one(
        conn.execute(
            """INSERT INTO audit_log (actor, action, resource, result, store_id, meta, prev_hash, hash, mac)
               VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s)
               RETURNING id, ts, hash""",
            (actor, action, resource, result, store_id, json.dumps(safe_meta), prev, digest, mac),
        ).fetchone(),
        context="audit append",
    )
    return {"id": row["id"], "hash": row["hash"], "prev": prev}


def verify_chain(conn: Conn, *, limit: int | None = None) -> dict:
    """تحقق مستقل: يعيد بناء السلسلة ويكشف أي تعديل/حذف/إدراج مفقود."""
    from .config import get_settings

    key = get_settings().audit_hmac_key.get_secret_value()
    sql = "SELECT id, actor, action, resource, result, store_id, meta, prev_hash, hash, mac FROM audit_log ORDER BY id"
    rows = conn.execute(sql).fetchall()
    if limit:
        rows = rows[-limit:]

    prev = "0" * 64
    problems: list[dict] = []
    expected_id = None
    for row in rows:
        if expected_id is not None and row["id"] != expected_id:
            problems.append({"id": row["id"], "problem": f"sequence gap (expected {expected_id})"})
        expected_id = row["id"] + 1
        entry = {
            "actor": row["actor"],
            "action": row["action"],
            "resource": row["resource"],
            "result": row["result"],
            "store_id": str(row["store_id"]) if row["store_id"] else None,
            "meta": row["meta"],
        }
        if row["prev_hash"] != prev:
            problems.append({"id": row["id"], "problem": "broken prev_hash link"})
        digest = hash_entry(row["prev_hash"], entry)
        if digest != row["hash"]:
            problems.append({"id": row["id"], "problem": "content hash mismatch (row tampered)"})
        if not hmac.compare_digest(mac_hash(key, row["hash"]), row["mac"]):
            problems.append({"id": row["id"], "problem": "MAC mismatch (forged without key)"})
        prev = row["hash"]
    return {"valid": not problems, "entries": len(rows), "problems": problems, "head": prev}
