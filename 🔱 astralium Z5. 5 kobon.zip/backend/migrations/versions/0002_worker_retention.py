"""Grant the retention worker what it actually needs + index for pending scans.

Revision ID: 0002_worker_retention
Revises: 0001_initial
Create Date: 2026-10-20

سبب الهجرة: عامل الصيانة (app/workers/files.py) يحذف توكينات منتهية و`jti` مُبطلة
ومفاتيح idempotency قديمة، وكانت الصلاحيات تمنع DELETE على `revoked_jtis` و
`idempotency_keys` — أي أن العامل كان سيفشل بصلاحية غير كافية. هنا نمنح الحد
الأدنى اللازم (DELETE فقط على الجداول التشغيلية، لا على الدفتر أو سجل التدقيق).
"""

from alembic import op

revision = "0002_worker_retention"
down_revision = "0001_initial"
branch_labels = None
depends_on = None

APP_ROLE = "fibonix_app"

UPGRADE = f"""
GRANT DELETE ON revoked_jtis, idempotency_keys TO {APP_ROLE};
CREATE INDEX IF NOT EXISTS files_pending_scan_idx ON files(created_at) WHERE scan_status = 'pending';
CREATE INDEX IF NOT EXISTS idempotency_created_idx ON idempotency_keys(created_at);
CREATE INDEX IF NOT EXISTS revoked_jtis_expires_idx ON revoked_jtis(expires_at);
"""

DOWNGRADE = f"""
REVOKE DELETE ON revoked_jtis, idempotency_keys FROM {APP_ROLE};
DROP INDEX IF EXISTS files_pending_scan_idx;
DROP INDEX IF EXISTS idempotency_created_idx;
DROP INDEX IF EXISTS revoked_jtis_expires_idx;
"""


def upgrade() -> None:
    op.execute(UPGRADE)


def downgrade() -> None:
    op.execute(DOWNGRADE)
