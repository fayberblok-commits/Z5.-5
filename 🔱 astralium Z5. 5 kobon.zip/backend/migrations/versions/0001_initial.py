"""Initial schema: tenants, money, payments, files, audit, auth + RLS.

Revision ID: 0001_initial
Create Date: 2026-10-20
"""

from alembic import op

revision = "0001_initial"
down_revision = None
branch_labels = None
depends_on = None

APP_ROLE = "fibonix_app"

SCHEMA = """

-- ============ الهوية والصلاحيات ============
CREATE TABLE accounts (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    email text NOT NULL,
    password_hash text NOT NULL,
    role text NOT NULL CHECK (role IN ('owner','merchant','merchant_staff','buyer','ai_service')),
    store_id uuid,
    totp_secret_enc text,
    totp_confirmed_at timestamptz,
    webauthn_credentials jsonb NOT NULL DEFAULT '[]'::jsonb,
    failed_logins int NOT NULL DEFAULT 0,
    locked_until timestamptz,
    created_at timestamptz NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX accounts_email_lower_idx ON accounts (lower(email));

CREATE TABLE sessions (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    account_id uuid NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
    token_hash text UNIQUE NOT NULL,
    device_fp_hash text NOT NULL,
    step_up_at timestamptz,
    created_at timestamptz NOT NULL DEFAULT now(),
    last_used_at timestamptz NOT NULL DEFAULT now(),
    expires_at timestamptz NOT NULL,
    revoked_at timestamptz,
    rotated_from uuid
);
CREATE INDEX sessions_account_idx ON sessions(account_id);

CREATE TABLE revoked_jtis (
    jti text PRIMARY KEY,
    expires_at timestamptz NOT NULL
);

-- ============ المتاجر ============
CREATE TABLE stores (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    name text NOT NULL,
    owner_id uuid NOT NULL REFERENCES accounts(id),
    status text NOT NULL DEFAULT 'active' CHECK (status IN ('active','suspended','closed')),
    created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE merchant_accounts (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    store_id uuid NOT NULL UNIQUE REFERENCES stores(id) ON DELETE CASCADE,
    provider text NOT NULL DEFAULT 'stripe' CHECK (provider IN ('stripe','paypal')),
    provider_account_id text NOT NULL,
    payouts_enabled boolean NOT NULL DEFAULT false,
    country char(2) NOT NULL,
    created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE products (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    store_id uuid NOT NULL REFERENCES stores(id) ON DELETE CASCADE,
    title text NOT NULL,
    price_minor bigint NOT NULL CHECK (price_minor >= 0),
    currency char(3) NOT NULL DEFAULT 'USD',
    status text NOT NULL DEFAULT 'active' CHECK (status IN ('draft','active','archived')),
    digital_file_key text,
    created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX products_store_idx ON products(store_id);

-- ============ الطلبات والمال ============
CREATE TABLE orders (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    store_id uuid NOT NULL REFERENCES stores(id),
    buyer_email text NOT NULL,
    amount_minor bigint NOT NULL CHECK (amount_minor >= 0),
    coupon_minor bigint NOT NULL DEFAULT 0 CHECK (coupon_minor >= 0),
    currency char(3) NOT NULL DEFAULT 'USD',
    status text NOT NULL DEFAULT 'pending'
        CHECK (status IN ('pending','paid','fulfilled','refunded','disputed','canceled','failed')),
    idempotency_key text NOT NULL,
    created_at timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT coupon_not_above_amount CHECK (coupon_minor <= amount_minor)
);
CREATE UNIQUE INDEX orders_idem_idx ON orders(store_id, idempotency_key);
CREATE INDEX orders_store_idx ON orders(store_id, created_at DESC);

CREATE TABLE order_items (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    order_id uuid NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
    store_id uuid NOT NULL REFERENCES stores(id),
    product_id uuid NOT NULL REFERENCES products(id),
    qty int NOT NULL CHECK (qty > 0),
    unit_price_minor bigint NOT NULL CHECK (unit_price_minor >= 0)
);
CREATE INDEX order_items_store_idx ON order_items(store_id);

CREATE TABLE payments (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    order_id uuid NOT NULL UNIQUE REFERENCES orders(id),
    store_id uuid NOT NULL REFERENCES stores(id),
    provider text NOT NULL CHECK (provider IN ('stripe','paypal')),
    provider_payment_id text UNIQUE NOT NULL,
    amount_minor bigint NOT NULL CHECK (amount_minor >= 0),
    currency char(3) NOT NULL,
    gateway_fee_minor bigint NOT NULL DEFAULT 0 CHECK (gateway_fee_minor >= 0),
    status text NOT NULL CHECK (status IN ('pending','processing','paid','failed','refunded','disputed')),
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX payments_store_idx ON payments(store_id);

CREATE TABLE platform_fees (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    order_id uuid NOT NULL UNIQUE REFERENCES orders(id),
    payment_id uuid NOT NULL REFERENCES payments(id),
    store_id uuid NOT NULL REFERENCES stores(id),
    amount_minor bigint NOT NULL CHECK (amount_minor >= 0),
    currency char(3) NOT NULL,
    status text NOT NULL DEFAULT 'pending'
        CHECK (status IN ('pending','processing','paid','failed','refunded','disputed')),
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now()
);

-- تحويلات مالية فعلية عبر المزود: حصة التاجر، وتحصيل عمولة المنصة.
-- لا يُعتبر أي تحويل 'paid' قبل تأكيد رسمي (webhook/استعلام موقّع من المزود).
CREATE TABLE transfers (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    order_id uuid NOT NULL REFERENCES orders(id),
    store_id uuid NOT NULL REFERENCES stores(id),
    kind text NOT NULL CHECK (kind IN ('merchant_payout','platform_fee_collection')),
    provider_transfer_id text UNIQUE,
    amount_minor bigint NOT NULL CHECK (amount_minor > 0),
    currency char(3) NOT NULL,
    status text NOT NULL DEFAULT 'pending'
        CHECK (status IN ('pending','processing','paid','failed','refunded')),
    idempotency_key text UNIQUE NOT NULL,
    failure_reason text,
    created_at timestamptz NOT NULL DEFAULT now(),
    confirmed_at timestamptz
);
CREATE UNIQUE INDEX transfers_one_payout_per_order ON transfers(order_id, kind);

CREATE TABLE settlements (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    store_id uuid NOT NULL REFERENCES stores(id),
    period_start date NOT NULL,
    period_end date NOT NULL,
    gross_minor bigint NOT NULL,
    platform_fee_minor bigint NOT NULL,
    gateway_fee_minor bigint NOT NULL DEFAULT 0,
    net_to_merchant_minor bigint NOT NULL,
    status text NOT NULL DEFAULT 'open' CHECK (status IN ('open','frozen','paid')),
    created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE refunds (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    payment_id uuid NOT NULL REFERENCES payments(id),
    store_id uuid NOT NULL REFERENCES stores(id),
    amount_minor bigint NOT NULL CHECK (amount_minor > 0),
    reason text NOT NULL,
    provider_refund_id text UNIQUE,
    fee_policy text NOT NULL CHECK (fee_policy IN ('fee_refunded','fee_retained')),
    status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','succeeded','failed')),
    created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE disputes (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    payment_id uuid NOT NULL REFERENCES payments(id),
    store_id uuid NOT NULL REFERENCES stores(id),
    provider_dispute_id text UNIQUE NOT NULL,
    amount_minor bigint NOT NULL CHECK (amount_minor > 0),
    status text NOT NULL CHECK (status IN ('needs_response','under_review','won','lost','closed')),
    created_at timestamptz NOT NULL DEFAULT now()
);

-- خريطة معرّف المزوّد → المتجر (بدون RLS: مطلوبة لربط الـ webhook قبل معرفة المتجر)
CREATE TABLE provider_refs (
    provider text NOT NULL,
    provider_payment_id text NOT NULL,
    store_id uuid NOT NULL REFERENCES stores(id),
    order_id uuid NOT NULL REFERENCES orders(id),
    PRIMARY KEY (provider, provider_payment_id)
);

CREATE TABLE webhook_events (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    provider text NOT NULL,
    event_id text NOT NULL,
    event_type text NOT NULL,
    payload jsonb NOT NULL,
    signature_valid boolean NOT NULL,
    status text NOT NULL DEFAULT 'received'
        CHECK (status IN ('received','processed','duplicate','rejected','failed')),
    received_at timestamptz NOT NULL DEFAULT now(),
    processed_at timestamptz,
    UNIQUE (provider, event_id)
);

-- دفتر مزدوج حقيقي: كل سطر له حساب واحد واتجاه واحد. مجموع المدين = مجموع الدائن
-- لكل entry_group يُتحقق منه داخل نفس المعاملة قبل التثبيت.
CREATE TABLE ledger_entries (
    id bigserial PRIMARY KEY,
    entry_group uuid NOT NULL,
    store_id uuid NOT NULL REFERENCES stores(id),
    order_id uuid REFERENCES orders(id),
    account text NOT NULL CHECK (account IN ('buyer_payment','merchant_receivable','platform_fee',
                                             'gateway_fee','refund_payable','dispute_hold','platform_earnings')),
    direction text NOT NULL CHECK (direction IN ('debit','credit')),
    amount_minor bigint NOT NULL CHECK (amount_minor > 0),
    currency char(3) NOT NULL,
    created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX ledger_store_idx ON ledger_entries(store_id);
CREATE INDEX ledger_group_idx ON ledger_entries(entry_group);

CREATE TABLE audit_log (
    id bigserial PRIMARY KEY,
    ts timestamptz NOT NULL DEFAULT now(),
    actor text NOT NULL,
    action text NOT NULL,
    resource text NOT NULL,
    result text NOT NULL DEFAULT 'ok',
    store_id uuid,
    meta jsonb NOT NULL DEFAULT '{}'::jsonb,
    prev_hash text NOT NULL,
    hash text NOT NULL,
    mac text NOT NULL
);

CREATE TABLE idempotency_keys (
    key text PRIMARY KEY,
    scope text NOT NULL,
    request_hash text NOT NULL,
    response jsonb,
    created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE files (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    store_id uuid NOT NULL REFERENCES stores(id),
    order_id uuid REFERENCES orders(id),
    object_key text NOT NULL UNIQUE,
    content_type text NOT NULL,
    size_bytes bigint NOT NULL CHECK (size_bytes > 0),
    sha256 text NOT NULL,
    scan_status text NOT NULL CHECK (scan_status IN ('pending','clean','infected','error')),
    created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE file_download_tokens (
    jti uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    file_id uuid NOT NULL REFERENCES files(id) ON DELETE CASCADE,
    store_id uuid NOT NULL REFERENCES stores(id),
    buyer_id text NOT NULL,
    expires_at timestamptz NOT NULL,
    used_at timestamptz
);

-- ============ قيود عدم القابلية للتعديل ============
CREATE OR REPLACE FUNCTION forbid_mutation() RETURNS trigger AS $$
BEGIN
    RAISE EXCEPTION 'append-only table %: % forbidden', TG_TABLE_NAME, TG_OP;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER ledger_append_only BEFORE UPDATE OR DELETE ON ledger_entries
    FOR EACH ROW EXECUTE FUNCTION forbid_mutation();
CREATE TRIGGER ledger_no_truncate BEFORE TRUNCATE ON ledger_entries
    FOR EACH STATEMENT EXECUTE FUNCTION forbid_mutation();

CREATE TRIGGER audit_append_only BEFORE UPDATE OR DELETE ON audit_log
    FOR EACH ROW EXECUTE FUNCTION forbid_mutation();
CREATE TRIGGER audit_no_truncate BEFORE TRUNCATE ON audit_log
    FOR EACH STATEMENT EXECUTE FUNCTION forbid_mutation();

-- ============ RLS ============
DO $$
DECLARE t text;
BEGIN
  FOREACH t IN ARRAY ARRAY['products','orders','order_items','payments','platform_fees',
                           'transfers','settlements','refunds','disputes','ledger_entries','files']
  LOOP
    EXECUTE format('ALTER TABLE %I ENABLE ROW LEVEL SECURITY', t);
    EXECUTE format('ALTER TABLE %I FORCE ROW LEVEL SECURITY', t);
    EXECUTE format($f$CREATE POLICY tenant_isolation ON %I
        USING (store_id = current_setting('app.store_id', true)::uuid)
        WITH CHECK (store_id = current_setting('app.store_id', true)::uuid)$f$, t);
  END LOOP;
END $$;

-- جداول على مستوى المنصة: منع الوصول الكامل لدور التطبيق إلا بمنح صريح
REVOKE ALL ON ALL TABLES IN SCHEMA public FROM PUBLIC;
GRANT USAGE ON SCHEMA public TO fibonix_app;
GRANT SELECT, INSERT, UPDATE ON accounts, sessions, stores, merchant_accounts,
      idempotency_keys, webhook_events, provider_refs TO fibonix_app;
GRANT SELECT, INSERT ON audit_log TO fibonix_app;
GRANT SELECT, INSERT, UPDATE, DELETE ON products, orders, order_items, payments, platform_fees,
      transfers, settlements, refunds, disputes, files, file_download_tokens TO fibonix_app;
GRANT SELECT, INSERT ON ledger_entries TO fibonix_app;
GRANT USAGE, SELECT ON SEQUENCE ledger_entries_id_seq TO fibonix_app;
GRANT USAGE, SELECT ON SEQUENCE audit_log_id_seq TO fibonix_app;
GRANT SELECT, INSERT ON revoked_jtis TO fibonix_app;

ALTER DEFAULT PRIVILEGES IN SCHEMA public
    REVOKE ALL ON TABLES FROM PUBLIC;
"""

DROP = """
DROP TABLE IF EXISTS file_download_tokens, files, idempotency_keys, audit_log,
    ledger_entries, provider_refs, webhook_events, disputes, refunds, settlements, transfers,
    platform_fees, payments, order_items, orders, products, merchant_accounts,
    stores, revoked_jtis, sessions, accounts CASCADE;
DROP FUNCTION IF EXISTS forbid_mutation() CASCADE;
"""


def upgrade() -> None:
    op.execute(SCHEMA)


def downgrade() -> None:
    op.execute(DROP)
