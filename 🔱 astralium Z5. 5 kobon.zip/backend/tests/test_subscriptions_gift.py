from app.modules.commerce.subscriptions import create_subscription, cancel_subscription, SUBS
from app.modules.commerce.giftcards import issue_card, redeem
from app.modules.commerce.courses import create_course, enroll, progress
from app.modules.commerce.bookings import book_service, BOOKINGS
from app.modules.orders.lifecycle import can_transition, deliver_digital
from app.modules.commerce.abandoned import save_cart, abandoned
from app.modules.ai.employees import list_employees, generate_book_outline


def test_subscription():
    s = create_subscription("s1", "a@example.com", 1000, "month")
    assert s["status"] == "active"
    cancel_subscription(s["id"])
    assert SUBS[s["id"]]["status"] == "canceled"


def test_giftcard():
    c = issue_card(5000)
    bal = redeem(c["code"], 2000)
    assert bal == 3000
    try:
        redeem(c["code"], 4000)
        raise AssertionError('expected rejection')
    except ValueError:
        pass


def test_course():
    cr = create_course("s1", "دورة فلك", ["درس1", "درس2"])
    enroll(cr["id"], "a@example.com")
    assert progress(cr["id"], "a@example.com", 1) == 1


def test_booking_conflict():
    BOOKINGS.clear()
    assert book_service("s1", "استشارة", "a@example.com", "2026-10-21T10:00")["slot"].startswith("2026")
    try:
        book_service("s1", "استشارة", "b@example.com", "2026-10-21T10:00")
        raise AssertionError('expected rejection')
    except ValueError:
        pass


def test_lifecycle():
    assert can_transition("pending", "paid")
    assert not can_transition("pending", "fulfilled")
    assert can_transition("paid", "refunded")


def test_digital_delivery():
    url = deliver_digital("s1", "o1", "a@example.com", "book.pdf", "secret-32bytes-long-for-test!!")
    assert "sig=" in url


def test_abandoned():
    save_cart("c1", "s1", [{"id": "p1"}], "a@example.com")
    # hack ts to old
    from app.modules.commerce.abandoned import CARTS

    CARTS["c1"]["ts"] = 0
    assert "c1" in abandoned(hours=1)


def test_ai_employees():
    assert len(list_employees("manager")) == 5
    assert len(list_employees("merchant")) == 7
    b = generate_book_outline("الفلك")
    assert "chapters" in b
