"""عزل المتاجر (IDOR)، CORS، ترويسات، رفع ملفات، وصلاحية الروابط."""

from __future__ import annotations



def test_idor_cross_store_products(client, make_merchant):
    a = make_merchant()
    b = make_merchant()
    r = client.get(f"/stores/{b['store_id']}/products", headers=a["headers"])
    assert r.status_code == 403


def test_idor_cross_store_write(client, make_merchant):
    a = make_merchant()
    b = make_merchant()
    r = client.post(f"/stores/{b['store_id']}/products", json={"title": "x", "price_minor": 100},
                    headers=a["headers"])
    assert r.status_code == 403


def test_idor_cross_store_order(client, make_merchant):
    a = make_merchant()
    b = make_merchant()
    r = client.post("/orders", json={"store_id": b["store_id"], "amount_cents": 100}, headers=a["headers"])
    assert r.status_code == 403


def test_idor_cross_store_ledger(client, make_merchant):
    a = make_merchant()
    b = make_merchant()
    r = client.get(f"/stores/{b['store_id']}/ledger/verify", headers=a["headers"])
    assert r.status_code == 403


def test_cors_does_not_reflect_evil_origin(client):
    r = client.get("/health", headers={"Origin": "https://evil.example"})
    assert r.headers.get("access-control-allow-origin") is None


def test_security_headers_present(client):
    h = client.get("/health").headers
    for name in ("Strict-Transport-Security", "X-Content-Type-Options", "X-Frame-Options",
                 "Referrer-Policy", "Permissions-Policy", "Content-Security-Policy"):
        assert name in h


def test_upload_requires_auth(client, db):
    r = client.post("/files/upload", content=b"\x89PNG\r\n\x1a\n" + b"0" * 32,
                    headers={"x-filename": "a.png"})
    assert r.status_code == 401


def test_download_url_requires_auth(client, db):
    r = client.post("/files/download/00000000-0000-0000-0000-000000000000")
    assert r.status_code == 401


def test_expired_and_tampered_link_rejected(client, db):
    from app.modules.files.service import sign_url, verify_signed_url

    secret = "unit-test-secret-not-real-000000"
    url = sign_url(secret, "private", "key", "buyer1", 1)
    assert "sig=" in url and "s3.example" not in url
    exp = str(int(__import__("time").time()) + 10)
    import hashlib
    import hmac
    import time as t

    sig = hmac.new(secret.encode(), f"private/key:buyer1:{exp}".encode(), hashlib.sha256).hexdigest()
    assert verify_signed_url(secret, "private", "key", "buyer1", exp, sig)
    old = str(int(t.time()) - 10)
    old_sig = hmac.new(secret.encode(), f"private/key:buyer1:{old}".encode(), hashlib.sha256).hexdigest()
    assert not verify_signed_url(secret, "private", "key", "buyer1", old, old_sig)
    assert not verify_signed_url(secret, "private", "key", "buyer1", exp, "f" * 64)
