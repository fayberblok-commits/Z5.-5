from app.modules.ledger.service import Ledger, split_sale


def test_free_product():
    m, f = split_sale(0)
    assert m == 0 and f == 0
    ledger = Ledger()
    # free order -> no ledger entries
    assert ledger.verify_zero_diff() == 0


def test_under_2_product_ledger():
    # منتج 1.5$ -> 150 cents، المنصة تأخذ 150، التاجر 0 — موثق
    m, f = split_sale(150)
    assert m == 0 and f == 150
    ledger = Ledger()
    ledger.post("s1", "o1", "buyer_payment", "platform_fee", f)
    assert ledger.verify_zero_diff() == 0


def test_multi_merchant_cart_ledger():
    ledger = Ledger()
    for store, amt in [("A", 1000), ("B", 2000)]:
        m, f = split_sale(amt)
        ledger.post(store, f"o_{store}", "buyer_payment", "merchant_receivable", m)
        if f:
            ledger.post(store, f"o_{store}", "buyer_payment", "platform_fee", f)
    assert ledger.verify_zero_diff() == 0


def test_dispute():
    ledger = Ledger()
    ledger.post("s1", "o1", "buyer_payment", "merchant_receivable", 800)
    ledger.post("s1", "o1", "buyer_payment", "platform_fee", 200)
    # نزاع -> تجميد
    ledger.post("s1", "o1", "dispute_hold", "merchant_receivable", 800)
    assert ledger.verify_zero_diff() == 0
