"""fuzzing للمدخلات — حقن عشوائي."""

from app.modules.files.service import quarantine_reason
from app.modules.templates_engine.engine import render_template
import random
import string


def fuzz_filename():
    for _ in range(100):
        name = "".join(random.choices(string.printable, k=20))
        try:
            quarantine_reason(b"hello", name)
        except Exception as exc:  # noqa: BLE001 — أي انهيار غير متحكم به يفشل الاختبار
            raise AssertionError(f"crash on {name}: {exc}") from exc


def fuzz_template():
    payloads = ["{{7*7}}", "{% for %}", "<% eval %>", "<script>" + "a" * 1000, "A" * 100000]
    for p in payloads:
        try:
            render_template(p, {})
        except (ValueError, TypeError):
            pass  # controlled rejection only


def test_fuzz_filename():
    fuzz_filename()


def test_fuzz_template():
    fuzz_template()
