"""سجل التدقيق: سلسلة تجزئة + MAC، كشف التعديل/الحذف/التزوير، وتنقية الأسرار."""

from __future__ import annotations

import pytest

from app.core.audit import audit_append, redact, verify_chain
from app.core.db import atomic


def _seed(conn, n=3):
    for i in range(n):
        audit_append(conn, actor=f"user{i}", action="test", resource=f"res:{i}",
                     meta={"i": i, "password": "should-not-appear", "nested": {"token": "secret"}})


def test_chain_valid(db):
    with atomic() as conn:
        _seed(conn)
    with atomic() as conn:
        report = verify_chain(conn)
    assert report["valid"] is True
    assert report["entries"] == 3


def test_secrets_redacted(db):
    with atomic() as conn:
        _seed(conn, 1)
    with atomic() as conn:
        row = conn.execute("SELECT meta FROM audit_log").fetchone()
    assert row["meta"]["password"] == "[redacted]"
    assert row["meta"]["nested"]["token"] == "[redacted]"
    assert "should-not-appear" not in str(row["meta"])


def test_redact_helper():
    assert redact({"api_key": "x", "ok": 1}) == {"api_key": "[redacted]", "ok": 1}
    assert redact(None) == {}


def test_tampering_detected(db, owner_conn):
    with atomic() as conn:
        _seed(conn)
    # المهاجم بصلاحيات عالية يعطّل trigger ثم يعدّل صفًا
    owner_conn.execute("ALTER TABLE audit_log DISABLE TRIGGER audit_append_only")
    owner_conn.execute("UPDATE audit_log SET actor='attacker' WHERE id=2")
    owner_conn.commit()
    owner_conn.execute("ALTER TABLE audit_log ENABLE TRIGGER audit_append_only")
    owner_conn.commit()
    with atomic() as conn:
        report = verify_chain(conn)
    assert report["valid"] is False
    assert any("tampered" in p["problem"] or "hash" in p["problem"] or "MAC" in p["problem"]
               for p in report["problems"])


def test_deletion_detected(db, owner_conn):
    with atomic() as conn:
        _seed(conn)
    owner_conn.execute("ALTER TABLE audit_log DISABLE TRIGGER audit_append_only")
    owner_conn.execute("DELETE FROM audit_log WHERE id=2")
    owner_conn.commit()
    owner_conn.execute("ALTER TABLE audit_log ENABLE TRIGGER audit_append_only")
    owner_conn.commit()
    with atomic() as conn:
        report = verify_chain(conn)
    assert report["valid"] is False
    assert any("gap" in p["problem"] or "link" in p["problem"] for p in report["problems"])


def test_forged_chain_without_key_detected(db, owner_conn):
    """إعادة حساب السلسلة بلا معرفة AUDIT_HMAC_KEY ⇒ MAC لا يطابق."""
    import hashlib
    import json

    with atomic() as conn:
        _seed(conn, 2)
    owner_conn.execute("ALTER TABLE audit_log DISABLE TRIGGER audit_append_only")
    owner_conn.execute("UPDATE audit_log SET actor='forged' WHERE id=1")
    rows = owner_conn.execute("SELECT * FROM audit_log ORDER BY id").fetchall()
    prev = "0" * 64
    for row in rows:
        entry = {"actor": row["actor"], "action": row["action"], "resource": row["resource"],
                 "result": row["result"],
                 "store_id": str(row["store_id"]) if row["store_id"] else None,
                 "meta": row["meta"] if isinstance(row["meta"], dict) else json.loads(row["meta"])}
        digest = hashlib.sha256(prev.encode() + json.dumps(entry, sort_keys=True, separators=(",", ":"),
                                                           ensure_ascii=False).encode()).hexdigest()
        owner_conn.execute("UPDATE audit_log SET prev_hash=%s, hash=%s WHERE id=%s", (prev, digest, row["id"]))
        prev = digest
    owner_conn.commit()
    owner_conn.execute("ALTER TABLE audit_log ENABLE TRIGGER audit_append_only")
    owner_conn.commit()
    with atomic() as conn:
        report = verify_chain(conn)
    assert report["valid"] is False
    assert any("MAC" in p["problem"] for p in report["problems"])


def test_append_only_blocks_update_and_delete(db, owner_conn):
    import psycopg

    with atomic() as conn:
        _seed(conn, 1)
    with pytest.raises(psycopg.errors.RaiseException):
        owner_conn.execute("UPDATE audit_log SET actor='x'")
    owner_conn.rollback()
    with pytest.raises(psycopg.errors.RaiseException):
        owner_conn.execute("DELETE FROM audit_log")
    owner_conn.rollback()
