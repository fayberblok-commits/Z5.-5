"""Fail-first regressions: streamed uploads and business-event idempotency."""
from __future__ import annotations

import pytest
from starlette.requests import Request

from app.core.config import get_settings
from app.modules.payments.mock_transport import StripeMockState
from tests.integration.test_money_flow import (
    _create_and_pay, _fee_row, _ledger_rows, _merchant_with_connect, _transfers, _webhook,
)


@pytest.fixture(autouse=True)
def reset_mock():
    StripeMockState.reset()
    yield
    StripeMockState.reset()


def test_anonymous_upload_is_rejected_without_reading_body(client, db, monkeypatch):
    async def forbidden_body(self):
        raise AssertionError('Anonymous upload body must not be buffered')
    monkeypatch.setattr(Request, 'body', forbidden_body)
    response = client.post('/files/upload', content=b'untrusted')
    assert response.status_code == 401


@pytest.mark.parametrize('declared', ['invalid', '-1', '+4', '1,1', '9' * 5000])
def test_malformed_or_extreme_upload_length_never_500(client, make_merchant, declared):
    merchant = make_merchant()
    response = client.post('/files/upload', content=b'data',
                           headers={**merchant['headers'], 'content-length': declared})
    assert response.status_code in (400, 413)


def test_chunked_upload_limit_is_413_before_storage(client, make_merchant, monkeypatch):
    import app.main as main
    merchant = make_merchant()
    settings = get_settings().model_copy(update={'max_upload_bytes': 8})
    monkeypatch.setattr(main, 'get_settings', lambda: settings)
    response = client.post('/files/upload', content=iter([b'abcd', b'efgh', b'ijkl']),
                           headers=merchant['headers'])
    assert response.status_code == 413


def test_same_payment_two_success_events_do_not_double_book(client, make_merchant):
    merchant = _merchant_with_connect(client, make_merchant)
    _, pi = _create_and_pay(client, merchant, 7000)
    event = {'id': 'evt_success_one', 'type': 'payment_intent.succeeded',
             'data': {'object': {'id': pi, 'amount': 7000}}}
    assert _webhook(client, event).status_code == 200
    first_ledger = _ledger_rows(merchant['store_id'])
    first_fee = _fee_row(merchant['store_id'])
    event['id'] = 'evt_success_two'
    assert _webhook(client, event).status_code == 200
    assert _ledger_rows(merchant['store_id']) == first_ledger
    assert _fee_row(merchant['store_id']) == first_fee
    assert len(_transfers(merchant['store_id'])) == 1


def test_stale_payment_failure_does_not_downgrade_success(client, make_merchant, owner_conn):
    merchant = _merchant_with_connect(client, make_merchant)
    order, pi = _create_and_pay(client, merchant, 7000)
    assert _webhook(client, {'id': 'evt_paid_first', 'type': 'payment_intent.succeeded',
                             'data': {'object': {'id': pi, 'amount': 7000}}}).status_code == 200
    assert _webhook(client, {'id': 'evt_failure_late', 'type': 'payment_intent.payment_failed',
                             'data': {'object': {'id': pi}}}).status_code == 200
    row = owner_conn.execute('SELECT status FROM payments WHERE order_id=%s', (order,)).fetchone()
    assert row['status'] == 'paid'
    assert _fee_row(merchant['store_id'])['status'] == 'processing'


@pytest.mark.parametrize('payload', [None, [], {}, {'id': 4, 'type': 'payment_intent.succeeded'},
                                    {'id': 'evt_bad_data', 'type': 'payment_intent.succeeded', 'data': []},
                                    {'id': 'evt_bad_obj', 'type': 'payment_intent.succeeded',
                                     'data': {'object': []}}],
                         ids=['null', 'list', 'empty', 'numeric-id', 'list-data', 'list-object'])
def test_signed_malformed_webhook_is_400_not_500(client, db, payload):
    from tests.integration.test_money_flow import _signed
    signed = _signed(client, payload)
    response = client.post('/webhooks/stripe', **signed)
    assert response.status_code == 400


def test_invalid_webhook_signature_does_not_open_database(monkeypatch):
    import app.modules.payments.service as payments
    from app.modules.payments.stripe_connect import StripeConnectClient
    def forbidden_transaction():
        raise AssertionError('Invalid signatures must be rejected before DB access')
    monkeypatch.setattr(payments, 'atomic', forbidden_transaction)
    with pytest.raises(payments.PaymentError):
        payments.process_webhook(client=StripeConnectClient('sk_test_' + 'a' * 32),
                                 raw_body=b'{"id":"evt_bad","type":"x"}',
                                 signature_header='invalid', webhook_secret='not-a-provider-secret')
