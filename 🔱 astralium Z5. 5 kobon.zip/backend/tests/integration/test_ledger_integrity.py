"""سلامة الدفتر: مدين=دائن فعليًا، قيد ناقص مستحيل، append-only، وكشف العبث."""

from __future__ import annotations

import os
import subprocess
import sys
import pathlib
import uuid

import psycopg
import pytest

from app.core.db import tenant
from app.modules.ledger import repository as ledger
from app.modules.ledger.service import Ledger, split_sale


pytestmark = pytest.mark.usefixtures("db")


def _store(owner_conn) -> str:
    email = f"l-{uuid.uuid4().hex[:10]}@example.com"
    acc = owner_conn.execute(
        "INSERT INTO accounts (email, password_hash, role) VALUES (%s,'h','merchant') RETURNING id", (email,)
    ).fetchone()["id"]
    sid = owner_conn.execute(
        "INSERT INTO stores (name, owner_id) VALUES ('L',%s) RETURNING id", (acc,)
    ).fetchone()["id"]
    owner_conn.commit()
    return str(sid)


def test_split_sale_policies():
    assert split_sale(7000) == (6800, 200)
    assert split_sale(200) == (0, 200)
    assert split_sale(199) == (0, 199)
    assert split_sale(0) == (0, 0)
    assert split_sale(1) == (0, 1)


def test_in_memory_ledger_really_verifies():
    lg = Ledger()
    lg.post("s", "o", "buyer_payment", "merchant_receivable", 6800)
    lg.post("s", "o", "buyer_payment", "platform_fee", 200)
    assert lg.verify_zero_diff() == 0
    # سطر مفرد مُدخل يدويًا يكشف اختلال التوازن (لا تُعيد صفرًا بلا فحص)
    lg.entries.append(lg.entries[0].__class__(
        id="x", store_id="s", order_id="o", account="buyer_payment", direction="debit",
        amount_minor=500, currency="USD", entry_group="bad-group"))
    assert lg.verify_zero_diff() == 500


def test_post_group_rejects_unbalanced(owner_conn):
    sid = _store(owner_conn)
    with tenant(sid) as conn:
        with pytest.raises(ledger.LedgerError):
            ledger.post_group(conn, store_id=sid, order_id=None,
                              lines=[("buyer_payment", "debit", 7000), ("platform_fee", "credit", 200)],
                              currency="USD")


@pytest.mark.parametrize("bad", [
    ("buyer_payment", "debit", 0),
    ("buyer_payment", "debit", -100),
    ("unknown_account", "debit", 100),
    ("buyer_payment", "sideways", 100),
])
def test_post_group_rejects_invalid_lines(owner_conn, bad):
    sid = _store(owner_conn)
    with tenant(sid) as conn:
        with pytest.raises(ledger.LedgerError):
            ledger.post_group(conn, store_id=sid, order_id=None, lines=[bad], currency="USD")


def test_ledger_append_only_triggers(owner_conn):
    sid = _store(owner_conn)
    with tenant(sid) as conn:
        ledger.post_group(conn, store_id=sid, order_id=None,
                          lines=[("buyer_payment", "debit", 100), ("platform_fee", "credit", 100)],
                          currency="USD")
    for stmt in ("UPDATE ledger_entries SET amount_minor=1", "DELETE FROM ledger_entries"):
        with pytest.raises(psycopg.errors.RaiseException):
            owner_conn.execute(stmt)
        owner_conn.rollback()  # كل محاولة في معاملة مستقلة


def test_verify_balanced_detects_tampering(owner_conn):
    sid = _store(owner_conn)
    with tenant(sid) as conn:
        ledger.post_sale(conn, store_id=sid, order_id=None, gross_minor=7000,
                         gateway_fee_minor=0, currency="USD")
    assert ledger.verify_balanced(sid)["balanced"] is True

    # إدخال مجموعة غير متوازنة مباشرة (كما يفعل من يملك صلاحية الكتابة) → يجب كشفها
    with tenant(sid) as conn:
        conn.execute(  # nosec B608 — استعلام ثابت بقيم مربوطة (اختبار)
            """INSERT INTO ledger_entries (entry_group, store_id, order_id, account, direction, amount_minor, currency)
               VALUES (%s,%s,NULL,'buyer_payment','debit',500,'USD')""",
            (uuid.uuid4(), sid),
        )
    report = ledger.verify_balanced(sid)
    assert report["balanced"] is False
    assert report["unbalanced_groups"] or report["single_line_groups"]


def test_process_kill_leaves_no_partial_entries(owner_conn, pg_server):
    """قتل العملية أثناء الكتابة: المعاملة تُلغى كاملة، فلا قيد ناقص."""
    sid = _store(owner_conn)
    worker = pathlib.Path(__file__).with_name("_kill_worker.py")
    result = subprocess.run(  # noqa: S603 — مفسّر بايثون مع سكربت اختباري ثابت
        [sys.executable, str(worker), pg_server["dsn"], sid],
        capture_output=True, text=True, env={**os.environ}, check=False,
    )
    assert result.returncode == 9, result.stderr
    report = ledger.verify_balanced(sid)
    assert report["rows_checked"] == 0
    assert report["balanced"] is True


def test_balanced_report_counts(owner_conn):
    sid = _store(owner_conn)
    with tenant(sid) as conn:
        ledger.post_sale(conn, store_id=sid, order_id=None, gross_minor=7000, gateway_fee_minor=0)
    report = ledger.verify_balanced(sid)
    assert report["groups_checked"] == 1
    assert report["rows_checked"] == 3
    assert report["per_currency_diff"] == {"USD": 0}


def test_balance_accounts(owner_conn):
    sid = _store(owner_conn)
    with tenant(sid) as conn:
        ledger.post_sale(conn, store_id=sid, order_id=None, gross_minor=7000, gateway_fee_minor=0)
    assert ledger.balance("buyer_payment", sid) == 7000
    assert ledger.balance("platform_fee", sid) == -200
    assert ledger.balance("merchant_receivable", sid) == -6800
