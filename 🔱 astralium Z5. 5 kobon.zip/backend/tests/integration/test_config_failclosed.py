"""الإعدادات fail-closed: لا أسرار افتراضية، ولا إقلاع بإعدادات ناقصة أو ضعيفة."""

from __future__ import annotations

import os
import secrets
import pathlib

import pytest
from pydantic import ValidationError

from app.core.config import ConfigError, Settings, get_settings, reset_settings_cache

# قيم عشوائية وليست أسرارًا حقيقية (تُولّد عند التشغيل)
_r = lambda n: secrets.token_urlsafe(n)  # noqa: E731

REQUIRED = {
    "APP_BASE_URL": "https://app.example.test",
    "ADMIN_BASE_URL": "https://admin.example.test",
    "APP_SECRET_KEY": _r(30),
    "JWT_SECRET": _r(30),
    "AUDIT_HMAC_KEY": _r(30),
    "ENCRYPTION_KEK": _r(30),
    "STRIPE_SECRET_KEY": "sk_test_" + secrets.token_hex(16),
    "STRIPE_WEBHOOK_SECRET": "whsec_" + secrets.token_hex(20),
    "STRIPE_CONNECT_CLIENT_ID": "ca_" + secrets.token_hex(18),
    "DATABASE_URL": "postgresql://u:p@db:5432/fibonix?sslmode=require",
    "REDIS_URL": "redis://redis:6379/0",
    "S3_ENDPOINT": "https://s3.example.test",
    "S3_ACCESS_KEY": _r(18),
    "S3_SECRET_KEY": _r(30),
    "S3_BUCKET_PRIVATE": "priv",
    "S3_BUCKET_PUBLIC": "pub",
    "CLAMAV_HOST": "clamav",
    "ADMIN_ALLOWED_IPS": "203.0.113.7",
}


def _settings(monkeypatch, **overrides):
    # عزل كامل: أي متغير بيئي متروك من اختبار آخر قد يغيّر النتيجة (كان يسبب فشلًا متقطعًا)
    for key in list(Settings.model_fields):
        monkeypatch.delenv(key.upper(), raising=False)
        monkeypatch.delenv(key, raising=False)
    monkeypatch.delenv("STRIPE_MOCK_TRANSPORT", raising=False)
    env = dict(REQUIRED)
    env.update(overrides)
    for k, v in env.items():
        if v is not None:
            monkeypatch.setenv(k, v)
    return Settings()


def test_valid_settings(monkeypatch):
    s = _settings(monkeypatch, APP_ENV="production")
    assert s.app_env == "production"
    assert s.secret("jwt_secret") == os.environ["JWT_SECRET"]


@pytest.mark.parametrize("field", ["JWT_SECRET", "APP_SECRET_KEY", "STRIPE_WEBHOOK_SECRET", "DATABASE_URL"])
def test_missing_required_field_fails(monkeypatch, field):
    with pytest.raises(ValidationError):
        _settings(monkeypatch, APP_ENV="production", **{field: None})


@pytest.mark.parametrize("value", [
    "change-me-please-change-me-please-123",
    "short",
    "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",  # entropy منخفضة
    "your-secret-key-here-0123456789abc",
])
def test_weak_or_placeholder_secret_rejected(monkeypatch, value):
    with pytest.raises(ValidationError):
        _settings(monkeypatch, APP_ENV="production", JWT_SECRET=value)


def test_wrong_stripe_key_shape(monkeypatch):
    with pytest.raises(ValidationError):
        _settings(monkeypatch, APP_ENV="production", STRIPE_SECRET_KEY="not-a-stripe-key")


def test_production_requires_https_and_admin_ips(monkeypatch):
    with pytest.raises(ValidationError):
        _settings(monkeypatch, APP_ENV="production", APP_BASE_URL="http://insecure.test")
    with pytest.raises(ValidationError):
        _settings(monkeypatch, APP_ENV="production", ADMIN_ALLOWED_IPS="")


def test_production_requires_sslmode(monkeypatch):
    with pytest.raises(ValidationError):
        _settings(monkeypatch, APP_ENV="production", DATABASE_URL="postgresql://u:p@db:5432/fibonix")


def test_get_settings_raises_config_error(monkeypatch):
    for key in REQUIRED:
        monkeypatch.delenv(key, raising=False)
    reset_settings_cache()
    with pytest.raises(ConfigError):
        get_settings()
    reset_settings_cache()


def test_no_fallback_secrets_in_source():
    """لا توجد قيم سرية افتراضية في كود التطبيق."""
    root = pathlib.Path(__file__).resolve().parents[2] / "app"
    forbidden = ["s3-fallback", "whsec_test_fallback", "fallback-test-secret",
                 "sk_test_change_me", "dev-secret"]
    hits = []
    for path in root.rglob("*.py"):
        text = path.read_text(encoding="utf-8")
        for token in forbidden:
            if token in text:
                hits.append(f"{path.name}: {token}")
    assert not hits, hits
    # ولا توجد أي قيمة سرية افتراضية بصيغة os.environ.get(SECRET, "<قيمة>")
    import re as _re

    default_secret = _re.compile(r"environ\.get\(\s*['\"][A-Z_]*(SECRET|KEY|TOKEN|PASSWORD)['\"]\s*,")
    leaks = [f"{p.name}" for p in root.rglob("*.py") if default_secret.search(p.read_text(encoding="utf-8"))]
    assert not leaks, leaks


def test_placeholder_list_only_in_denylist():
    """عبارات مثل change-me تظهر فقط داخل قائمة الرفض، لا كقيمة افتراضية."""
    cfg = (pathlib.Path(__file__).resolve().parents[2] / "app" / "core" / "config.py").read_text()
    assert cfg.count("change-me") == 1  # داخل _PLACEHOLDER_PATTERNS فقط


def test_settings_have_no_default_secrets():
    """كل الحقول الحساسة بلا قيم افتراضية في تعريفها."""
    sensitive = ["app_secret_key", "jwt_secret", "audit_hmac_key", "encryption_kek",
                 "stripe_secret_key", "stripe_webhook_secret", "database_url", "s3_secret_key"]
    for field in sensitive:
        info = Settings.model_fields[field]
        assert info.is_required(), f"{field} has a default value — forbidden"


def test_configuration_errors_do_not_echo_secret_inputs(monkeypatch):
    value = 'sk_test_' + secrets.token_hex(24) + '!'
    with pytest.raises(ValidationError) as caught:
        _settings(monkeypatch, APP_ENV='test', S3_ENDPOINT='http://localhost:9000', STRIPE_SECRET_KEY=value)
    assert value not in str(caught.value)
    reset_settings_cache()
    try:
        with pytest.raises(ConfigError) as wrapped:
            get_settings()
        assert value not in str(wrapped.value)
        assert wrapped.value.__cause__ is None
    finally:
        reset_settings_cache()


@pytest.mark.parametrize('environment', ['production', 'staging', 'development'])
def test_mock_payment_transport_rejected_outside_test(monkeypatch, environment):
    with pytest.raises(ValidationError):
        _settings(monkeypatch, APP_ENV=environment, STRIPE_MOCK_TRANSPORT="1")
