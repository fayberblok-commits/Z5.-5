"""المصادقة والجلسات: Argon2id، قفل، تدوير، إبطال، TOTP، CSRF، ربط جهاز، step-up."""

from __future__ import annotations

import base64
import json
import time
import uuid

import jwt
import pytest
from argon2 import PasswordHasher

from app.modules.auth import service as auth

PASSWORD = "StrongPassw0rd!23"


def _register(client, email=None):
    email = email or f"u{uuid.uuid4().hex[:8]}@example.com"
    r = client.post("/auth/register", json={"email": email, "password": PASSWORD, "store_name": "S"})
    assert r.status_code == 200, r.text
    return email, r.json()["store_id"]


def test_weak_password_rejected(client, db):
    for pw in ("short1!A", "alllowercase123", "ALLUPPERCASE123", "NoDigitsHere!!"):
        r = client.post("/auth/register", json={"email": "weak@example.com", "password": pw, "store_name": "S"})
        assert r.status_code in (400, 422), (pw, r.status_code)


def test_register_audit_has_no_credential_material(client, db, owner_conn):
    """انحدار: سجل التدقيق عند التسجيل لا يحتوي أي مفتاح/قيمة اعتماد، ولا كلمة مرور ولو شكلية."""
    email, _ = _register(client)
    rows = owner_conn.execute(
        "SELECT meta FROM audit_log WHERE action='register' AND actor=%s", (email,)
    ).fetchall()
    assert len(rows) == 1
    meta = rows[0]["meta"]
    assert set(meta) == {"role"}
    blob = str(meta).lower()
    for banned in ("password", "passwd", "secret", "token", "hash"):
        assert banned not in blob
    # ولا توجد قيمة صورية مثل "never-logged" تُوهم بأن شيئًا سُجّل
    assert "never-logged" not in blob


def test_argon2id_hash_used(client, db, owner_conn):
    email, _ = _register(client)
    h = owner_conn.execute("SELECT password_hash FROM accounts WHERE email=%s", (email,)).fetchone()["password_hash"]
    assert h.startswith("$argon2id$")


def test_password_rehash_on_login(client, db, owner_conn):
    email, _ = _register(client)
    weak_params = PasswordHasher(time_cost=1, memory_cost=8, parallelism=1, hash_len=16, salt_len=8)
    old_hash = weak_params.hash(PASSWORD)
    owner_conn.execute("UPDATE accounts SET password_hash=%s WHERE email=%s", (old_hash, email))
    owner_conn.commit()
    r = client.post("/auth/login", json={"email": email, "password": PASSWORD})
    assert r.status_code == 200
    new_hash = owner_conn.execute("SELECT password_hash FROM accounts WHERE email=%s", (email,)).fetchone()["password_hash"]
    assert new_hash != old_hash
    assert new_hash.startswith("$argon2id$")


def test_account_enumeration_same_response_and_timing(client, db):
    _register(client, "known@example.com")
    t0 = time.perf_counter()
    r1 = client.post("/auth/login", json={"email": "known@example.com", "password": "WrongPassw0rd!23"})
    t1 = time.perf_counter()
    r2 = client.post("/auth/login", json={"email": "nobody@example.com", "password": "WrongPassw0rd!23"})
    t2 = time.perf_counter()
    assert r1.status_code == r2.status_code == 401
    assert r1.json() == r2.json()
    # زمن مماثل (هامش 3x) لمنع التعداد عبر التوقيت
    assert max(t1 - t0, t2 - t1) / max(1e-6, min(t1 - t0, t2 - t1)) < 3.0


def test_lockout_after_failures(client, db):
    email, _ = _register(client)
    for _ in range(5):
        r = client.post("/auth/login", json={"email": email, "password": "WrongPassw0rd!23"})
        assert r.status_code == 401
    r = client.post("/auth/login", json={"email": email, "password": PASSWORD})
    assert r.status_code == 423


def test_session_cookie_flags(client, db):
    email, _ = _register(client)
    r = client.post("/auth/login", json={"email": email, "password": PASSWORD})
    cookies = r.headers.get_list("set-cookie")
    session_cookie = next(c for c in cookies if c.startswith("__Host-session="))
    assert "Secure" in session_cookie and "HttpOnly" in session_cookie
    assert "SameSite=strict" in session_cookie
    assert "Path=/" in session_cookie


def test_csrf_required_for_cookie_requests(client, db):
    email, _ = _register(client)
    r = client.post("/auth/login", json={"email": email, "password": PASSWORD})
    csrf = r.json()["csrf_token"]
    client.cookies.set("__Host-session", r.cookies["__Host-session"], domain="testserver.local", path="/")
    # بلا ترويسة CSRF → 403
    r = client.post("/auth/logout", headers={"X-CSRF-Token": "wrong"})
    assert r.status_code == 403
    r = client.post("/auth/logout", headers={"X-CSRF-Token": csrf})
    assert r.status_code == 200


def test_logout_revokes_session(client, db, owner_conn):
    email, _ = _register(client)
    r = client.post("/auth/login", json={"email": email, "password": PASSWORD})
    token = r.json()["access_token"]
    csrf = r.json()["csrf_token"]
    session_token = r.cookies["__Host-session"]
    # الجلسة صالحة قبل الخروج
    with owner_conn.transaction():
        s = auth.resolve_session(owner_conn, token=session_token,
                                 user_agent="testclient", accept_language="", client_hint="")
        assert s["email"] == email
    r = client.post("/auth/logout", headers={"Authorization": f"Bearer {token}", "X-CSRF-Token": csrf})
    assert r.status_code == 200
    with pytest.raises(auth.AuthError):
        auth.resolve_session(owner_conn, token=session_token,
                             user_agent="testclient", accept_language="", client_hint="")


def test_session_rotation(client, db, owner_conn):
    email, _ = _register(client)
    r = client.post("/auth/login", json={"email": email, "password": PASSWORD})
    old = r.cookies["__Host-session"]
    with owner_conn.transaction():
        s = auth.resolve_session(owner_conn, token=old, user_agent="testclient",
                                 accept_language="", client_hint="", rotate=True)
    new = s["rotated_token"]
    assert new != old
    with pytest.raises(auth.AuthError):
        auth.resolve_session(owner_conn, token=old, user_agent="testclient",
                             accept_language="", client_hint="")
    with owner_conn.transaction():
        assert auth.resolve_session(owner_conn, token=new, user_agent="testclient",
                                    accept_language="", client_hint="")["email"] == email


def test_device_binding_revokes_on_mismatch(client, db, owner_conn):
    email, _ = _register(client)
    r = client.post("/auth/login", json={"email": email, "password": PASSWORD})
    token = r.cookies["__Host-session"]
    with pytest.raises(auth.AuthError):
        auth.resolve_session(owner_conn, token=token, user_agent="different-agent",
                             accept_language="", client_hint="")
    # الجلسة أُبطلت بعد محاولة الجهاز المختلف
    with pytest.raises(auth.AuthError):
        auth.resolve_session(owner_conn, token=token, user_agent="testclient",
                             accept_language="", client_hint="")


def test_jwt_revocation(client, db, owner_conn):
    email, _ = _register(client)
    r = client.post("/auth/login", json={"email": email, "password": PASSWORD})
    body = r.json()
    assert client.get("/me", headers={"Authorization": f"Bearer {body['access_token']}"}).status_code == 200
    with owner_conn.transaction():
        auth.revoke_jti(owner_conn, body["jti"], int(time.time()) + 600)
    assert client.get("/me", headers={"Authorization": f"Bearer {body['access_token']}"}).status_code == 401


def test_jwt_wrong_secret_rejected(client, db):
    email, _ = _register(client)
    r = client.post("/auth/login", json={"email": email, "password": PASSWORD})
    token = r.json()["access_token"]
    tampered = token[:-4] + ("aaaa" if token[-4:] != "aaaa" else "bbbb")
    assert client.get("/me", headers={"Authorization": f"Bearer {tampered}"}).status_code == 401


def test_totp_enroll_confirm_and_login(client, db):
    email, _ = _register(client)
    r = client.post("/auth/login", json={"email": email, "password": PASSWORD})
    h = {"Authorization": f"Bearer {r.json()['access_token']}"}
    r = client.post("/auth/totp/enroll", headers=h)
    assert r.status_code == 200
    secret = r.json()["secret"]
    import pyotp

    code = pyotp.TOTP(secret).now()
    assert client.post("/auth/totp/confirm", params={"code": code}, headers=h).status_code == 200
    # الآن الدخول يتطلب TOTP
    assert client.post("/auth/login", json={"email": email, "password": PASSWORD}).status_code == 401
    assert client.post("/auth/login", json={"email": email, "password": PASSWORD, "totp_code": "000000"}).status_code == 401
    r = client.post("/auth/login", json={"email": email, "password": PASSWORD, "totp_code": pyotp.TOTP(secret).now()})
    assert r.status_code == 200


def test_totp_secret_encrypted_at_rest(client, db, owner_conn):
    email, _ = _register(client)
    r = client.post("/auth/login", json={"email": email, "password": PASSWORD})
    h = {"Authorization": f"Bearer {r.json()['access_token']}"}
    secret = client.post("/auth/totp/enroll", headers=h).json()["secret"]
    blob = owner_conn.execute("SELECT totp_secret_enc FROM accounts WHERE email=%s", (email,)).fetchone()["totp_secret_enc"]
    assert secret not in blob
    import base64

    raw = base64.b64decode(blob)
    assert secret.encode() not in raw


def _make_owner(owner_conn, email="owner@example.com"):
    from app.core.security import hash_password

    row = owner_conn.execute(
        "INSERT INTO accounts (email, password_hash, role) VALUES (%s,%s,'owner') RETURNING id",
        (email, hash_password(PASSWORD)),
    ).fetchone()
    owner_conn.commit()
    return str(row["id"])


def test_admin_requires_step_up_and_totp(client, db, owner_conn):
    _make_owner(owner_conn)
    r = client.post("/auth/login", json={"email": "owner@example.com", "password": PASSWORD})
    token = r.json()["access_token"]
    csrf = r.json()["csrf_token"]
    # JWT وحده لا يكفي للوصول الإداري (يلزم جلسة تفاعلية + step-up)
    assert client.get("/admin/overview", headers={"Authorization": f"Bearer {token}"}).status_code == 403
    client.cookies.set("__Host-session", r.cookies["__Host-session"], domain="testserver.local", path="/")
    client.cookies.set("__Host-csrf", csrf, domain="testserver.local", path="/")
    h = {"X-CSRF-Token": csrf}
    # بلا step-up → 403
    assert client.get("/admin/overview", headers=h).status_code == 403
    # enroll + step-up
    secret = client.post("/auth/totp/enroll", headers=h).json()["secret"]
    import pyotp

    code = pyotp.TOTP(secret).now()
    client.post("/auth/totp/confirm", params={"code": code}, headers=h)
    assert client.post("/admin/step-up", params={"code": code}, headers=h).status_code == 200
    assert client.get("/admin/overview", headers=h).status_code == 200


def test_admin_ip_allowlist_enforced(client, db, owner_conn, monkeypatch):
    from app.core.config import get_settings

    _make_owner(owner_conn, "owner2@example.com")
    r = client.post("/auth/login", json={"email": "owner2@example.com", "password": PASSWORD})
    h = {"Authorization": f"Bearer {r.json()['access_token']}"}
    settings = get_settings()
    monkeypatch.setattr(settings, "admin_allowed_ips", "203.0.113.9")
    assert client.get("/admin/overview", headers=h).status_code == 403

# ---------------------------------------------------------------- JWT hardening (PyJWT, HS256 only)
def _token_for(client):
    email, store = _register(client)
    r = client.post("/auth/login", json={"email": email, "password": PASSWORD})
    assert r.status_code == 200, r.text
    return r.json()["access_token"]


def test_alg_none_token_rejected(client, db):
    """هجوم alg=none: توكن بلا توقيع يجب أن يُرفض 401، لا 200."""
    email, _ = _register(client)
    forged = jwt.encode(
        {"sub": "x", "role": "admin", "iss": "http://testserver", "exp": int(time.time()) + 600},
        key="",
        algorithm="none",
    )
    r = client.get("/me", headers={"Authorization": f"Bearer {forged}"})
    assert r.status_code == 401


def test_foreign_signed_token_rejected(client, db):
    """توكن موقّع بمفتاح آخر (تخمين/تسريب مفتاح) يُرفض."""
    forged = jwt.encode(
        {"sub": "x", "role": "admin", "iss": "http://testserver", "exp": int(time.time()) + 600},
        "attacker-controlled-key-that-is-long-enough-32",
        algorithm="HS256",
    )
    assert client.get("/me", headers={"Authorization": f"Bearer {forged}"}).status_code == 401


def test_expired_and_missing_claims_rejected(client, db):
    from app.core.config import get_settings

    secret = get_settings().jwt_secret.get_secret_value()
    base = {"sub": "x", "role": "merchant", "iss": get_settings().app_base_url}
    expired = jwt.encode({**base, "exp": int(time.time()) - 10}, secret, algorithm="HS256")
    no_exp = jwt.encode(dict(base), secret, algorithm="HS256")
    wrong_iss = jwt.encode({**base, "iss": "http://evil.test", "exp": int(time.time()) + 600}, secret,
                           algorithm="HS256")
    no_sub = jwt.encode({"role": "merchant", "iss": base["iss"], "exp": int(time.time()) + 600}, secret,
                        algorithm="HS256")
    for tok in (expired, no_exp, wrong_iss, no_sub):
        assert client.get("/me", headers={"Authorization": f"Bearer {tok}"}).status_code == 401


def test_tampered_payload_rejected(client, db):
    """تعديل الحمولة (رفع الدور) دون إعادة توقيع يُرفض."""
    token = _token_for(client)
    header, payload, sig = token.split(".")
    raw = json.loads(base64.urlsafe_b64decode(payload + "=" * (-len(payload) % 4)))
    raw["role"] = "admin"
    new_payload = base64.urlsafe_b64encode(json.dumps(raw).encode()).decode().rstrip("=")
    r = client.get("/me", headers={"Authorization": f"Bearer {header}.{new_payload}.{sig}"})
    assert r.status_code == 401


def test_no_vulnerable_jose_dependency():
    """انحدار سلسلة التوريد: python-jose/ecdsa أُزيلا (PYSEC-2026-4298 / PYSEC-2026-1325)."""
    import importlib.util

    assert importlib.util.find_spec("jose") is None
    assert importlib.util.find_spec("ecdsa") is None
    import jwt as pyjwt_mod

    assert pyjwt_mod.__version__ >= "2.10"
