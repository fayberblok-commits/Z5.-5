"""أمان الملفات: مصادقة، نوع حقيقي، فحص فيروسات fail-closed، روابط مقيدة أحادية الاستخدام."""

from __future__ import annotations

import uuid
from datetime import datetime, timedelta, timezone

import pytest

from app.modules.files import secure_upload as up

PNG = b"\x89PNG\r\n\x1a\n" + b"\x00" * 64
PDF = b"%PDF-1.7\n" + b"\x00" * 64


class FakeS3:
    def __init__(self):
        self.objects: dict[str, bytes] = {}
        self.presign_calls: list[dict] = []

    def put_object(self, **kw):
        self.objects[kw["Key"]] = kw["Body"].read()
        return {"ETag": '"etag"'}

    def get_object(self, **kw):
        import io
        return {"Body": io.BytesIO(self.objects[kw["Key"]])}

    def generate_presigned_url(self, op, Params=None, ExpiresIn=None):
        self.presign_calls.append({"op": op, "params": Params, "expires": ExpiresIn})
        host = "http://localhost:9000"
        return f"{host}/{Params['Bucket']}/{Params['Key']}?X-Amz-Expires={ExpiresIn}&X-Amz-Signature=stub"


@pytest.fixture()
def fake_s3(monkeypatch):
    client = FakeS3()
    monkeypatch.setattr(up, "s3_client", lambda: client)
    monkeypatch.setattr(up, "clamd_scan", lambda content: True)
    return client


def test_upload_without_session_rejected(client, db):
    r = client.post("/files/upload", content=PNG, headers={"x-filename": "a.png"})
    assert r.status_code == 401


def test_upload_when_scanner_unavailable_fails_closed(client, make_merchant, monkeypatch):
    m = make_merchant()
    monkeypatch.setattr(up, "s3_client", lambda: FakeS3())
    # clamd غير متاح في البيئة → يجب الرفض بـ 503 لا القبول
    monkeypatch.setattr(up, "clamd_scan", up.clamd_scan)
    r = client.post("/files/upload", content=PNG, headers={**m["headers"], "x-filename": "a.png"})
    assert r.status_code == 503


def test_upload_happy_path_with_scanner(client, make_merchant, fake_s3):
    m = make_merchant()
    r = client.post("/files/upload", content=PNG, headers={**m["headers"], "x-filename": "photo.png"})
    assert r.status_code == 200, r.text
    body = r.json()
    assert body["content_type"] == "image/png"
    assert body["object_key"].startswith("stores/")
    assert body["object_key"].endswith(".png")
    assert "photo" not in body["object_key"]  # اسم عشوائي لا اسم المستخدم


@pytest.mark.parametrize("payload,name", [
    (b"X5O!P%@AP[4\\PZX54(P^)7CC)7}$EICAR-STANDARD-ANTIVIRUS-TEST-FILE!$H+H*", "eicar.png"),
    (b"MZ\x90\x00" + b"\x00" * 100, "evil.png"),                       # PE/EXE
    (b"PK\x03\x04" + b"\x00" * 100, "archive.png"),                     # ZIP
    (b"\x89PNG\r\n\x1a\n" + b"%PDF-1.7 evil", "polyglot.png"),          # polyglot
    (b"<svg><script>alert(1)</script></svg>", "image.svg"),             # SVG نشط
])
def test_dangerous_uploads_rejected(client, make_merchant, fake_s3, payload, name):
    m = make_merchant()
    r = client.post("/files/upload", content=payload, headers={**m["headers"], "x-filename": name})
    assert r.status_code == 400, (name, r.text)


def test_upload_with_path_traversal_name(client, make_merchant, fake_s3):
    m = make_merchant()
    r = client.post("/files/upload", content=PNG, headers={**m["headers"], "x-filename": "../../etc/passwd"})
    assert r.status_code == 400


def test_download_url_bound_to_user_and_single_use(client, make_merchant, fake_s3, db):
    m = make_merchant()
    r = client.post("/files/upload", content=PNG, headers={**m["headers"], "x-filename": "a.png"})
    file_id = r.json()["file_id"]

    r = client.post(f"/files/{file_id}/download-url", headers={**m["headers"], "X-CSRF-Token": m["csrf"]})
    assert r.status_code == 200, r.text
    body = r.json()
    assert body["url"] == f"/files/download/{body['jti']}"  # authenticated redemption only
    assert "s3.example" not in body["url"]
    assert body["ttl_seconds"] <= 900
    jti = body["jti"]

    # استخدام أول ناجح
    r = client.post(f"/files/download/{jti}", headers={**m["headers"], "X-CSRF-Token": m["csrf"]})
    assert r.status_code == 200, r.text
    # استخدام ثانٍ مرفوض (replay)
    r = client.post(f"/files/download/{jti}", headers={**m["headers"], "X-CSRF-Token": m["csrf"]})
    assert r.status_code == 400


def test_download_url_for_other_store_blocked(client, make_merchant, fake_s3, db):
    a = make_merchant()
    b = make_merchant()
    r = client.post("/files/upload", content=PNG, headers={**a["headers"], "x-filename": "a.png"})
    file_id = r.json()["file_id"]
    r = client.post(f"/files/{file_id}/download-url", headers={**b["headers"], "X-CSRF-Token": b["csrf"]})
    assert r.status_code == 400  # RLS يُخفي الملف


def test_expired_token_rejected(client, make_merchant, fake_s3, db, owner_conn):
    m = make_merchant()
    r = client.post("/files/upload", content=PNG, headers={**m["headers"], "x-filename": "a.png"})
    file_id = r.json()["file_id"]
    jti = client.post(f"/files/{file_id}/download-url",
                      headers={**m["headers"], "X-CSRF-Token": m["csrf"]}).json()["jti"]
    owner_conn.execute("UPDATE file_download_tokens SET expires_at=%s WHERE jti=%s",
                       (datetime.now(timezone.utc) - timedelta(minutes=1), jti))
    owner_conn.commit()
    r = client.post(f"/files/download/{jti}", headers={**m["headers"], "X-CSRF-Token": m["csrf"]})
    assert r.status_code == 400


def test_files_table_records_clean_scan(client, make_merchant, fake_s3, db, owner_conn):
    m = make_merchant()
    client.post("/files/upload", content=PNG, headers={**m["headers"], "x-filename": "a.png"})
    row = owner_conn.execute("SELECT scan_status, size_bytes, sha256 FROM files").fetchone()
    assert row["scan_status"] == "clean"
    assert row["size_bytes"] == len(PNG)
    assert len(row["sha256"]) == 64


def test_validate_oversize():
    with pytest.raises(up.UploadRejected):
        up.validate(PNG, "a.png", max_bytes=16)


def test_svg_always_rejected():
    with pytest.raises(up.UploadRejected):
        up.validate(b"<svg xmlns='http://www.w3.org/2000/svg'></svg>", "x.png")


def test_pdf_allowed_when_clean(fake_s3, make_merchant):
    result = up.store_object(store_id=str(uuid.uuid4()), order_id=None, content=PDF, filename="doc.pdf")
    assert result["content_type"] == "application/pdf"
    assert result["object_key"].endswith(".pdf")


def test_download_does_not_expose_reusable_s3_capability(client, make_merchant, fake_s3):
    m = make_merchant()
    uploaded = client.post('/files/upload', content=PNG,
                           headers={**m['headers'], 'x-filename': 'a.png'}).json()
    issued = client.post(f"/files/{uploaded['file_id']}/download-url", headers=m['headers'])
    assert issued.status_code == 200
    token = issued.json()
    assert token['url'] == f"/files/download/{token['jti']}"
    assert fake_s3.presign_calls == []


def test_download_returns_private_bytes_not_object_key(client, make_merchant, fake_s3):
    import io
    fake_s3.get_object = lambda **kw: {'Body': io.BytesIO(fake_s3.objects[kw['Key']])}
    m = make_merchant()
    uploaded = client.post('/files/upload', content=PNG,
                           headers={**m['headers'], 'x-filename': 'a.png'}).json()
    token = client.post(f"/files/{uploaded['file_id']}/download-url", headers=m['headers']).json()
    response = client.post(f"/files/download/{token['jti']}", headers=m['headers'])
    assert response.status_code == 200
    assert response.content == PNG
    assert response.headers['cache-control'] == 'no-store'
    assert response.headers['content-disposition'] == 'attachment'
    assert client.post(f"/files/download/{token['jti']}", headers=m['headers']).status_code == 400


def test_object_store_failure_does_not_burn_download_token(client, make_merchant, fake_s3, monkeypatch):
    m = make_merchant()
    uploaded = client.post('/files/upload', content=PNG,
                           headers={**m['headers'], 'x-filename': 'a.png'}).json()
    token = client.post(f"/files/{uploaded['file_id']}/download-url", headers=m['headers']).json()
    original = fake_s3.get_object
    def unavailable(**kw):
        raise OSError('store unavailable')
    monkeypatch.setattr(fake_s3, 'get_object', unavailable)
    response = client.post(f"/files/download/{token['jti']}", headers=m['headers'])
    assert response.status_code == 503
    monkeypatch.setattr(fake_s3, 'get_object', original)
    response = client.post(f"/files/download/{token['jti']}", headers=m['headers'])
    assert response.status_code == 200
    assert response.content == PNG
