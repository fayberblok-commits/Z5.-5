"""عامل اختباري: يبدأ معاملة، يكتب سطرًا واحدًا من القيد، ثم يموت فورًا.

يُستخدم لإثبات أن المعاملة تُلغى كاملة عند انهيار العملية (لا قيد ناقص).
لا يُستورد من التطبيق — يُشغّل كعملية مستقلة.
"""

from __future__ import annotations

import os
import sys
import uuid

import psycopg
from psycopg.rows import dict_row

if __name__ == "__main__":
    dsn, store_id = sys.argv[1], sys.argv[2]
    conn = psycopg.connect(dsn, row_factory=dict_row)
    conn.execute("SET ROLE fibonix_app")
    conn.execute("SELECT set_config('app.store_id', %s, true)", (store_id,))
    conn.execute("BEGIN")
    conn.execute(
        "INSERT INTO ledger_entries (entry_group, store_id, order_id, account, direction, amount_minor, currency)"
        " VALUES (%s,%s,NULL,'buyer_payment','debit',7000,'USD')",
        (str(uuid.uuid4()), store_id),
    )
    os._exit(9)  # موت مفاجئ قبل كتابة السطر المقابل
