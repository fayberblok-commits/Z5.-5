"""تطابق نماذج ORM مع مخطط PostgreSQL الحقيقي (كشف انحراف الكود عن الهجرة)."""

from __future__ import annotations

import pytest
from sqlalchemy import create_engine, inspect

from app.db.models import Base

pytestmark = pytest.mark.usefixtures("db")


@pytest.fixture(scope="module")
def inspector(pg_server):
    url = pg_server["dsn"].replace("postgresql://", "postgresql+psycopg://", 1)
    engine = create_engine(url)
    yield inspect(engine)
    engine.dispose()


def test_all_model_tables_exist(inspector):
    db_tables = set(inspector.get_table_names())
    model_tables = set(Base.metadata.tables)
    missing = model_tables - db_tables
    assert not missing, f"tables in models but not in DB: {missing}"


def test_model_columns_exist(inspector):
    problems = []
    for table in Base.metadata.tables.values():
        db_cols = {c["name"] for c in inspector.get_columns(table.name)}
        model_cols = {c.name for c in table.columns}
        if model_cols - db_cols:
            problems.append({table.name: sorted(model_cols - db_cols)})
    assert not problems, problems


def test_required_money_tables_present(inspector):
    required = {"orders", "payments", "platform_fees", "merchant_accounts", "settlements",
                "transfers", "refunds", "disputes", "webhook_events", "ledger_entries"}
    assert required <= set(inspector.get_table_names())


def test_rls_enabled_on_tenant_tables(pg_server):
    import psycopg

    tenant_tables = ["products", "orders", "payments", "platform_fees", "transfers", "settlements",
                     "refunds", "disputes", "ledger_entries", "files"]
    with psycopg.connect(pg_server["dsn"], row_factory=psycopg.rows.dict_row) as conn:
        rows = conn.execute(
            "SELECT relname, relrowsecurity, relforcerowsecurity FROM pg_class WHERE relname = ANY(%s)",
            (tenant_tables,),
        ).fetchall()
    found = {r["relname"]: (r["relrowsecurity"], r["relforcerowsecurity"]) for r in rows}
    for table in tenant_tables:
        assert found[table] == (True, True), table


def test_money_columns_are_integers(pg_server):
    """لا أعمدة عشرية عائمة للأموال — minor units فقط."""
    import psycopg

    with psycopg.connect(pg_server["dsn"], row_factory=psycopg.rows.dict_row) as conn:
        rows = conn.execute(
            """SELECT table_name, column_name, data_type FROM information_schema.columns
                WHERE table_schema='public'
                  AND (column_name LIKE '%minor%' OR column_name LIKE '%amount%')
                  AND data_type NOT IN ('bigint','integer')"""
        ).fetchall()
    assert rows == [], rows
