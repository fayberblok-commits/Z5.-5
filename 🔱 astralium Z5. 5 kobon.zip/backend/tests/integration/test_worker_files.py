"""عامل الملفات: يجب أن يعمل فعليًا (لا حلقة نائمة، ولا دالة تُرجع صفرًا دائمًا).

نُثبت: حذف التوكنات المنتهية/المستخدمة، إغلاق الملفات المعلّقة fail-closed،
تنظيف jti المنتهية ومفاتيح idempotency القديمة، وعدم المساس بالصفوف الحيّة.
"""

from __future__ import annotations

import uuid

from app.core.db import atomic
from app.workers.files import run_once


def _store_with_file(conn, owner_conn):
    owner = owner_conn.execute(
        "INSERT INTO accounts (email, password_hash, role) VALUES (%s,'x','merchant') "
        "ON CONFLICT DO NOTHING RETURNING id",
        (f"w{uuid.uuid4().hex[:8]}@example.com",),
    ).fetchone()
    store = owner_conn.execute(
        "INSERT INTO stores (name, owner_id) VALUES ('W', %s) RETURNING id", (owner["id"],)
    ).fetchone()
    key = f"stores/{store['id']}/{uuid.uuid4().hex}.jpg"
    f = owner_conn.execute(
        """INSERT INTO files (store_id, object_key, content_type, size_bytes, sha256, scan_status, created_at)
           VALUES (%s,%s,'image/jpeg',10,'deadbeef','clean', now()) RETURNING id""",
        (store["id"], key),
    ).fetchone()
    owner_conn.commit()
    return store["id"], f["id"]


def _token(owner_conn, store_id, file_id, *, used: bool, expired: bool) -> uuid.UUID:
    row = owner_conn.execute(
        """INSERT INTO file_download_tokens (file_id, store_id, buyer_id, expires_at, used_at)
           VALUES (%s,%s,'buyer',
                   CASE WHEN %s THEN now() - interval '2 hours' ELSE now() + interval '1 hour' END,
                   CASE WHEN %s THEN now() ELSE NULL END)
           RETURNING jti""",
        (file_id, store_id, expired, used),
    ).fetchone()
    owner_conn.commit()
    return row["jti"]


def test_run_once_deletes_only_dead_tokens_and_reports_counts(db, owner_conn):
    store_id, file_id = _store_with_file(None, owner_conn)
    dead_expired = _token(owner_conn, store_id, file_id, used=False, expired=True)
    dead_used = _token(owner_conn, store_id, file_id, used=True, expired=False)
    alive = _token(owner_conn, store_id, file_id, used=False, expired=False)

    owner_conn.commit()
    with atomic() as conn:
        result = run_once(conn)

    remaining = {
        r["jti"] for r in owner_conn.execute("SELECT jti FROM file_download_tokens").fetchall()
    }
    assert alive in remaining
    assert dead_expired not in remaining
    assert dead_used not in remaining
    assert result.expired_tokens >= 2
    assert result.total >= 2


def test_run_once_closes_stale_pending_files_as_error(db, owner_conn):
    store_id, _ = _store_with_file(None, owner_conn)
    stale = owner_conn.execute(
        """INSERT INTO files (store_id, object_key, content_type, size_bytes, sha256, scan_status, created_at)
           VALUES (%s,%s,'image/png',10,'aa','pending', now() - interval '2 hours') RETURNING id""",
        (store_id, f"stores/{store_id}/{uuid.uuid4().hex}.png"),
    ).fetchone()
    fresh = owner_conn.execute(
        """INSERT INTO files (store_id, object_key, content_type, size_bytes, sha256, scan_status, created_at)
           VALUES (%s,%s,'image/png',10,'bb','pending', now()) RETURNING id""",
        (store_id, f"stores/{store_id}/{uuid.uuid4().hex}.png"),
    ).fetchone()
    owner_conn.commit()

    with atomic() as conn:
        result = run_once(conn)

    status = {
        r["id"]: r["scan_status"]
        for r in owner_conn.execute(
            "SELECT id, scan_status FROM files WHERE id = ANY(%s)", ([stale["id"], fresh["id"]],)
        ).fetchall()
    }
    assert status[stale["id"]] == "error"
    assert status[fresh["id"]] == "pending"
    assert result.stale_pending_files >= 1


def test_run_once_purges_expired_jtis_and_idempotency(db, owner_conn):
    owner_conn.execute(
        "INSERT INTO revoked_jtis (jti, expires_at) VALUES (%s, now() - interval '40 days')", (uuid.uuid4().hex,)
    )
    live_jti = uuid.uuid4().hex
    owner_conn.execute("INSERT INTO revoked_jtis (jti, expires_at) VALUES (%s, now() + interval '1 day')", (live_jti,))
    owner_conn.execute(
        "INSERT INTO idempotency_keys (key, scope, request_hash, created_at) "
        "VALUES ('old-key','scope','h', now() - interval '30 days')"
    )
    owner_conn.execute(
        "INSERT INTO idempotency_keys (key, scope, request_hash, created_at) VALUES ('new-key','scope','h', now())"
    )
    owner_conn.commit()

    with atomic() as conn:
        result = run_once(conn)

    assert result.old_jtis >= 1
    assert result.old_idempotency >= 1
    assert owner_conn.execute("SELECT 1 FROM revoked_jtis WHERE jti=%s", (live_jti,)).fetchone()
    assert owner_conn.execute("SELECT 1 FROM idempotency_keys WHERE key='new-key'").fetchone()


def test_run_once_is_idempotent_when_nothing_to_do(db):
    with atomic() as conn:
        first = run_once(conn)
    with atomic() as conn:
        second = run_once(conn)
    assert second.total == 0 or second.total <= first.total
    assert second.expired_tokens == 0
    assert second.stale_pending_files == 0


def test_worker_is_not_a_noop_module():
    """انحدار: العامل كان `while True: time.sleep(10)` بلا أي عمل."""
    import inspect

    import app.workers.files as worker

    src = inspect.getsource(worker)
    assert "time.sleep(10)\n\n\nif __name__" not in src
    assert "DELETE FROM" in src and "UPDATE files SET scan_status" in src
    assert callable(worker.run_once) and callable(worker.run)


def test_run_loop_exits_on_sigterm(db, monkeypatch):
    """الحلقة نفسها: تعمل، تلتقط SIGTERM، وتخرج بلا تعليق (كانت `sleep(10)` أبدية)."""
    import signal

    import app.workers.files as worker

    calls = {"n": 0}

    def fake_run_once(conn, **_):
        calls["n"] += 1
        return worker.SweepResult(0, 0, 0, 0)

    monkeypatch.setattr(worker, "run_once", fake_run_once)
    worker._stop = False
    monkeypatch.setattr(worker.time, "sleep", lambda _s: worker._handle_signal(signal.SIGTERM, None))
    worker.run(interval=0.01)
    assert calls["n"] >= 1
    assert worker._stop is True


def test_run_loop_survives_transient_db_error(db, monkeypatch, caplog):
    """خطأ عابر في دورة واحدة لا يُسقط العامل ولا يُخفيه بلا تسجيل."""
    import signal

    import app.workers.files as worker

    def boom(conn, **_):
        raise RuntimeError("db gone")

    monkeypatch.setattr(worker, "run_once", boom)
    worker._stop = False
    monkeypatch.setattr(worker.time, "sleep", lambda _s: worker._handle_signal(signal.SIGTERM, None))
    worker.run(interval=0.01)
    assert worker._stop is True
    assert any("sweep failed" in r.message % r.args if r.args else "sweep failed" in r.message
               for r in caplog.records)
