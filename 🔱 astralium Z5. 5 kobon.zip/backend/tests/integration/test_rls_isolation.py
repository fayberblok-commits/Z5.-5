"""عزل المتاجر على مستوى PostgreSQL (RLS) — لا يعتمد على فلترة بايثون."""

from __future__ import annotations

import uuid

import psycopg
import pytest


def _app_conn(pg_server):
    """اتصال بدور التطبيق الحقيقي (NOSUPERUSER/NOBYPASSRLS)."""
    dsn_owner = pg_server["dsn"]
    # نستبدل المستخدم بكلمة مرور دور التطبيق عبر SET ROLE من اتصال المالك
    return psycopg.connect(dsn_owner, row_factory=psycopg.rows.dict_row)


@pytest.fixture()
def two_stores(owner_conn, db):
    a, b = uuid.uuid4(), uuid.uuid4()
    acc = owner_conn.execute(
        "INSERT INTO accounts (email, password_hash, role) VALUES ('x@example.com','h','merchant') RETURNING id"
    ).fetchone()["id"]
    for sid, name in ((a, "A"), (b, "B")):
        owner_conn.execute("INSERT INTO stores (id, name, owner_id) VALUES (%s,%s,%s)", (sid, name, acc))
        owner_conn.execute(
            "INSERT INTO products (store_id, title, price_minor) VALUES (%s,%s,100)", (sid, f"p-{name}")
        )
        owner_conn.execute(
            "INSERT INTO orders (id, store_id, buyer_email, amount_minor, idempotency_key) VALUES (%s,%s,'b@x.com',100,%s)",
            (uuid.uuid4(), sid, f"k-{name}"),
        )
    owner_conn.commit()
    return str(a), str(b)


def test_tenant_sees_only_own_rows(pg_server, two_stores):
    a, _b = two_stores
    with _app_conn(pg_server) as conn, conn.transaction():
        conn.execute("SET ROLE fibonix_app")
        conn.execute("SELECT set_config('app.store_id', %s, true)", (a,))
        rows = conn.execute("SELECT store_id FROM products").fetchall()
        assert rows and all(str(r["store_id"]) == a for r in rows)


def test_tenant_cannot_read_other_store(pg_server, two_stores):
    _a, b = two_stores
    with _app_conn(pg_server) as conn, conn.transaction():
        conn.execute("SET ROLE fibonix_app")
        conn.execute("SELECT set_config('app.store_id', %s, true)", (b,))
        conn.execute("SELECT set_config('app.store_id', %s, true)", (b,))
        # محاولة القراءة بمعرّف متجر آخر لا تُرجع صفوفًا
        other = conn.execute("SELECT COUNT(*) AS n FROM products WHERE store_id <> %s", (b,)).fetchone()
        assert other["n"] == 0


def test_insert_for_other_store_is_blocked(pg_server, two_stores):
    a, b = two_stores
    with _app_conn(pg_server) as conn, conn.transaction():
        conn.execute("SET ROLE fibonix_app")
        conn.execute("SELECT set_config('app.store_id', %s, true)", (a,))
        with pytest.raises(psycopg.errors.InsufficientPrivilege):
            conn.execute(
                "INSERT INTO products (store_id, title, price_minor) VALUES (%s,'evil',100)", (b,)
            )


def test_no_store_context_returns_nothing(pg_server, two_stores):
    with _app_conn(pg_server) as conn, conn.transaction():
        conn.execute("SET ROLE fibonix_app")
        assert conn.execute("SELECT COUNT(*) AS n FROM products").fetchone()["n"] == 0
        assert conn.execute("SELECT COUNT(*) AS n FROM orders").fetchone()["n"] == 0


def test_app_role_cannot_bypass_rls(pg_server):
    with _app_conn(pg_server) as conn:
        row = conn.execute(
            """SELECT rolname, rolsuper, rolbypassrls FROM pg_roles WHERE rolname='fibonix_app'"""
        ).fetchone()
    assert row["rolsuper"] is False
    assert row["rolbypassrls"] is False


def test_owner_like_force_rls_also_applies(pg_server, two_stores):
    """FORCE RLS: حتى مالك الجدول لا يقرأ بلا سياق متجر."""
    _a, _b = two_stores
    with _app_conn(pg_server) as conn, conn.transaction():
        conn.execute("SET ROLE fibonix_app")
        assert conn.execute("SELECT COUNT(*) AS n FROM ledger_entries").fetchone()["n"] == 0
