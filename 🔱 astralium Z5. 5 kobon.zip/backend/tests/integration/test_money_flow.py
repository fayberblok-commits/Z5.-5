"""اختبارات مالية تكاملية على PostgreSQL حقيقي + Stripe MockTransport.

السيناريو الأساسي: بيع 70$ ⇒ عمولة 2$ (200) + حصة تاجر 68$ (6800)، مع تحويل
حقيقي (محاكى عبر طبقة HTTP الرسمية) وتسوية، ومنع تكرار، وعدم اعتبار العمولة
مدفوعة قبل تأكيد موزّع.
"""

from __future__ import annotations

import json
import time

import pytest

from app.core.config import get_settings
from app.modules.ledger import repository as ledger
from app.modules.payments.mock_transport import StripeMockState
from app.modules.payments.stripe_connect import compute_signature

pytestmark = pytest.mark.usefixtures("db")


# ------------------------------------------------------------------ helpers
def _merchant_with_connect(client, make_merchant):
    m = make_merchant()
    r = client.post(f"/stores/{m['store_id']}/payments/onboard",
                    params={"provider_account_id": "acct_test_123456789", "country": "US"},
                    headers=m["headers"])
    assert r.status_code == 200, r.text
    return m


def _create_and_pay(client, m, amount: int, coupon: int = 0):
    r = client.post("/orders", json={"store_id": m["store_id"], "amount_cents": amount, "coupon_cents": coupon},
                    headers={**m["headers"], "Idempotency-Key": f"ord-{amount}-{coupon}-{time.time_ns()}"})
    assert r.status_code == 200, r.text
    order_id = r.json()["order_id"]
    r = client.post(f"/orders/{order_id}/pay", headers=m["headers"])
    assert r.status_code == 200, r.text
    return order_id, r.json()["payment_intent"]


def _signed(client, event: dict, *, secret: str | None = None, ts: int | None = None) -> dict:
    secret = secret or get_settings().stripe_webhook_secret.get_secret_value()
    body = json.dumps(event).encode()
    timestamp = ts if ts is not None else int(time.time())
    sig = compute_signature(body, secret, timestamp)
    return {"content": body, "headers": {"Stripe-Signature": f"t={timestamp},v1={sig}"}}


def _webhook(client, event: dict, **kw):
    payload = _signed(client, event, **kw)
    return client.post("/webhooks/stripe", content=payload["content"], headers=payload["headers"])


def _fee_row(store_id: str) -> dict:
    from app.core.db import tenant

    with tenant(store_id) as conn:
        return conn.execute(
            "SELECT amount_minor, status FROM platform_fees ORDER BY created_at DESC LIMIT 1"
        ).fetchone()


def _transfers(store_id: str) -> list[dict]:
    from app.core.db import tenant

    with tenant(store_id) as conn:
        return conn.execute("SELECT * FROM transfers WHERE store_id=%s", (store_id,)).fetchall()


def _ledger_rows(store_id: str) -> list[dict]:
    from app.core.db import tenant

    with tenant(store_id) as conn:
        return conn.execute(
            "SELECT account, direction, amount_minor FROM ledger_entries WHERE store_id=%s ORDER BY id",
            (store_id,),
        ).fetchall()


@pytest.fixture(autouse=True)
def _reset_stripe_mock():
    StripeMockState.reset()
    yield
    StripeMockState.reset()


# ------------------------------------------------------------------ $70 sale
def test_sale_70_dollars_split_and_settlement(client, make_merchant):
    m = _merchant_with_connect(client, make_merchant)
    order_id, pi_id = _create_and_pay(client, m, 7000)
    assert pi_id.startswith("pi_")

    # قبل التأكيد: لا دفتر ولا تحويل ولا عمولة محصّلة
    assert _ledger_rows(m["store_id"]) == []
    assert _transfers(m["store_id"]) == []

    r = _webhook(client, {"id": "evt_1", "type": "payment_intent.succeeded",
                          "data": {"object": {"id": pi_id, "amount": 7000, "status": "succeeded"}}})
    assert r.status_code == 200, r.text
    assert r.json()["result"]["split"]["platform_fee_minor"] == 200
    assert r.json()["result"]["split"]["merchant_net_minor"] == 6800

    rows = _ledger_rows(m["store_id"])
    assert ("buyer_payment", "debit", 7000) in [(r["account"], r["direction"], r["amount_minor"]) for r in rows]
    assert ("platform_fee", "credit", 200) in [(r["account"], r["direction"], r["amount_minor"]) for r in rows]
    assert ("merchant_receivable", "credit", 6800) in [(r["account"], r["direction"], r["amount_minor"]) for r in rows]

    # العمولة "processing" لا "paid" قبل تأكيد المزود
    fee = _fee_row(m["store_id"])
    assert fee["amount_minor"] == 200
    assert fee["status"] == "processing"

    transfers = _transfers(m["store_id"])
    assert len(transfers) == 1
    assert transfers[0]["kind"] == "merchant_payout"
    assert transfers[0]["amount_minor"] == 6800
    assert transfers[0]["provider_transfer_id"].startswith("tr_")
    assert transfers[0]["status"] == "processing"

    assert ledger.verify_balanced(m["store_id"])["balanced"] is True

    # تأكيد رسمي للتحويل ⇒ العمولة paid
    r = _webhook(client, {"id": "evt_2", "type": "transfer.paid",
                          "data": {"object": {"id": transfers[0]["provider_transfer_id"], "status": "paid",
                                              "metadata": {"order_id": order_id}}}})
    assert r.status_code == 200
    assert _fee_row(m["store_id"])["status"] == "paid"
    assert _transfers(m["store_id"])[0]["status"] == "paid"
    accounts = {(r["account"], r["direction"]) for r in _ledger_rows(m["store_id"])}
    assert ("platform_earnings", "credit") in accounts
    assert ledger.verify_balanced(m["store_id"])["balanced"] is True

    summary = client.get(f"/stores/{m['store_id']}/settlements", headers=m["headers"]).json()
    assert summary["gross_minor"] == 7000
    assert summary["platform_fee_minor"] == 200
    assert summary["net_to_merchant_minor"] == 6800


def test_replayed_webhook_creates_no_second_transfer(client, make_merchant):
    m = _merchant_with_connect(client, make_merchant)
    order_id, pi_id = _create_and_pay(client, m, 7000)
    event = {"id": "evt_dup", "type": "payment_intent.succeeded",
             "data": {"object": {"id": pi_id, "amount": 7000}}}

    first = _webhook(client, event)
    assert first.json()["status"] == "processed"
    ledger_count = len(_ledger_rows(m["store_id"]))
    transfer_count = len(_transfers(m["store_id"]))
    assert transfer_count == 1

    second = _webhook(client, event)
    assert second.status_code == 200
    assert second.json()["status"] == "duplicate"
    assert len(_ledger_rows(m["store_id"])) == ledger_count
    assert len(_transfers(m["store_id"])) == transfer_count
    assert len(StripeMockState.calls) == 2  # PI + transfer واحد فقط


def test_provider_idempotency_returns_same_transfer(client, make_merchant):
    """نفس مفتاح idempotency لدى المزود يعيد نفس التحويل (لا تحويل ثانٍ)."""
    from app.modules.payments.stripe_connect import StripeConnectClient

    c = StripeConnectClient("sk_test_" + "a" * 20, transport=StripeMockState and __import__(
        "app.modules.payments.mock_transport", fromlist=["mock_transport"]).mock_transport())
    t1 = c.create_transfer(amount_minor=6800, currency="USD", destination="acct_x", order_id="o1",
                           kind="merchant_payout", idempotency_key="payout:o1")
    t2 = c.create_transfer(amount_minor=6800, currency="USD", destination="acct_x", order_id="o1",
                           kind="merchant_payout", idempotency_key="payout:o1")
    assert t1["id"] == t2["id"]


def test_transfer_failure_marks_failed_not_paid(client, make_merchant):
    m = _merchant_with_connect(client, make_merchant)
    order_id, pi_id = _create_and_pay(client, m, 7000)
    StripeMockState.fail_transfers = True

    r = _webhook(client, {"id": "evt_fail", "type": "payment_intent.succeeded",
                          "data": {"object": {"id": pi_id, "amount": 7000}}})
    assert r.status_code == 200
    assert r.json()["result"]["payout"]["status"] == "failed"

    fee = _fee_row(m["store_id"])
    assert fee["status"] == "failed"
    transfers = _transfers(m["store_id"])
    assert transfers[0]["status"] == "failed"
    assert transfers[0]["failure_reason"]
    # الدفتر يبقى متوازنًا ولا تُعلن العمولة محصّلة
    assert ledger.verify_balanced(m["store_id"])["balanced"] is True


def test_invalid_signature_rejected_without_side_effects(client, make_merchant):
    m = _merchant_with_connect(client, make_merchant)
    _, pi_id = _create_and_pay(client, m, 7000)
    event = {"id": "evt_bad", "type": "payment_intent.succeeded", "data": {"object": {"id": pi_id}}}

    r = _webhook(client, event, secret="whsec_" + "b" * 40)
    assert r.status_code == 400
    assert _ledger_rows(m["store_id"]) == []
    assert _transfers(m["store_id"]) == []


def test_stale_timestamp_rejected(client, make_merchant):
    m = _merchant_with_connect(client, make_merchant)
    _, pi_id = _create_and_pay(client, m, 7000)
    r = _webhook(client, {"id": "evt_old", "type": "payment_intent.succeeded",
                          "data": {"object": {"id": pi_id}}}, ts=int(time.time()) - 3600)
    assert r.status_code == 400


def test_payment_failed_marks_order_failed(client, make_merchant):
    m = _merchant_with_connect(client, make_merchant)
    order_id, pi_id = _create_and_pay(client, m, 7000)
    r = _webhook(client, {"id": "evt_pf", "type": "payment_intent.payment_failed",
                          "data": {"object": {"id": pi_id}}})
    assert r.status_code == 200
    assert _fee_row(m["store_id"])["status"] == "failed"
    from app.core.db import tenant

    with tenant(m["store_id"]) as conn:
        assert conn.execute("SELECT status FROM orders WHERE id=%s", (order_id,)).fetchone()["status"] == "failed"


# ------------------------------------------------------------------ edge money
def test_refund_full_refunds_fee_and_freezes_settlement(client, make_merchant):
    m = _merchant_with_connect(client, make_merchant)
    order_id, pi_id = _create_and_pay(client, m, 7000)
    _webhook(client, {"id": "evt_r1", "type": "payment_intent.succeeded",
                      "data": {"object": {"id": pi_id, "amount": 7000}}})
    r = _webhook(client, {"id": "evt_r2", "type": "charge.refunded",
                          "data": {"object": {"id": "re_1", "payment_intent": pi_id,
                                              "amount_refunded": 7000, "reason": "requested_by_customer"}}})
    assert r.status_code == 200
    assert r.json()["result"]["fee_policy"] == "fee_refunded"
    assert _fee_row(m["store_id"])["status"] == "refunded"
    assert ledger.verify_balanced(m["store_id"])["balanced"] is True
    from app.core.db import tenant

    with tenant(m["store_id"]) as conn:
        st = conn.execute("SELECT status FROM settlements WHERE store_id=%s", (m["store_id"],)).fetchall()
    assert any(row["status"] == "frozen" for row in st)


def test_partial_refund_retains_fee(client, make_merchant):
    m = _merchant_with_connect(client, make_merchant)
    order_id, pi_id = _create_and_pay(client, m, 7000)
    _webhook(client, {"id": "evt_p1", "type": "payment_intent.succeeded",
                      "data": {"object": {"id": pi_id, "amount": 7000}}})
    r = _webhook(client, {"id": "evt_p2", "type": "charge.refunded",
                          "data": {"object": {"id": "re_2", "payment_intent": pi_id,
                                              "amount_refunded": 1000, "reason": "requested_by_customer"}}})
    assert r.json()["result"]["fee_policy"] == "fee_retained"
    assert ledger.verify_balanced(m["store_id"])["balanced"] is True


def test_dispute_freezes_and_holds_funds(client, make_merchant):
    m = _merchant_with_connect(client, make_merchant)
    order_id, pi_id = _create_and_pay(client, m, 7000)
    _webhook(client, {"id": "evt_d1", "type": "payment_intent.succeeded",
                      "data": {"object": {"id": pi_id, "amount": 7000}}})
    r = _webhook(client, {"id": "evt_d2", "type": "charge.dispute.created",
                          "data": {"object": {"id": "dp_1", "payment_intent": pi_id, "amount": 7000,
                                              "status": "needs_response"}}})
    assert r.status_code == 200
    assert _fee_row(m["store_id"])["status"] == "disputed"
    accounts = {(row["account"], row["direction"]) for row in _ledger_rows(m["store_id"])}
    assert ("dispute_hold", "credit") in accounts
    assert ledger.verify_balanced(m["store_id"])["balanced"] is True


def test_under_two_dollars_all_goes_to_platform(client, make_merchant):
    m = _merchant_with_connect(client, make_merchant)
    order_id, pi_id = _create_and_pay(client, m, 150)
    r = _webhook(client, {"id": "evt_small", "type": "payment_intent.succeeded",
                          "data": {"object": {"id": pi_id, "amount": 150}}})
    assert r.json()["result"]["split"]["platform_fee_minor"] == 150
    assert r.json()["result"]["split"]["merchant_net_minor"] == 0
    assert _transfers(m["store_id"]) == []  # لا تحويل صفري


def test_free_order_no_payment_no_ledger(client, make_merchant):
    m = _merchant_with_connect(client, make_merchant)
    r = client.post("/orders", json={"store_id": m["store_id"], "amount_cents": 0},
                    headers={**m["headers"], "Idempotency-Key": "free-1"})
    order_id = r.json()["order_id"]
    r = client.post(f"/orders/{order_id}/pay", headers=m["headers"])
    assert r.status_code == 200
    assert r.json()["status"] == "free"
    assert _ledger_rows(m["store_id"]) == []
    assert _transfers(m["store_id"]) == []


def test_coupon_reduces_gross(client, make_merchant):
    m = _merchant_with_connect(client, make_merchant)
    order_id, pi_id = _create_and_pay(client, m, 7000, coupon=1000)
    r = _webhook(client, {"id": "evt_c1", "type": "payment_intent.succeeded",
                          "data": {"object": {"id": pi_id, "amount": 6000}}})
    split = r.json()["result"]["split"]
    assert split["gross_minor"] == 6000
    assert split["platform_fee_minor"] == 200
    assert split["merchant_net_minor"] == 5800


def test_gateway_fee_reduces_merchant_share(client, make_merchant):
    m = _merchant_with_connect(client, make_merchant)
    order_id, pi_id = _create_and_pay(client, m, 7000)
    r = _webhook(client, {"id": "evt_g1", "type": "payment_intent.succeeded",
                          "data": {"object": {"id": pi_id, "amount": 7000, "balance_transaction_fee": 233}}})
    split = r.json()["result"]["split"]
    assert split["gateway_fee_minor"] == 233
    assert split["merchant_net_minor"] == 6800 - 233
    assert split["platform_fee_minor"] == 200
    assert ledger.verify_balanced(m["store_id"])["balanced"] is True


def test_multi_merchant_cart_two_fees(client, make_merchant):
    a = _merchant_with_connect(client, make_merchant)
    b = _merchant_with_connect(client, make_merchant)
    _, pi_a = _create_and_pay(client, a, 7000)
    _, pi_b = _create_and_pay(client, b, 5000)
    _webhook(client, {"id": "evt_ma", "type": "payment_intent.succeeded", "data": {"object": {"id": pi_a}}})
    _webhook(client, {"id": "evt_mb", "type": "payment_intent.succeeded", "data": {"object": {"id": pi_b}}})
    assert _fee_row(a["store_id"])["amount_minor"] == 200
    assert _fee_row(b["store_id"])["amount_minor"] == 200


def test_pay_requires_merchant_account(client, make_merchant):
    m = make_merchant()  # بلا onboard
    r = client.post("/orders", json={"store_id": m["store_id"], "amount_cents": 7000},
                    headers={**m["headers"], "Idempotency-Key": "no-acct"})
    order_id = r.json()["order_id"]
    r = client.post(f"/orders/{order_id}/pay", headers=m["headers"])
    assert r.status_code == 400
    assert "merchant account" in r.json()["detail"]


def test_separate_charges_do_not_also_create_destination_charge(client, make_merchant):
    m = _merchant_with_connect(client, make_merchant)
    _, pi = _create_and_pay(client, m, 7000)
    payment_call = next(c for c in StripeMockState.calls if c['path'] == '/v1/payment_intents')
    assert 'transfer_data[destination]' not in payment_call['form']
    assert int(payment_call['form']['amount']) == 7000
    response = _webhook(client, {'id': 'evt_separate_charge', 'type': 'payment_intent.succeeded',
                                'data': {'object': {'id': pi, 'amount': 7000, 'status': 'succeeded'}}})
    assert response.status_code == 200
    transfers = [c for c in StripeMockState.calls if c['path'] == '/v1/transfers']
    assert len(transfers) == 1
    assert int(transfers[0]['form']['amount']) == 6800


def test_distinct_event_ids_for_same_transfer_do_not_rebook_fee(client, make_merchant):
    m = _merchant_with_connect(client, make_merchant)
    _, pi = _create_and_pay(client, m, 7000)
    response = _webhook(client, {'id': 'evt_payment_same_transfer', 'type': 'payment_intent.succeeded',
                                'data': {'object': {'id': pi, 'amount': 7000, 'status': 'succeeded'}}})
    assert response.status_code == 200
    transfer = _transfers(m['store_id'])[0]['provider_transfer_id']
    for event_id in ('evt_transfer_confirmation_1', 'evt_transfer_confirmation_2'):
        response = _webhook(client, {'id': event_id, 'type': 'transfer.paid',
                                    'data': {'object': {'id': transfer, 'status': 'paid'}}})
        assert response.status_code == 200
        if event_id.endswith('_1'):
            after_first = _ledger_rows(m['store_id'])
        else:
            assert _ledger_rows(m['store_id']) == after_first
    assert len(_transfers(m['store_id'])) == 1
