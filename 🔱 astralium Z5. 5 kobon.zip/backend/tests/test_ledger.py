from app.modules.ledger.service import Ledger, split_sale


def test_split_normal():
    m, f = split_sale(1000)
    assert m == 800 and f == 200


def test_split_less_than_fee():
    m, f = split_sale(150)
    assert m == 0 and f == 150


def test_split_free():
    m, f = split_sale(0)
    assert m == 0 and f == 0


def test_ledger_zero_diff():
    ledger = Ledger()
    ledger.post("s1", "o1", "buyer_payment", "merchant_receivable", 800)
    ledger.post("s1", "o1", "buyer_payment", "platform_fee", 200)
    assert ledger.verify_zero_diff() == 0
    assert ledger.balance("buyer_payment") == 1000
