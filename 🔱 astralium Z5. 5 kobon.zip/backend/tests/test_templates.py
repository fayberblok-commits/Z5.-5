from app.modules.templates_engine.engine import render_template, sanitize_html
import pytest


def test_sanitize_blocks_js():
    with pytest.raises(ValueError):
        sanitize_html("<script>alert(1)</script>")
    with pytest.raises(ValueError):
        sanitize_html('<div onload="evil()">hi</div>')


def test_render_logicless():
    out = render_template("Hello {{name}}", {"name": "World"})
    assert "World" in out
    with pytest.raises(ValueError):
        render_template("Hello {{7*7}}", {})


def test_ssti_blocked():
    with pytest.raises(ValueError):
        render_template("hi {% for x %}", {"x": "1"})
