"""اختبارات مالية شاملة — كل حالات الحافة 2$."""

from app.modules.ledger.service import split_sale, Ledger
from app.modules.payments.adapters import IdempotencyStore, verify_stripe_signature, stripe_sign_payload
import time


def test_commission_cases():
    assert split_sale(1000) == (800, 200)
    assert split_sale(200) == (0, 200)  # exactly 2$
    assert split_sale(199) == (0, 199)  # <2$
    assert split_sale(0) == (0, 0)  # مجاني
    assert split_sale(1) == (0, 1)
    assert split_sale(10000) == (9800, 200)


def test_coupon_and_free():
    # coupon 3$ on 10$ => net 7$ => 5$ merchant 2$ fee
    net = max(0, 1000 - 300)
    m, f = split_sale(net)
    assert m == 500 and f == 200
    # coupon makes free
    net = max(0, 500 - 600)
    m, f = split_sale(net)
    assert m == 0 and f == 0


def test_cart_multi_merchant():
    # سلة متعددة التجار: كل متجر عمولة منفصلة
    cart = [("storeA", 1000), ("storeB", 500)]
    total_fee = 0
    for _store, amt in cart:
        _, fee = split_sale(amt)
        total_fee += fee
    assert total_fee == 400  # 200 per store


def test_ledger_atomic():
    ledger = Ledger()
    for i in range(10):
        ledger.post("s1", f"o{i}", "buyer_payment", "merchant_receivable", 800)
        ledger.post("s1", f"o{i}", "buyer_payment", "platform_fee", 200)
    assert ledger.verify_zero_diff() == 0
    assert ledger.balance("platform_fee") == -2000  # credit negative in our model


def test_idempotency():
    store = IdempotencyStore()
    assert store.check_or_store("key1")
    assert not store.check_or_store("key1")  # duplicate
    assert store.check_or_store("key2")


def test_webhook_timing_and_tamper():
    payload = '{"amount":1000}'
    secret = "whsec_test"
    ts = str(int(time.time()))
    header = stripe_sign_payload(payload, secret, ts)
    assert verify_stripe_signature(payload, header, secret)
    # tampered amount
    assert not verify_stripe_signature('{"amount":9999}', header, secret)
    # old timestamp should fail (>300s)
    old = str(int(time.time()) - 400)
    old_header = stripe_sign_payload(payload, secret, old)
    assert not verify_stripe_signature(payload, old_header, secret)


def test_double_click_race():
    # simulate concurrent order creation idempotency
    store = IdempotencyStore()
    # two tabs same idempotency key
    key = "idem_order_123"
    first = store.check_or_store(key)
    second = store.check_or_store(key)
    assert first and not second


def test_refund():
    ledger = Ledger()
    ledger.post("s1", "o1", "buyer_payment", "merchant_receivable", 800)
    ledger.post("s1", "o1", "buyer_payment", "platform_fee", 200)
    # refund: reverse entries
    ledger.post("s1", "o1", "refund_payable", "buyer_payment", 800)
    ledger.post("s1", "o1", "refund_payable", "platform_fee", 200)
    assert ledger.verify_zero_diff() == 0
