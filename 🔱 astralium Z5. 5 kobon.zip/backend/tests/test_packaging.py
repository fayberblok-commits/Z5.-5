"""قابلية النشر: كل ما تشير إليه الصورة/الـ compose يجب أن يوجد فعلًا وأن يكون قابلًا للاستيراد.

عيوب حقيقية كشفها هذا الملف وأُصلحت:
* `Dockerfile` كان ينسخ `pyproject.toml` من سياق بناء لا يحتويه → البناء يفشل.
* الصورة كانت تثبّت حزمًا غير مثبّتة الإصدار يدويًا وتنسى `psycopg[binary]` و`pyotp`
  → الحاوية تفشل عند الاستيراد (لا عند البناء)، أي فشل إنتاجي صامت.
* `docker-compose.yml` كان يحمل كلمات مرور افتراضية مكتوبة (`change-me-...`).
* خدمة `ai-service` كانت تشغّل وحدة بلا `__main__` → حاوية تخرج فورًا.
"""

from __future__ import annotations

import ast
import pathlib
import re
import tomllib

import yaml

ROOT = pathlib.Path(__file__).resolve().parents[2]
BACKEND = ROOT / "backend"
APP = BACKEND / "app"
STDLIB = set(__import__("sys").stdlib_module_names) | {"__future__"}


def _requirements() -> set[str]:
    text = (BACKEND / "requirements.txt").read_text(encoding="utf-8")
    names = set()
    for line in text.splitlines():
        line = line.strip()
        if not line or line.startswith("#") or line.startswith("-"):
            continue
        name = re.split(r"[=<>!\[;]", line, maxsplit=1)[0].strip().lower()
        names.add(name.replace("_", "-"))
    return names


def _top_level_imports() -> set[str]:
    found = set()
    for path in APP.rglob("*.py"):
        tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    found.add(alias.name.split(".")[0])
            elif isinstance(node, ast.ImportFrom) and node.level == 0 and node.module:
                found.add(node.module.split(".")[0])
    return found


def test_every_third_party_import_is_declared():
    declared = {n.replace("_", "-") for n in _requirements()}
    declared |= {"python-magic", "psycopg", "pyjwt", "pillow", "argon2-cffi", "botocore"}
    # أسماء الاستيراد تختلف عن أسماء الحزم في هذه الحالات
    alias = {
        "magic": "python-magic",
        "jwt": "pyjwt",
        "PIL": "pillow",
        "argon2": "argon2-cffi",
        "botocore": "botocore",
    }
    missing = []
    for mod in sorted(_top_level_imports()):
        if mod in STDLIB or mod == "app":
            continue
        key = alias.get(mod, mod.replace("_", "-")).lower()
        if key not in declared:
            missing.append(mod)
    assert not missing, f"وحدات مستوردة غير معلنة في requirements.txt: {missing}"


def test_requirements_are_exactly_pinned():
    unpinned = []
    for line in (BACKEND / "requirements.txt").read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or line.startswith("-"):
            continue
        if "==" not in line:
            unpinned.append(line)
    assert not unpinned, f"حزم غير مثبّتة الإصدار: {unpinned}"


def test_pyproject_and_requirements_agree():
    pyproject = tomllib.loads((ROOT / "pyproject.toml").read_text(encoding="utf-8"))
    def norm(d: str) -> str:
        return re.split(r"[=<>!\[;]", d, maxsplit=1)[0].strip().lower().replace("_", "-")

    declared = {norm(d) for d in pyproject["project"]["dependencies"]}
    # starlette اعتماد مباشر (نُثبّته صراحة) وليس واردًا في pyproject
    declared |= {"starlette"}
    assert declared == _requirements(), declared ^ _requirements()


def test_dockerfile_copy_sources_exist_and_hardening_present():
    dockerfile = (BACKEND / "Dockerfile").read_text(encoding="utf-8")
    for src in re.findall(r"^COPY\s+(\S+)", dockerfile, flags=re.MULTILINE):
        if src.startswith("--"):
            continue
        # سياق البناء هو مجلد backend/
        assert (BACKEND / src).exists(), f"COPY source missing in build context: {src}"
    assert "USER 65532:65532" in dockerfile, "must run as non-root"
    assert "HEALTHCHECK" in dockerfile, "must define a healthcheck"
    assert "pip install --no-cache-dir -r /app/requirements.txt" in dockerfile
    assert "python-jose" not in dockerfile and "asyncpg" not in dockerfile


def test_compose_has_no_default_credentials():
    compose = yaml.safe_load((ROOT / "docker-compose.yml").read_text(encoding="utf-8"))
    pattern = re.compile(r"^\$\{[A-Z_]+:\?")
    for name, svc in compose["services"].items():
        for key, value in (svc.get("environment") or {}).items():
            if any(t in key for t in ("PASSWORD", "SECRET", "TOKEN", "KEY")):
                assert pattern.match(str(value)), f"{name}.{key} has a default credential: {value}"


def test_every_compose_command_target_is_runnable():
    compose = yaml.safe_load((ROOT / "docker-compose.yml").read_text(encoding="utf-8"))
    for name, svc in compose["services"].items():
        cmd = svc.get("command")
        if not cmd or "app." not in " ".join(cmd):
            continue
        mod = [c for c in cmd if c.startswith("app.")][-1].split(":")[0]
        path = BACKEND / (mod.replace(".", "/") + ".py")
        assert path.exists(), f"{name}: module {mod} not found"
        src = path.read_text(encoding="utf-8")
        assert '__name__ == "__main__"' in src, f"{name}: {mod} has no __main__ entrypoint"
    for name, svc in compose["services"].items():
        assert svc.get("security_opt"), f"{name}: no-new-privileges required"
        assert svc.get("cap_drop") or name in {"db", "redis", "minio", "vault"}, f"{name}: cap_drop required"


def test_prod_compose_does_not_weaken_apparmor():
    prod = yaml.safe_load((ROOT / "docker-compose.prod.yml").read_text(encoding="utf-8"))
    for name, svc in prod["services"].items():
        for opt in svc.get("security_opt") or []:
            assert "apparmor=unconfined" not in opt, f"{name}: apparmor=unconfined disables confinement"


def test_sbom_matches_direct_runtime_versions():
    import json
    from packaging.requirements import Requirement
    bom = json.loads((ROOT / 'SBOM.json').read_text())
    actual = {c['name'].lower().replace('_', '-'): c['version'] for c in bom['components']}
    for line in (BACKEND / 'requirements.txt').read_text().splitlines():
        if not line.strip() or line.startswith('#'):
            continue
        req = Requirement(line)
        expected = next(iter(req.specifier)).version
        assert actual.get(req.name.lower().replace('_', '-')) == expected


def test_frontend_index_labels_demo_and_has_favicon():
    text = (ROOT / 'frontend/src/index.html').read_text()
    assert 'rel="icon"' in text
    assert '100%' not in text
    assert 'عرض توضيحي' in text
