from fastapi.testclient import TestClient

from app.core.rate_limit import limiter
from app.main import app

client = TestClient(app)


def test_reject_negative_amount():
    r = client.post("/orders", json={"store_id": "s1", "amount_cents": -500})
    assert r.status_code == 422


def test_reject_coupon_above_amount():
    r = client.post("/orders", json={"store_id": "s1", "amount_cents": 2000, "coupon_cents": 2001})
    assert r.status_code == 422


def test_reject_int_overflow():
    r = client.post("/orders", json={"store_id": "s1", "amount_cents": 2**63})
    assert r.status_code == 422


def test_reject_unsafe_store_id():
    for bad in ["s1'; DROP TABLE orders;--", "s1/../../etc", "s" * 65, ""]:
        r = client.post("/orders", json={"store_id": bad, "amount_cents": 100})
        assert r.status_code == 422, bad


def test_reject_bad_currency():
    r = client.post("/orders", json={"store_id": "s1", "amount_cents": 100, "currency": "usd$"})
    assert r.status_code == 422


def test_traversal_in_filename_rejected():
    """أسماء الملفات ذات المسارات تُرفض قبل أي تخزين (zip-slip/path traversal)."""
    from app.modules.files.secure_upload import UploadRejected, safe_object_name

    for bad in ("../etc/passwd", "..\\windows\\system32", "a/b.png", "x\x00.png"):
        try:
            safe_object_name(bad, "image/png")
            raise AssertionError(f"accepted unsafe name {bad!r}")
        except UploadRejected:
            pass


def test_rate_limit_enforced(monkeypatch):
    """الحد قابل للضبط من الإعدادات، ويُطبَّق فعليًا (429 بعد تجاوز الحد)."""
    from app.core.config import get_settings

    settings = get_settings()
    monkeypatch.setattr(settings, "rate_limit_per_min", 5)
    limiter.reset()
    codes = [client.get("/health").status_code for _ in range(8)]
    assert codes[:5] == [200] * 5
    assert codes[-1] == 429
    limiter.reset()
