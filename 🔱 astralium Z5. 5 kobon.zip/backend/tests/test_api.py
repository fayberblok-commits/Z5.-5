"""واجهات أساسية — العقد الجديد: كل مسار مالي يتطلب جلسة صالحة."""

from __future__ import annotations


def test_health(client):
    r = client.get("/health")
    assert r.status_code == 200
    assert r.json()["version"] == "5.5.0"


def test_register_login_me(client, db):
    r = client.post("/auth/register", json={
        "email": "owner1@example.com", "password": "StrongPassw0rd!23", "store_name": "Store A"})
    assert r.status_code == 200, r.text
    store_id = r.json()["store_id"]
    assert store_id

    r = client.post("/auth/login", json={"email": "owner1@example.com", "password": "StrongPassw0rd!23"})
    assert r.status_code == 200
    token = r.json()["access_token"]
    r = client.get("/me", headers={"Authorization": f"Bearer {token}"})
    assert r.status_code == 200
    assert r.json()["store_id"] == store_id


def test_product_create_and_list(client, make_merchant):
    m = make_merchant()
    r = client.post(f"/stores/{m['store_id']}/products",
                    json={"title": "كتاب", "price_minor": 2900}, headers=m["headers"])
    assert r.status_code == 200, r.text
    r = client.get(f"/stores/{m['store_id']}/products", headers=m["headers"])
    assert r.status_code == 200
    assert len(r.json()["products"]) == 1


def test_order_requires_auth(client, db):
    r = client.post("/orders", json={"store_id": "00000000-0000-0000-0000-000000000000", "amount_cents": 1000})
    assert r.status_code == 401


def test_order_authenticated(client, make_merchant):
    m = make_merchant()
    r = client.post("/orders", json={"store_id": m["store_id"], "amount_cents": 1000},
                    headers={**m["headers"], "Idempotency-Key": "ord-1"})
    assert r.status_code == 200, r.text
    body = r.json()
    assert body["net_minor"] == 1000
    assert body["platform_fee_minor"] == 200
    assert body["merchant_minor"] == 800
