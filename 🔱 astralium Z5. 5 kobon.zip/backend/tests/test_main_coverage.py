"""ترويسات أمنية، واجهة المتجر، مسارات إدارية، وتحقق من المدخلات."""

from __future__ import annotations

import pytest


def test_security_headers(client):
    r = client.get("/health")
    h = r.headers
    assert h["Strict-Transport-Security"].startswith("max-age=")
    assert h["X-Content-Type-Options"] == "nosniff"
    assert h["X-Frame-Options"] == "DENY"
    assert "default-src 'self'" in h["Content-Security-Policy"]
    assert "frame-ancestors 'none'" in h["Content-Security-Policy"]
    assert h["Cache-Control"] == "no-store"
    assert h["Cross-Origin-Opener-Policy"] == "same-origin"


def test_storefront(client):
    r = client.get("/")
    assert r.status_code == 200
    assert "Astralium" in r.text


def test_docs_disabled(client):
    for path in ("/docs", "/openapi.json", "/redoc"):
        assert client.get(path).status_code == 404


def test_admin_requires_auth(client, db):
    r = client.get("/admin/overview")
    assert r.status_code == 401


def test_admin_forbidden_for_merchant(client, make_merchant):
    m = make_merchant()
    r = client.get("/admin/overview", headers=m["headers"])
    assert r.status_code == 403


@pytest.mark.parametrize("payload", [
    {"store_id": "s1", "amount_cents": -500},
    {"store_id": "s1", "amount_cents": 2000, "coupon_cents": 2001},
    {"store_id": "s1", "amount_cents": 2**63},
    {"store_id": "s1'; DROP TABLE orders;--", "amount_cents": 100},
    {"store_id": "s1", "amount_cents": 100, "currency": "usd$"},
])
def test_order_validation(client, make_merchant, payload):
    m = make_merchant()
    payload = dict(payload, store_id=payload["store_id"] if payload["store_id"] != "s1" else m["store_id"])
    r = client.post("/orders", json=payload, headers=m["headers"])
    assert r.status_code == 422, r.text


def test_order_idempotent(client, make_merchant):
    m = make_merchant()
    h = {**m["headers"], "Idempotency-Key": "same-key-1"}
    body = {"store_id": m["store_id"], "amount_cents": 5000}
    first = client.post("/orders", json=body, headers=h)
    second = client.post("/orders", json=body, headers=h)
    assert first.status_code == second.status_code == 200
    assert first.json()["order_id"] == second.json()["order_id"]


def test_idempotency_key_reuse_with_different_payload(client, make_merchant):
    m = make_merchant()
    h = {**m["headers"], "Idempotency-Key": "same-key-2"}
    assert client.post("/orders", json={"store_id": m["store_id"], "amount_cents": 1000}, headers=h).status_code == 200
    r = client.post("/orders", json={"store_id": m["store_id"], "amount_cents": 9999}, headers=h)
    assert r.status_code == 400


def test_free_order_has_no_fee(client, make_merchant):
    m = make_merchant()
    r = client.post("/orders", json={"store_id": m["store_id"], "amount_cents": 0}, headers=m["headers"])
    assert r.status_code == 200
    assert r.json()["platform_fee_minor"] == 0
    assert r.json()["merchant_minor"] == 0
