from app.modules.guardian.service import AnomalyDetector, Honeytokens


def test_bruteforce():
    d = AnomalyDetector()
    for _ in range(5):
        d.record_login_fail("1.2.3.4")
    assert d.is_bruteforce("1.2.3.4")


def test_honey():
    h = Honeytokens()
    assert h.touch("honey_admin@example.com")
    assert len(h.alerts) == 1


def test_bulk_download():
    d = AnomalyDetector()
    for _ in range(21):
        flag = d.record_download("buyer1")
    assert flag
