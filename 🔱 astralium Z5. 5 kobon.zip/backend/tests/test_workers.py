from app.workers.video import generate_video
from app.workers.mail import send_email
import pytest


def test_video():
    v = generate_video("promo video for book")
    assert v.startswith("video://")


def test_mail():
    r = send_email("user@example.com", "Subject", "<p>hi</p>", "hi")
    assert r["sent"]
    with pytest.raises(ValueError):
        send_email("user@example.com", "Bad\nInjection", "<p>hi</p>", "hi")


def test_mail_bad_email():
    import pytest

    with pytest.raises(ValueError):
        send_email("not-an-email", "Subject", "<p>hi</p>", "hi")
