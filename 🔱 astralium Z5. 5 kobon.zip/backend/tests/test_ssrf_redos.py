"""SSRF، ReDoS، حقن ترويسات البريد، ومنع التخزين المؤقت."""

from __future__ import annotations

import re
import time

import pytest


def is_ssrf_url(url: str) -> bool:
    blocked = ["10.", "192.168.", "172.16.", "127.0.0.1", "169.254.", "localhost", "::1"]
    return any(b in url for b in blocked)


def test_ssrf_blocked():
    assert is_ssrf_url("http://10.0.0.1/admin")
    assert is_ssrf_url("http://169.254.169.254/latest/meta-data")
    assert not is_ssrf_url("https://api.stripe.com/v1/charges")


def test_safe_regex_is_linear():
    pattern = r"^a+$"
    start = time.time()
    re.match(pattern, "a" * 30 + "!")
    assert time.time() - start < 0.1


def test_email_header_injection():
    from app.workers.mail import send_email

    with pytest.raises(ValueError):
        send_email("victim@example.com", "Subject\nBcc: attacker@evil.com", "<p>hi</p>", "hi")


def test_cache_no_store(client):
    assert "no-store" in client.get("/health").headers["Cache-Control"]
