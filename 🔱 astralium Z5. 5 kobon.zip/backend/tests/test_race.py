"""سباقات تزامن — مخزون/كوبون/تحميلات."""

import threading

import pytest
from app.modules.commerce.marketing import create_coupon, COUPONS
from app.modules.ledger.service import Ledger


def test_coupon_race():
    COUPONS.clear()
    create_coupon("RACE10", 500, max_uses=5)
    successes = []

    def try_use():
        from app.modules.commerce.marketing import apply_coupon

        try:
            apply_coupon("RACE10", 2000)
            successes.append(1)
        except ValueError:
            successes.append(0)

    threads = [threading.Thread(target=try_use) for _ in range(10)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()
    # Only 5 should succeed
    assert sum(successes) == 5
    assert COUPONS["RACE10"]["uses"] == 5


def test_inventory_race():
    stock = {"p1": 3}
    lock = threading.Lock()
    sold = []

    def buy():
        with lock:
            if stock["p1"] > 0:
                stock["p1"] -= 1
                sold.append(1)
            else:
                sold.append(0)

    threads = [threading.Thread(target=buy) for _ in range(5)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()
    assert sum(sold) == 3
    assert stock["p1"] == 0


def test_download_race():
    from app.modules.files.service import sign_url, verify_signed_url

    secret = "race-secret-32bytes-long!!"
    assert "sig=" in sign_url(secret, "private", "key", "buyer1", 600)
    # concurrent verify should all succeed
    results = []

    def verify():
        import hmac
        import hashlib
        import time as t

        exp = str(int(t.time()) + 600)
        sig = hmac.new(secret.encode(), f"private/key:buyer1:{exp}".encode(), hashlib.sha256).hexdigest()
        results.append(verify_signed_url(secret, "private", "key", "buyer1", exp, sig))

    threads = [threading.Thread(target=verify) for _ in range(20)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()
    assert all(results)


def test_ledger_atomic_kill():
    # قتل العملية في منتصف الكتابة — يجب أن تكون ذرية
    ledger = Ledger()
    # simulate transaction: either both entries or none
    with pytest.raises(RuntimeError):
        ledger.post("s1", "o1", "buyer_payment", "merchant_receivable", 800)
        raise RuntimeError("killed")
    # كل post يُنشئ سطرين متوازنين (مدين/دائن) في مجموعة واحدة — لا سطر مفرد
    assert len(ledger.entries) == 2
    assert ledger.verify_zero_diff() == 0
    assert {e.direction for e in ledger.entries} == {"debit", "credit"}
