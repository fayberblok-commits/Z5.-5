from app.core.security import hash_password, verify_password
from app.core.encryption import generate_dek, wrap_dek, encrypt_field, decrypt_field
from app.modules.payments.adapters import verify_stripe_signature, stripe_sign_payload
from app.modules.files.service import quarantine_reason, sign_url, verify_signed_url
import time


def test_password_hash():
    h = hash_password("StrongPass123!")
    assert verify_password(h, "StrongPass123!")
    assert not verify_password(h, "wrong")


def test_encryption_roundtrip():
    kek = b"0" * 32
    dek = generate_dek()
    nonce, wrapped = wrap_dek(kek, dek)
    data = encrypt_field(kek, (nonce, wrapped), "SECRET-IBAN-1234", "bank:store1")
    pt = decrypt_field(kek, (nonce, wrapped), data, "bank:store1")
    assert pt == "SECRET-IBAN-1234"


def test_stripe_sig():
    payload = '{"id":"evt_123"}'
    secret = "whsec_test"
    ts = str(int(time.time()))
    header = stripe_sign_payload(payload, secret, ts)
    assert verify_stripe_signature(payload, header, secret)
    assert not verify_stripe_signature(payload, header, "wrong")


def test_file_quarantine():
    assert quarantine_reason(b"hello", "test.txt") is None
    assert quarantine_reason(b"X5O!P%@AP[4 virus", "x.txt") is not None
    assert quarantine_reason(b"<?php evil", "evil.jpg") is not None


def test_signed_url():
    url = sign_url("secret1234567890!!", "private", "key123", "buyer1", 600)
    # parse
    assert "sig=" in url
    # verify directly
    import time
    import hmac
    import hashlib

    exp = str(int(time.time()) + 600)
    sig = hmac.new(b"secret1234567890!!", f"private/key123:buyer1:{exp}".encode(), hashlib.sha256).hexdigest()
    assert verify_signed_url("secret1234567890!!", "private", "key123", "buyer1", exp, sig)


def test_permissions():
    from app.core.permissions import enforce

    enforce("owner", "store", "manage")
    try:
        enforce("buyer", "payment_config", "manage")
        raise AssertionError('expected rejection')
    except PermissionError:
        pass


def test_audit_chain_hash_helpers():
    """سلسلة التجزئة حتمية: نفس المدخل ⇒ نفس التجزئة، وأي تغيير يكسرها."""
    from app.core.audit import hash_entry, mac_hash

    entry = {"actor": "alice", "action": "create", "resource": "store",
             "result": "ok", "store_id": None, "meta": {}}
    prev = "0" * 64
    digest = hash_entry(prev, entry)
    assert digest == hash_entry(prev, entry)
    assert len(digest) == 64
    tampered = dict(entry, actor="eve")
    assert hash_entry(prev, tampered) != digest
    assert mac_hash("k" * 32, digest) != mac_hash("z" * 32, digest)


def test_audit_chain_persisted_and_tamper_evident(db):
    """السجل الحقيقي في PostgreSQL: صالح بعد الكتابة، ويكشف التعديل."""
    import psycopg

    from app.core.audit import audit_append, verify_chain
    from app.core.db import atomic

    with atomic() as conn:
        audit_append(conn, actor="alice", action="create", resource="store")
        audit_append(conn, actor="bob", action="update", resource="product")
    with atomic() as conn:
        assert verify_chain(conn)["valid"] is True
    conn = psycopg.connect(db["dsn"], row_factory=psycopg.rows.dict_row)
    conn.execute("ALTER TABLE audit_log DISABLE TRIGGER audit_append_only")
    conn.execute("UPDATE audit_log SET actor='eve' WHERE id=1")
    conn.commit()
    conn.execute("ALTER TABLE audit_log ENABLE TRIGGER audit_append_only")
    conn.commit()
    conn.close()
    with atomic() as conn:
        assert verify_chain(conn)["valid"] is False
