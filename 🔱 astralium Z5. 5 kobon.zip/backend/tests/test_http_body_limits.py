"""ASGI receive-level regressions: no dependency on client transport buffering."""
from __future__ import annotations

import asyncio

import pytest
from fastapi import HTTPException
from starlette.requests import Request

from app.core.http_body import read_limited_body


def make_request(messages, *, headers=()):
    seen = []
    async def receive():
        seen.append(True)
        return messages.pop(0)
    scope = {'type': 'http', 'method': 'POST', 'path': '/', 'headers': list(headers)}
    return Request(scope, receive), seen


@pytest.mark.asyncio
async def test_stops_receiving_on_first_excess_chunk():
    messages = [{'type': 'http.request', 'body': b'1234', 'more_body': True},
                {'type': 'http.request', 'body': b'5678', 'more_body': True},
                {'type': 'http.request', 'body': b'9', 'more_body': True},
                {'type': 'http.request', 'body': b'NEVER READ', 'more_body': False}]
    request, seen = make_request(messages)
    with pytest.raises(HTTPException) as caught:
        await read_limited_body(request, max_bytes=8)
    assert caught.value.status_code == 413
    assert len(seen) == 3
    assert len(messages) == 1


@pytest.mark.asyncio
async def test_exact_limit_succeeds():
    request, _ = make_request([{'type': 'http.request', 'body': b'12345678'}],
                              headers=[(b'content-length', b'8')])
    assert await read_limited_body(request, max_bytes=8) == b'12345678'


@pytest.mark.asyncio
@pytest.mark.parametrize('headers', [[(b'content-length', b'4'), (b'content-length', b'4')],
                                    [(b'content-length', b'4'), (b'transfer-encoding', b'chunked')],
                                    [(b'content-length', b'not-digits')]])
async def test_ambiguous_or_invalid_framing_never_reads(headers):
    request, seen = make_request([], headers=headers)
    with pytest.raises(HTTPException) as caught:
        await read_limited_body(request, max_bytes=8)
    assert caught.value.status_code == 400
    assert seen == []


@pytest.mark.asyncio
async def test_disconnect_is_controlled_error():
    request, _ = make_request([{'type': 'http.request', 'body': b'1234', 'more_body': True},
                              {'type': 'http.disconnect'}])
    with pytest.raises(HTTPException) as caught:
        await read_limited_body(request, max_bytes=8)
    assert caught.value.status_code == 400


@pytest.mark.asyncio
async def test_declared_size_mismatch_is_rejected():
    request, _ = make_request([{'type': 'http.request', 'body': b'1234'}],
                              headers=[(b'content-length', b'6')])
    with pytest.raises(HTTPException) as caught:
        await read_limited_body(request, max_bytes=8)
    assert caught.value.status_code == 400


@pytest.mark.asyncio
async def test_slow_body_times_out():
    async def receive():
        await asyncio.sleep(60)
        return {'type': 'http.request', 'body': b'late'}
    request = Request({'type': 'http', 'method': 'POST', 'path': '/', 'headers': []}, receive)
    with pytest.raises(HTTPException) as caught:
        await read_limited_body(request, max_bytes=8, timeout_seconds=0.01)
    assert caught.value.status_code == 408
