from app.core.vault import Vault


def test_vault():
    v = Vault("http://vault:8200", "token123")
    v.put_secret("stripe/key", "sk_test_abc123")
    assert v.get_secret("stripe/key") == "sk_test_abc123"
    assert v.mask("sk_test_abc123") == "****c123"
    assert v.mask("short") == "****"
