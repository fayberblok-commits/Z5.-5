from app.modules.templates_engine.legal import render_legal
from app.modules.templates_engine.invoice import render_invoice


def test_legal():
    out = render_legal("privacy_ar", {"store_name": "MyStore", "date": "2026-10-20"})
    assert "MyStore" in out
    assert "ليست بديلا" in out or "ليست بديلاً" in out


def test_invoice():
    html = render_invoice("ORD123", [{"title": "Book", "price": 2900}], 2900)
    assert "ORD123" in html
    assert "لا تظهر العمولة" in html
