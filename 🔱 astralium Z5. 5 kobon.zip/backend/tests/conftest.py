"""تهيئة الاختبارات: PostgreSQL حقيقي (مضمّن) + دور تطبيق غير مالك + إعدادات اختبار.

لا أسرار حقيقية: تُولَّد قيم عشوائية عند التشغيل وتُمرّر عبر متغيرات البيئة.
"""

from __future__ import annotations

import os
import pathlib
import secrets
import subprocess
import sys
import tempfile
import uuid

import pytest

BACKEND = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(BACKEND))

_TEST_SECRETS = {
    "APP_SECRET_KEY": secrets.token_urlsafe(36),
    "JWT_SECRET": secrets.token_urlsafe(36),
    "AUDIT_HMAC_KEY": secrets.token_urlsafe(36),
    "ENCRYPTION_KEK": secrets.token_urlsafe(36),
    "STRIPE_SECRET_KEY": "sk_test_" + secrets.token_hex(16),
    "STRIPE_WEBHOOK_SECRET": "whsec_" + secrets.token_hex(24),
    "STRIPE_CONNECT_CLIENT_ID": "ca_" + secrets.token_hex(16),
    "S3_SECRET_KEY": secrets.token_urlsafe(30),
    "S3_ACCESS_KEY": secrets.token_urlsafe(20),
}
APP_ROLE = "fibonix_app"
APP_PASSWORD = secrets.token_urlsafe(24)


def _base_env(database_url: str) -> dict[str, str]:
    env = {
        "APP_ENV": "test",
        "APP_BASE_URL": "https://testserver",
        "ADMIN_BASE_URL": "https://admin.testserver",
        "DATABASE_URL": database_url,
        "DATABASE_APP_ROLE": APP_ROLE,
        "DATABASE_APP_PASSWORD": APP_PASSWORD,
        "REDIS_URL": "redis://localhost:6379/0",
        "S3_ENDPOINT": "http://localhost:9000",
        "S3_BUCKET_PRIVATE": "fibonix-private",
        "S3_BUCKET_PUBLIC": "fibonix-public",
        "CLAMAV_HOST": "127.0.0.1",
        "CLAMAV_PORT": "3310",
        "ADMIN_ALLOWED_IPS": "testclient,127.0.0.1",
        "RATE_LIMIT_PER_MIN": "10000",
        "STRIPE_MOCK_TRANSPORT": "1",
    }
    env.update(_TEST_SECRETS)
    return env


@pytest.fixture(scope="session")
def pg_server():
    """يشغّل PostgreSQL مضمّنًا (binaries عبر pgembed) لقاعدة اختبار واحدة."""
    import pgembed

    # تنظيف أي عناقيد سابقة تركها تشغيل متوقف (تفشل initdb مع بقايا كثيرة)
    import glob
    import shutil

    for stale in glob.glob("/tmp/fibonix-pg-*"):  # nosec B108  # noqa: S108  # nosec B108 — مجلد اختبار مؤقت
        shutil.rmtree(stale, ignore_errors=True)

    root = pathlib.Path(tempfile.mkdtemp(prefix="fibonix-pg-")) / "data"
    server = pgembed.get_server(root)
    uri = server.get_uri()
    admin_dsn = uri.replace("/postgres?", "/postgres?")

    import psycopg

    db_name = f"fibonix_test_{uuid.uuid4().hex[:8]}"
    with psycopg.connect(admin_dsn, autocommit=True) as conn:
        conn.execute(f'CREATE DATABASE "{db_name}"')
    test_dsn = admin_dsn.replace("/postgres?", f"/{db_name}?")

    env = _base_env(test_dsn)
    os.environ.update(env)
    os.environ["DATABASE_URL"] = test_dsn

    # دور التطبيق (NOSUPERUSER/NOBYPASSRLS)
    result = subprocess.run(
        [sys.executable, "-m", "app.scripts.bootstrap_db"],
        cwd=BACKEND, env=os.environ, capture_output=True, text=True,
    )
    assert result.returncode == 0, result.stderr

    # الترحيلات الحقيقية
    result = subprocess.run(
        [sys.executable, "-m", "alembic", "-c", "alembic.ini", "upgrade", "head"],
        cwd=BACKEND, env=os.environ, capture_output=True, text=True,
    )
    assert result.returncode == 0, result.stderr

    yield {"dsn": test_dsn, "role": APP_ROLE, "password": APP_PASSWORD, "env": env}


@pytest.fixture(scope="session", autouse=True)
def settings_env(pg_server):
    """يضمن أن كل الاختبارات ترى نفس الإعدادات المُولّدة."""
    from app.core.config import reset_settings_cache

    os.environ.update(pg_server["env"])
    reset_settings_cache()
    yield pg_server["env"]
    reset_settings_cache()


@pytest.fixture()
def db(pg_server):
    """معاملة نظيفة لكل اختبار: يفرّغ الجداول ثم يسلّم الاتصال."""
    import psycopg
    from psycopg.rows import dict_row

    with psycopg.connect(pg_server["dsn"], autocommit=True, row_factory=dict_row) as conn:
        # الجداول append-only تمنع TRUNCATE (سلوك إنتاجي مقصود) — يُعطَّل الـ trigger
        # هنا فقط لتنظيف بيئة الاختبار، ويُعاد تفعيله فورًا.
        conn.execute("ALTER TABLE ledger_entries DISABLE TRIGGER ledger_no_truncate")
        conn.execute("ALTER TABLE audit_log DISABLE TRIGGER audit_no_truncate")
        conn.execute(
            """TRUNCATE ledger_entries, audit_log, file_download_tokens, files, idempotency_keys,
                        webhook_events, provider_refs, disputes, refunds, settlements, transfers,
                        platform_fees, payments, order_items, orders, products, merchant_accounts,
                        stores, revoked_jtis, sessions, accounts RESTART IDENTITY CASCADE"""
        )
        conn.execute("ALTER TABLE ledger_entries ENABLE TRIGGER ledger_no_truncate")
        conn.execute("ALTER TABLE audit_log ENABLE TRIGGER audit_no_truncate")
    return pg_server


@pytest.fixture()
def client(pg_server):
    """TestClient على HTTPS (كوكي __Host يتطلب Secure)."""
    from fastapi.testclient import TestClient

    from app.main import app

    with TestClient(app, base_url="https://testserver") as c:
        yield c


@pytest.fixture()
def owner_conn(pg_server):
    import psycopg
    from psycopg.rows import dict_row

    with psycopg.connect(pg_server["dsn"], row_factory=dict_row) as conn:
        yield conn


@pytest.fixture()
def make_merchant(client, db):
    """ينشئ تاجرًا + متجرًا ويعيد (headers, store_id, email)."""
    counter = {"n": 0}

    def _make(email: str | None = None) -> dict:
        counter["n"] += 1
        email = email or f"merchant{counter['n']}-{secrets.token_hex(4)}@example.com"
        password = "StrongPassw0rd!23"
        r = client.post("/auth/register", json={"email": email, "password": password, "store_name": "Store"})
        assert r.status_code == 200, r.text
        store_id = r.json()["store_id"]
        r = client.post("/auth/login", json={"email": email, "password": password})
        assert r.status_code == 200, r.text
        body = r.json()
        return {
            "email": email,
            "password": password,
            "store_id": store_id,
            "csrf": body["csrf_token"],
            "headers": {"Authorization": f"Bearer {body['access_token']}", "X-CSRF-Token": body["csrf_token"]},
        }

    return _make
