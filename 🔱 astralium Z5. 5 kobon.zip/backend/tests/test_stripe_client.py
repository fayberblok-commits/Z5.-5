"""عميل Stripe Connect: شكل المفتاح، الإلزاميّة، أخطاء النقل، وتوقيع الـ webhook.

هذه الأخطاء هي ما يقع فعليًا في الإنتاج (شبكة/4xx/5xx/idempotency ناقص)، وكل مسار
منها يجب أن ينتهي بخطأ صريح لا بنجاح صامت.
"""

from __future__ import annotations

import time

import httpx
import pytest

from app.modules.payments.stripe_connect import (
    StripeConnectClient,
    StripeError,
    compute_signature,
    verify_webhook,
)

KEY = "sk_test_" + "a" * 24


def _client(handler) -> StripeConnectClient:
    return StripeConnectClient(KEY, transport=httpx.MockTransport(handler))


def test_rejects_bad_key_shape():
    with pytest.raises(StripeError):
        StripeConnectClient("pk_live_not_a_secret")


def test_missing_idempotency_key_raises():
    c = _client(lambda r: httpx.Response(200, json={}))
    with pytest.raises(StripeError) as exc:
        c.create_payment_intent(amount_minor=100, currency="usd", order_id="o", buyer_email="b@x.y",
                                transfer_destination=None, idempotency_key="")
    assert exc.value.code == "missing_idempotency_key"


def test_transport_error_becomes_stripe_error():
    def boom(request):
        raise httpx.ConnectError("network down", request=request)

    with pytest.raises(StripeError) as exc:
        _client(boom).create_transfer(amount_minor=100, currency="usd", destination="acct_x",
                                     order_id="o", kind="merchant_payout", idempotency_key="k")
    assert exc.value.code == "transport_error"


def test_provider_4xx_is_surfaced_not_swallowed():
    def deny(request):
        return httpx.Response(402, json={"error": {"message": "insufficient funds", "code": "balance"}})

    with pytest.raises(StripeError) as exc:
        _client(deny).create_transfer(amount_minor=100, currency="usd", destination="acct_x",
                                      order_id="o", kind="merchant_payout", idempotency_key="k")
    assert exc.value.status == 402 and exc.value.code == "balance"


def test_non_json_error_body_still_raises():
    def html_error(request):
        return httpx.Response(500, text="<html>oops</html>")

    with pytest.raises(StripeError):
        _client(html_error).create_payment_intent(amount_minor=100, currency="usd", order_id="o",
                                                  buyer_email="b@x.y", transfer_destination=None,
                                                  idempotency_key="k")


@pytest.mark.parametrize("amount", [0, -1])
def test_non_positive_amounts_rejected(amount):
    c = _client(lambda r: httpx.Response(200, json={}))
    with pytest.raises(StripeError):
        c.create_transfer(amount_minor=amount, currency="usd", destination="acct_x", order_id="o",
                          kind="merchant_payout", idempotency_key="k")
    with pytest.raises(StripeError):
        c.create_payment_intent(amount_minor=amount, currency="usd", order_id="o", buyer_email="b@x.y",
                                transfer_destination=None, idempotency_key="k")


def test_retrieve_transfer_error_path():
    c = _client(lambda r: httpx.Response(404, json={"error": {"message": "no such transfer"}}))
    with pytest.raises(StripeError):
        c.retrieve_transfer("tr_missing")


def test_refund_request_carries_reason_and_key():
    seen = {}

    def capture(request):
        seen["body"] = request.content.decode()
        seen["idem"] = request.headers.get("Idempotency-Key")
        return httpx.Response(200, json={"id": "re_1", "status": "succeeded"})

    out = _client(capture).create_refund(payment_intent="pi_1", amount_minor=500, reason="customer request",
                                         idempotency_key="refund:o:1")
    assert out["id"] == "re_1"
    assert seen["idem"] == "refund:o:1"
    assert "reason=requested_by_customer" in seen["body"]


def test_signature_roundtrip_and_tolerance():
    secret, payload, ts = "whsec_test", b'{"id":"evt"}', int(time.time())
    sig = compute_signature(payload, secret, ts)
    assert verify_webhook(payload, f"t={ts},v1={sig}", secret) is True
    assert verify_webhook(payload, f"t={ts},v1=deadbeef", secret) is False
    assert verify_webhook(payload, f"t={ts - 3600},v1={sig}", secret) is False
    assert verify_webhook(payload + b" ", f"t={ts},v1={sig}", secret) is False
    assert verify_webhook(payload, "garbage", secret) is False


def test_multiple_signatures_any_valid_passes():
    secret, payload, ts = "whsec_test", b"{}", int(time.time())
    good = compute_signature(payload, secret, ts)
    assert verify_webhook(payload, f"t={ts},v1=bad,v1={good}", secret) is True
