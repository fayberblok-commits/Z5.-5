from app.modules.guardian.service import FileIntegrity, detector, honey, responder
from pathlib import Path
import tempfile


def test_integrity():
    with tempfile.TemporaryDirectory() as d:
        p = Path(d) / "a.py"
        p.write_text("print(1)")
        fi = FileIntegrity(Path(d))
        fi.snapshot()
        assert fi.verify() == []
        p.write_text("print(2)")
        assert len(fi.verify()) == 1


def test_autoresponse():
    detector.login_fail.clear()
    for _ in range(5):
        detector.record_login_fail("9.9.9.9")
    assert detector.is_bruteforce("9.9.9.9")
    honey.touch("honey_admin@example.com")
    assert len(honey.alerts) >= 1
    resp = responder.on_event({"type": "bruteforce", "ip": "9.9.9.9"})
    assert "9.9.9.9" in resp["revoked"]
