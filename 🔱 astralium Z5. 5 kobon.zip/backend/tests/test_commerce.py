from app.modules.commerce.taxes import calc_tax, shipping_cost
from app.modules.commerce.marketing import create_coupon, apply_coupon, seo_meta
from app.modules.media.service import upload_media, create_project
from app.modules.team.service import add_staff, can_staff
from app.modules.analytics.service import track, report
from app.modules.gdpr.service import gdpr
from app.modules.admin.paygate import toggle, check_connection
from app.modules.admin.bank import mask_iban


def test_tax_shipping():
    assert calc_tax(1000, "SA") == 150
    assert shipping_cost("MENA") == 500


def test_coupon():
    create_coupon("SAVE10", 1000)
    assert apply_coupon("SAVE10", 2000) == 1000
    # exhausted
    for _ in range(99):
        apply_coupon("SAVE10", 2000)
    try:
        apply_coupon("SAVE10", 2000)
        raise AssertionError('expected rejection')
    except ValueError:
        pass


def test_media_project():
    m = upload_media("store1", "book.pdf", 1234, "application/pdf")
    assert "store1" in m["key"]
    p = create_project("store1", "My Store")
    assert p["name"] == "My Store"


def test_team():
    add_staff("staff@example.com", {"product.read", "order.create"})
    assert can_staff("staff@example.com", "product.read")
    assert not can_staff("staff@example.com", "store.delete")


def test_analytics():
    track("visit", "s1")
    track("sale", "s1", {"product_id": "p1"})
    track("sale", "s1", {"product_id": "p1"})
    r = report("s1")
    assert r["sales"] >= 2


def test_gdpr():
    exp = gdpr.export_customer("a@example.com", "s1")
    assert exp["email"] == "a@example.com"
    dele = gdpr.delete_customer("a@example.com", "s1")
    assert dele["deleted"]


def test_paygate():
    toggle("stripe", True)
    assert check_connection("stripe")
    assert mask_iban("SA1234567890") == "****7890"


def test_seo():
    m = seo_meta("Title", "Desc")
    assert "og_title" in m
