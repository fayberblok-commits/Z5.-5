from app.modules.ai.providers import providers


def test_limits():
    p = providers["openai"]
    p.usage_cents = 0
    out = p.generate("hello world")
    assert "generated" in out
    try:
        for _ in range(1000):
            p.generate("x")
        raise AssertionError('expected rejection')
    except RuntimeError:
        pass
    p.usage_cents = 0
