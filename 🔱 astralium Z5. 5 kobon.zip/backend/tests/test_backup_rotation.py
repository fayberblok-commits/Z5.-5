from pathlib import Path


def test_backup_and_restore(tmp_path: Path):
    import app.scripts.backup as b

    b.BACKUP_DIR = str(tmp_path)
    p = b.backup()
    assert Path(p).exists()
    assert b.restore(p)


def test_key_rotation():
    from app.scripts.rotate_keys import rotate
    from app.core.encryption import generate_dek, wrap_dek, unwrap_dek

    kek1 = b"1" * 32
    kek2 = b"2" * 32
    dek = generate_dek()
    w1 = wrap_dek(kek1, dek)
    w2 = rotate(kek1, kek2, w1)
    d1 = unwrap_dek(kek1, w1[0], w1[1])
    d2 = unwrap_dek(kek2, w2[0], w2[1])
    assert d1 == d2
