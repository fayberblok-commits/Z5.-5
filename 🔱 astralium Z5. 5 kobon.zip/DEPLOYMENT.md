> **حزمة التسليم الحالية: `🔱 astralium Z5. 5 kobon.zip` — 2026-10-20.** المصدر الحالي مغلّف للتحميل، وليس إصدارًا معتمدًا للإنتاج. الاختبارات الأخيرة340×3، وDAST18/18×3، وحمل20VUs×20s×3؛ تقاريرها في `reports/final-delivery/`. العوائق O01–O12 ما زالت مفتوحة. هذه الملاحظة تعلو ملاحظات الجولات السابقة عن عدم إنشاء أرشيف، وهي محفوظة كسجل تاريخي.

> **تحديث متابعة 2026-10-20 — مصدر قيد التقوية، وليس تسليمًا نهائيًا.** أُضيف ADR-018 وإصلاحات قراءة الرفع تدريجيًا قبل استهلاك الجسم، والتحقق من Webhook قبل DB، ومنع قيد بيع مكرر بحدثين مختلفين ومنع إخفاق متأخر من إفساد دفعة ناجحة. آخر مجموعة كاملة: **340 اختبارًا ناجحًا ×3**؛ التغطية **88.08%–88.12%**، واختلاف السطر يعود إلى أسماء fuzz العشوائية في المساعد القديم، لا إلى اختلاف نتائج النجاح. بقيت العوائق O01–O12. تقارير الجولة الجديدة في `reports/round2/`؛ تقارير الواجهة والحمل وDAST السابقة تاريخية ولم تُعد في هذه المتابعة. **لم تُنشأ حزمة إطلاق جديدة**؛ الأرشيف السابق نُقل إلى `previous-audit/` ولا يمثل هذا المصدر المعدّل.

# النشر — مسودة تطوير فقط
**غير معتمد لـ Staging ببيانات حقيقية أو للإنتاج. Docker غير متاح في بيئة المراجعة.**

## ما تحقق
مصادر COPY في Dockerfile موجودة، runtime requirements مطابقة للاعتماديات المباشرة ومقيدة بـ requirements.lock، non-root 65532، healthcheck، no-server-header، read-only/drop capabilities للتطبيق/العامل في Compose. YAML يُقرأ باختبارات التغليف. هذا فحص ساكن لا دليل build/start.

## إعداد محلي آمن
1. استخدم Python virtualenv منفصلًا للتطبيق. ثبت `pip install -r backend/requirements.txt -c backend/requirements.lock`. الملف lock محلول على Python 3.13/Linux؛ أعد الاختبار على Python 3.12 وصورة الهدف.
2. انسخ `.env.example` إلى ملف محلي مستبعد. املأ كل secret بقيمة مستقلة مولّدة بأداة إدارة أسرار، لا نص ثابت. استخدم DSN psycopg `postgresql://`، وليس `postgresql+asyncpg://`. النموذج الفارغ مقصود أن يفشل.
3. لا تستخدم `APP_ENV=test` لخدمة عامة. `STRIPE_MOCK_TRANSPORT=1` مرفوض خارج test؛ مفاتيح الدفع الحقيقية/Live ممنوعة في هذه المراجعة.
4. أنشئ مالك DB للترحيلات، ودور تطبيق غير مالك/NOBYPASSRLS؛ bootstrap/الترحيلات تتطلب صلاحيات منفصلة. من backend: `python -m app.scripts.bootstrap_db` ثم `alembic upgrade head`. لا تشغّل web بدور إدارة.
5. خارج test، يجب Redis متاحًا عند الإقلاع. اضبط S3 bucket private وسياسات منع public access، clamd، TLS، IP allowlist وسجلات منقحة. إصدار URL من التطبيق ليس إثباتًا لصحة bucket policy.

## عوائق Compose المفتوحة
- `postgres:16-alpine` و`redis:7-alpine` و`python:3.12-slim` وغيرها mutable؛ MinIO بلا tag. لم تُثبت digests لأن الصور لم تُسحب/تُتحقق. لا تختلق digest.
- منافذ DB/Redis/MinIO/Vault في ملف التطوير مكشوفة على المضيف؛ قيدها loopback أو احذف ports في نشر خاص بعد اختبار الشبكات.
- Vault يعمل بإعداد dev وليس خدمة أسرار إنتاجية، وcore/vault.py لا يستعمله أصلًا. ClamAV ليس خدمة مكتملة في Compose؛ الرفع سيرفض بأمان عند غيابه.
- `docker-compose.prod.yml` مسودة بها placeholder domain وتوجيه Caddy مباشرة إلى web؛ وجود حاوية WAF لا يعني مرور الطلبات بها. التطبيق منشور أيضًا على 8000؛ يمكن تجاوز WAF.
- production DB password reference لا يفرض `:?`، والموارد الجانبية لا تحقق كل hardening المطلوب. لا تعتمد على هذه المسودة في بيئة مكشوفة.
- إسقاط جميع capabilities قد يمنع init لبعض صور البنية؛ لم يُثبت التشغيل. AppArmor/docker-default وseccomp الفعلي وnon-root لخدمات الطرف الثالث غير مثبتة.

## بوابات النشر
Sandbox رسمي للمدفوعات مع إثبات settlement/fees، Redis/MinIO/Vault/ClamAV متكاملة، immutable images + SBOM للصورة + hadolint + Trivy image، docker compose config/build/up مع أسرار اختبار، ZAP فعلي، WAF routing/egress، WebAuthn، backup مشفر واستعادة مستقلة بقاعدة جديدة، crash/retry reconciliation، حمل ساعة متعدد عمليات، مراقبة/تنبيهات واستجابة حوادث. لا تُعوض هذه البوابات بنتائج mock.

## قيود أدوات التدقيق
Semgrep في venv مستقل (إصدارات OpenTelemetry تتعارض مع runtime). اجعل bin الخاص به أول PATH لأن launcher يستدعي pysemgrep بالاسم. SBOM يصف Python runtime فقط؛ لا يصف بيئة scanner الشاملة أو نظام تشغيل الصورة. `reports/runtime-pip-check.txt` يثبت التوافق داخل virtualenv runtime المعزول، لا كل حزم sandbox.
