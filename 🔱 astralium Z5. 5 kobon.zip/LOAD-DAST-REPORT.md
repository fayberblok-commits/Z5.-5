# DAST والحمل — نطاق محدود
2026-10-20. الخادم: tools/serve_live.py، PostgreSQL مضمّن، APP_ENV=test، MockTransport للمال وMemoryBackend لمحدد المعدل. ليس بيئة إنتاج.

- tools/dast.py: 18/18 ×3. ليس OWASP ZAP، ولا يمثّل تغطية كل payload/route/role.
- k6 2.3.0: 20 VUs ×20 ثانية ×3، طلبات health وroot فقط. checks 3550/3684/3814 ناجحة، http_req_failed=0 في التشغيلات الثلاثة؛ p95:36.45/31.03/16.46ms؛ p99:51.10/66.56/40.19ms. Thresholds p95<500ms وp99<1000ms ناجحة.
- لم يُنفذ حمل ساعة، ولا حمل معاملات دفع/تحميل ملفات، ولا multi-replica، ولا قياس Redis/S3 تحت ضغط. لا تعمم هذه الأرقام على أداء الشراء أو الإنتاج.
- تقارير JSON الخام في reports/dast_run*.json وreports/k6_run*.json. أي أرقام مختلفة بوثائق أقدم ملغاة بهذه الجولة.
