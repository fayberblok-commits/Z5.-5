> **حزمة التسليم الحالية: `🔱 astralium Z5. 5 kobon.zip` — 2026-10-20.** المصدر الحالي مغلّف للتحميل، وليس إصدارًا معتمدًا للإنتاج. الاختبارات الأخيرة340×3، وDAST18/18×3، وحمل20VUs×20s×3؛ تقاريرها في `reports/final-delivery/`. العوائق O01–O12 ما زالت مفتوحة. هذه الملاحظة تعلو ملاحظات الجولات السابقة عن عدم إنشاء أرشيف، وهي محفوظة كسجل تاريخي.

> **تحديث متابعة 2026-10-20 — مصدر قيد التقوية، وليس تسليمًا نهائيًا.** أُضيف ADR-018 وإصلاحات قراءة الرفع تدريجيًا قبل استهلاك الجسم، والتحقق من Webhook قبل DB، ومنع قيد بيع مكرر بحدثين مختلفين ومنع إخفاق متأخر من إفساد دفعة ناجحة. آخر مجموعة كاملة: **340 اختبارًا ناجحًا ×3**؛ التغطية **88.08%–88.12%**، واختلاف السطر يعود إلى أسماء fuzz العشوائية في المساعد القديم، لا إلى اختلاف نتائج النجاح. بقيت العوائق O01–O12. تقارير الجولة الجديدة في `reports/round2/`؛ تقارير الواجهة والحمل وDAST السابقة تاريخية ولم تُعد في هذه المتابعة. **لم تُنشأ حزمة إطلاق جديدة**؛ الأرشيف السابق نُقل إلى `previous-audit/` ولا يمثل هذا المصدر المعدّل.

# نموذج التهديد — مراجعة 2026-10-20

## الأصول والخصوم
أرصدة المنصة/التاجر، الدفتر، حسابات المستخدمين، ملفات رقمية، مفاتيح وتوكنات، audit ونسخ قاعدة البيانات. الخصم زائر مجهول، مستخدم خبيث، متجر/موظف يحاول عبور حدود متجره، مزود AI مخترق، webhook مُعاد، مورد supply chain أو مسؤول بنية ذو صلاحية. يُفترض تعديل HTTP والوصول إلى الواجهات العامة والتزامن والانقطاع.

| التهديد | الضابط/الدليل | الفجوة المتبقية |
|---|---|---|
| تسريب سر عند الإقلاع | hide_input_in_errors + ConfigError generic؛ regression redaction | logging خارجي/Serialization غير مدقق بالكامل |
| IDOR ومتجر آخر | tenant context + FORCE RLS + NOSUPERUSER/NOBYPASSRLS؛ tests/rls | استحقاق ملف عبر شراء ومصفوفة API كاملة |
| دفع تاجر مرتين | منع destination charge مع التحويل المستقل؛ regression طلب HTTP | تسوية المزود وإعادة المحاولات طويلة الأجل |
| تزوير/replay webhook | HMAC/timestamp + unique events + transactions | توافق الأحداث الرسمية، تضارب أحداث مختلفة/ترتيبها |
| سرقة رابط ملف | لا S3 bearer URL؛ جلسة/قفل/expiry/one-use | إعادة إصدار الرمز، انقطاع delivery، entitlement |
| ملف ضار | allowlist/magic/heuristics + clamd fail-closed | محرك فعلي وصيغ معقدة وأرشيفات عميقة |
| prompt injection | unknown deny + human confirmation/step-up + اختبارات EN/AR/Unicode | لا ضمان منع كل prompt؛ لا إثبات عزل خدمة/egress |
| session theft/CSRF | host cookies/CSRF/device fingerprint/revocation | fingerprints قابلة للتقليد، WebAuthn غير منفذ |
| العبث بالدفتر/audit | constraints/triggers/hash-chain وتحقق مستقل محليًا | DBA يمكنه إعادة كتابة سلسلة كاملة؛ checkpoint خارجي غائب |
| فشل خادم/قرص | atomic write وkill-mid-write regression | backup/restore الفعلي وRPO/RTO/HA غير مثبتة |
| فتح خدمات البيانات | إعدادات مسودة غير معتمدة | منافذ dev وصور mutable/WAF routing/Vault dev |

## قرارات المخاطر
لا يُقبل أي رصيد أو بيانات مستخدمين حقيقية في هذه النسخة. نموذج test يستخدم ذاكرة للـ rate limit وMockTransport؛ ليس ضابطًا تشغيليًا متعدد النسخ. الأولوية التالية: official financial reconciliation ثم entitlement/backup/Vault/isolation. كشف ثغرة جديدة يبطل قرارًا سابقًا بالجاهزية، حتى لو بقيت كل الاختبارات خضراء.
