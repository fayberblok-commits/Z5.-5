# تقرير الواجهة الحالي — 2026-10-20
الأدلة الحاكمة: reports/a11y_run1.json وrun2 وrun3. أُعيد التحقق عبر Playwright CLI/Chromium الموجود في البيئة، دون تثبيت متصفح جديد.

17 صفحة HTML ×7 viewports =119 فحص تخطيط في كل تشغيل، ثلاث تشغيلات متتالية. H1 مرئي وlang=ar، overflow لا يزيد عن 1px، ولا console errors أو HTTP>=400 في نطاق الصفحات. axe-core 4.10.2 على 17 صفحة عند عرض 375 في كل تشغيل، بلا violations ضمن tags WCAG A/AA المختارة. هذا ليس إثبات امتثال كامل أو اختبار قارئ شاشة بشري أو رحلة شراء متصلة بالمزود. لم تُختبر جميع الثيمات التسعة في هذه الجولة.

Negative control شُغّل ×3: اكتشف button-name وcolor-contrast وimage-alt وغيرها؛ reports/axe-negative-control.json. اكتُشف favicon 404 ونص اعتماد وصولية غير مسند في index، وأُصلحا؛ الصورة index-audited.png لتوثيق الصفحة المعدلة وليست أداة تحليل أسرار صور.

إعادة التشغيل في بيئة Arena: شغّل static server، انسخ e2e-artifacts/axe.min.js مؤقتًا إلى frontend/src/audit-axe.js، وافتح جلسة playwright-cli المسماة arena على Chromium، ثم مرّر محتوى tools/browser-audit.js إلى run-code. الناتج JSON في Result؛ أزل النسخة المؤقتة بعد التشغيل. أدوات Python القديمة في tools/a11y_e2e.py بديل يتطلب Playwright Python مثبّتًا، ولم يُستخدم بعد إعادة إنشاء بيئة هذه الجولة.
