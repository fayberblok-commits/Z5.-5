"""يشغّل مكدّسًا حقيقيًا للإختبار الحي: PostgreSQL مضمّن + ترحيلات + uvicorn.

لا أسرار ثابتة: كل المفاتيح تُولّد عشوائيًا لكل تشغيل (وهي قيم اختبار، لا مزود حقيقي).
الاستخدام: python3 tools/serve_live.py --port 8200
"""

from __future__ import annotations

import argparse
import os
import pathlib
import secrets
import subprocess
import sys

BACKEND = pathlib.Path(__file__).resolve().parents[1] / "backend"

SECRETS = {
    "APP_SECRET_KEY": secrets.token_urlsafe(36),
    "JWT_SECRET": secrets.token_urlsafe(36),
    "AUDIT_HMAC_KEY": secrets.token_urlsafe(36),
    "ENCRYPTION_KEK": secrets.token_urlsafe(36),
    "STRIPE_SECRET_KEY": "sk_test_" + secrets.token_hex(16),
    "STRIPE_WEBHOOK_SECRET": "whsec_" + secrets.token_hex(24),
    "STRIPE_CONNECT_CLIENT_ID": "ca_" + secrets.token_hex(16),
    "S3_SECRET_KEY": secrets.token_urlsafe(30),
    "S3_ACCESS_KEY": secrets.token_urlsafe(20),
}


def build_env(dsn: str) -> dict[str, str]:
    env = dict(os.environ)
    env.update(SECRETS)
    env.update(
        {
            "APP_ENV": "test",
            "APP_BASE_URL": "https://testserver",
            "ADMIN_BASE_URL": "https://admin.testserver",
            "DATABASE_URL": dsn,
            "DATABASE_APP_ROLE": "fibonix_app",
            "DATABASE_APP_PASSWORD": secrets.token_urlsafe(24),
            "REDIS_URL": "redis://localhost:6379/0",
            "S3_ENDPOINT": "http://localhost:9000",
            "S3_BUCKET_PRIVATE": "fibonix-private",
            "S3_BUCKET_PUBLIC": "fibonix-public",
            "CLAMAV_HOST": "127.0.0.1",
            "CLAMAV_PORT": "3310",
            "ADMIN_ALLOWED_IPS": "127.0.0.1",
            "RATE_LIMIT_PER_MIN": "100000",
            "STRIPE_MOCK_TRANSPORT": "1",
        }
    )
    return env


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--port", type=int, default=8200)
    ap.add_argument("--root", default="/tmp/fibonix-live")
    args = ap.parse_args()

    import psycopg
    import pgembed

    root = pathlib.Path(args.root) / "data"
    root.parent.mkdir(parents=True, exist_ok=True)
    server = pgembed.get_server(root)
    uri = server.get_uri()
    db_name = "fibonix_live"
    with psycopg.connect(uri, autocommit=True) as conn:
        exists = conn.execute("SELECT 1 FROM pg_database WHERE datname=%s", (db_name,)).fetchone()
        if not exists:
            conn.execute(f'CREATE DATABASE "{db_name}"')
            print("created database", db_name, flush=True)
    dsn = uri.replace("/postgres?", f"/{db_name}?")

    env = build_env(dsn)
    for cmd in (
        [sys.executable, "-m", "app.scripts.bootstrap_db"],
        [sys.executable, "-m", "alembic", "-c", "alembic.ini", "upgrade", "head"],
    ):
        r = subprocess.run(cmd, cwd=BACKEND, env=env, capture_output=True, text=True)
        if r.returncode != 0:
            print(r.stdout, r.stderr, file=sys.stderr)
            raise SystemExit(f"setup failed: {cmd}")

    os.environ.update(env)
    sys.path.insert(0, str(BACKEND))
    os.chdir(BACKEND)
    import uvicorn

    print(f"serving on 0.0.0.0:{args.port}", flush=True)
    uvicorn.run("app.main:app", host="0.0.0.0", port=args.port, log_level="warning",
                server_header=False)  # لا نكشف بصمة الخادم


if __name__ == "__main__":
    main()
