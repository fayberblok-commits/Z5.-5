"""Harness حقيقي: Playwright (Chromium) + axe-core على صفحات المتجر.

يقيس ما يمكن قياسه فعلًا ولا يدّعي غير ذلك:
* فائض أفقي (scrollWidth - clientWidth) لكل صفحة × كل مقاس.
* وجود H1 مرئي واسمه.
* مخالفات axe-core (WCAG 2.0/2.1/2.2 A+AA) مع تفاصيل العقدة.
* أخطاء الكونسول و4xx/5xx للطلبات.
* تباين فعلي محسوب (سلف/خلفية) لأهم عنصر نصي.

الاستخدام:
    python3 tools/a11y_e2e.py --base http://127.0.0.1:8123 --out reports/a11y_run1.json
"""

from __future__ import annotations

import argparse
import json
import pathlib
import sys

from playwright.sync_api import sync_playwright

PAGES = [
    "home-full",
    "catalog-full",
    "category-full",
    "product-full",
    "cart-full",
    "checkout-full",
    "thankyou-full",
    "account-full",
    "login-full",
    "about-full",
    "contact-full",
    "faq-full",
    "blog-full",
    "landing-full",
    "404-full",
    "maintenance-full",
    "track-full",
]

VIEWPORTS = [
    (320, 568),
    (375, 667),
    (768, 1024),
    (1024, 768),
    (1280, 800),
    (1440, 900),
    (1920, 1080),
]

AXE_SOURCE = pathlib.Path(__file__).resolve().parents[1] / "e2e-artifacts" / "axe.min.js"

CONTRAST_JS = """
() => {
  const el = document.querySelector('h1');
  if (!el) return null;
  const cs = getComputedStyle(el);
  const parse = (c) => {
    const m = c.match(/rgba?\\(([^)]+)\\)/);
    if (!m) return [0, 0, 0, 1];
    const p = m[1].split(',').map((x) => parseFloat(x));
    return [p[0], p[1], p[2], p.length > 3 ? p[3] : 1];
  };
  const lum = ([r, g, b]) => {
    const f = (v) => {
      v /= 255;
      return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4);
    };
    return 0.2126 * f(r) + 0.7152 * f(g) + 0.0722 * f(b);
  };
  let bgEl = el, bg = [255, 255, 255, 1];
  while (bgEl) {
    const c = parse(getComputedStyle(bgEl).backgroundColor);
    if (c[3] > 0) { bg = c; break; }
    bgEl = bgEl.parentElement;
  }
  const fg = parse(cs.color);
  const l1 = lum(fg), l2 = lum(bg);
  const ratio = (Math.max(l1, l2) + 0.05) / (Math.min(l1, l2) + 0.05);
  return {
    text: (el.textContent || '').trim().slice(0, 60),
    fontSize: cs.fontSize,
    color: cs.color,
    background: `rgb(${bg[0]}, ${bg[1]}, ${bg[2]})`,
    ratio: Math.round(ratio * 100) / 100,
  };
}
"""


def run(base: str, out: pathlib.Path, screenshots: bool) -> dict:
    results = {"base": base, "viewports": [], "axe": [], "pages": [], "console_errors": [], "http_errors": []}
    axe_src = AXE_SOURCE.read_text(encoding="utf-8")
    with sync_playwright() as pw:
        browser = pw.chromium.launch()
        try:
            for width, height in VIEWPORTS:
                ctx = browser.new_context(viewport={"width": width, "height": height}, device_scale_factor=1)
                page = ctx.new_page()
                console_errors: list[str] = []
                http_errors: list[str] = []
                page.on("console", lambda m: console_errors.append(m.text) if m.type == "error" else None)
                page.on("response", lambda r: http_errors.append(f"{r.status} {r.url}") if r.status >= 400 else None)

                vp_entry = {"viewport": f"{width}x{height}", "pages": []}
                for name in PAGES:
                    page.goto(f"{base}/{name}.html", wait_until="load")
                    page.add_script_tag(content=axe_src)
                    overflow = page.evaluate(
                        "() => document.documentElement.scrollWidth - document.documentElement.clientWidth"
                    )
                    h1 = page.evaluate(
                        "() => { const h = document.querySelector('h1');"
                        " return h ? { visible: !!(h.offsetWidth || h.offsetHeight), text: h.textContent.trim() } : null; }"
                    )
                    lang = page.evaluate("() => ({lang: document.documentElement.lang, dir: document.documentElement.dir})")
                    vp_entry["pages"].append(
                        {
                            "page": name,
                            "overflow_px": overflow,
                            "h1": h1,
                            "lang": lang,
                        }
                    )
                    if width == 375:
                        axe_res = page.evaluate(
                            """async () => await axe.run(document, {runOnly: {type: 'tag',
                               values: ['wcag2a','wcag2aa','wcag21a','wcag21aa','wcag22aa']}})"""
                        )
                        violations = [
                            {
                                "id": v["id"],
                                "impact": v["impact"],
                                "help": v["help"],
                                "nodes": [n["target"] for n in v["nodes"]][:5],
                                "count": len(v["nodes"]),
                            }
                            for v in axe_res["violations"]
                        ]
                        results["axe"].append({"page": name, "violations": violations})
                        results["pages"].append(
                            {"page": name, "contrast": page.evaluate(CONTRAST_JS), "title": page.title()}
                        )
                        if screenshots:
                            d = pathlib.Path("e2e-artifacts")
                            d.mkdir(exist_ok=True)
                            page.screenshot(path=str(d / f"{name}-375.png"), full_page=True)
                vp_entry["console_errors"] = console_errors
                vp_entry["http_errors"] = http_errors
                results["console_errors"].extend(console_errors)
                results["http_errors"].extend(http_errors)
                results["viewports"].append(vp_entry)
                ctx.close()
        finally:
            browser.close()

    failures = []
    for vp in results["viewports"]:
        for p in vp["pages"]:
            if p["overflow_px"] > 1:
                failures.append(f"overflow {p['page']} @{vp['viewport']}: {p['overflow_px']}px")
            if not p["h1"] or not p["h1"]["visible"]:
                failures.append(f"missing h1 {p['page']} @{vp['viewport']}")
            if p["lang"]["lang"] != "ar":
                failures.append(f"lang wrong {p['page']}: {p['lang']}")
    for entry in results["axe"]:
        for v in entry["violations"]:
            failures.append(f"axe {v['id']} ({v['impact']}) on {entry['page']} x{v['count']}")
    if results["console_errors"]:
        failures.append(f"console errors: {len(results['console_errors'])}")
    if results["http_errors"]:
        failures.append(f"http errors: {len(results['http_errors'])}")

    results["failures"] = failures
    results["verdict"] = "PASS" if not failures else "FAIL"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(results, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({"verdict": results["verdict"], "failures": failures[:20],
                      "pages": len(PAGES), "viewports": len(VIEWPORTS),
                      "axe_pages": len(results["axe"]),
                      "console_errors": len(results["console_errors"]),
                      "http_errors": len(results["http_errors"])}, ensure_ascii=False))
    return results


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--base", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--screenshots", action="store_true")
    a = ap.parse_args()
    r = run(a.base, pathlib.Path(a.out), a.screenshots)
    sys.exit(0 if r["verdict"] == "PASS" else 1)
