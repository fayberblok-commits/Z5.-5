"""DAST حقيقي ضد التطبيق الحي (بديل موثّق لـ ZAP baseline — ZAP يحتاج Docker غير متاح هنا).

كل فحص هنا سلبي/إيجابي ومُسمّى، ويُخرج JSON. لا "نجاح" بلا فحص فعلي:
كل فحص يرسل طلبًا واحدًا على الأقل ويقيّم الاستجابة.
"""

from __future__ import annotations

import argparse
import json
import pathlib
import sys
import time
import uuid

import httpx

SECRET_LEAK_PATTERNS = ("Traceback", "postgresql://", "sk_test", "whsec_", "psycopg", "File \"/app")


def _result(name: str, ok: bool, detail: str = "", status: int | None = None) -> dict:
    return {"check": name, "ok": ok, "detail": detail, "status": status}


def run(base: str, out: pathlib.Path) -> dict:
    c = httpx.Client(base_url=base, timeout=10.0, verify=False, follow_redirects=False)
    checks: list[dict] = []
    leaks: list[str] = []

    def get(path, **kw):
        r = c.get(path, **kw)
        _scan(r.text)
        return r

    def post(path, **kw):
        r = c.post(path, **kw)
        _scan(r.text)
        return r

    def _scan(body: str) -> None:
        for pat in SECRET_LEAK_PATTERNS:
            if pat in body:
                leaks.append(f"{pat} in body")

    # 1) ترويسات أمنية
    r = get("/health")
    required = [
        "strict-transport-security",
        "x-content-type-options",
        "x-frame-options",
        "referrer-policy",
        "permissions-policy",
        "content-security-policy",
        "cross-origin-opener-policy",
        "cross-origin-resource-policy",
    ]
    missing = [h for h in required if h not in r.headers]
    checks.append(_result("security_headers", not missing, f"missing={missing}", r.status_code))

    # 2) لا بصمة خادم
    checks.append(_result("no_server_fingerprint", "server" not in r.headers, str(dict(r.headers).get("server")),
                          r.status_code))

    # 3) لا توثيق/مخطط مكشوف
    o = get("/openapi.json")
    d = get("/docs")
    checks.append(_result("no_api_docs_exposed", o.status_code == 404 and d.status_code == 404,
                          f"openapi={o.status_code} docs={d.status_code}", o.status_code))

    # 4) endpoints محمية بلا مصادقة
    protected = ["/me", "/admin/overview", "/stores/00000000-0000-0000-0000-000000000000/products"]
    bad = [p for p in protected if get(p).status_code not in (401, 403, 404)]
    checks.append(_result("auth_required", not bad, f"open_without_token={bad}"))

    # 5) تسجيل/دخول حقيقي
    email = f"dast{uuid.uuid4().hex[:8]}@example.com"
    reg = post("/auth/register", json={"email": email, "password": "StrongPassw0rd!23", "store_name": "DAST Store"})
    login = post("/auth/login", json={"email": email, "password": "StrongPassw0rd!23"})
    checks.append(_result("register_login", reg.status_code == 200 and login.status_code == 200,
                          f"register={reg.status_code} login={login.status_code}"))
    token = login.json().get("access_token") if login.status_code == 200 else None
    store_id = reg.json().get("store_id") if reg.status_code == 200 else None
    auth = {"Authorization": f"Bearer {token}"} if token else {}

    # 6) كوكي الجلسة محمي
    set_cookie = login.headers.get("set-cookie", "")
    cookie_ok = all(flag in set_cookie for flag in ("HttpOnly", "Secure", "SameSite"))
    checks.append(_result("session_cookie_flags", cookie_ok, set_cookie[:120]))

    # 7) IDOR: متجر آخر
    other = post("/auth/register", json={"email": f"o{uuid.uuid4().hex[:8]}@example.com",
                                        "password": "StrongPassw0rd!23", "store_name": "Other"})
    other_store = other.json().get("store_id")
    idor = get(f"/stores/{other_store}/products", headers=auth)
    checks.append(_result("idor_blocked", idor.status_code in (403, 404), f"status={idor.status_code}"))

    # 8) حقن SQL في المسار والاستعلام
    sqli_payloads = ["1' OR '1'='1", "1;DROP TABLE orders;--", "1 UNION SELECT NULL--"]
    sqli_status = []
    for payload in sqli_payloads:
        sqli_status.append(get("/stores/%s/products" % payload, headers=auth).status_code)
    checks.append(_result("sqli_no_5xx", all(s < 500 for s in sqli_status), f"statuses={sqli_status}"))

    # 9) Path traversal
    trav = get("/files/download/..%2f..%2fetc%2fpasswd")
    checks.append(_result("path_traversal_blocked", trav.status_code < 500 and trav.status_code != 200,
                          f"status={trav.status_code}"))

    # 10) طرق غير مسموحة
    trace = c.request("TRACE", "/health")
    checks.append(_result("trace_method_blocked", trace.status_code in (405, 501), f"status={trace.status_code}"))

    # 11) توقيع webhook مزيّف
    wh = post("/webhooks/stripe", content=b'{"id":"evt_x","type":"payment_intent.succeeded"}',
              headers={"stripe-signature": "t=1,v1=deadbeef", "content-type": "application/json"})
    checks.append(_result("webhook_signature_enforced", wh.status_code in (400, 401, 403),
                          f"status={wh.status_code}"))

    # 12) JWT alg=none
    forged = ("eyJhbGciOiJub25lIiwidHlwIjoiSldUIn0."
              "eyJzdWIiOiJhZG1pbiIsInJvbGUiOiJvd25lciIsImlzcyI6Imh0dHBzOi8vdGVzdHNlcnZlciJ9.")
    me = get("/me", headers={"Authorization": f"Bearer {forged}"})
    checks.append(_result("alg_none_rejected", me.status_code == 401, f"status={me.status_code}"))

    # 13) مبالغ سالبة/كوبون أكبر من المبلغ
    neg = post("/orders", headers={**auth, "Idempotency-Key": uuid.uuid4().hex},
               json={"store_id": store_id, "items": [{"product_id": None, "quantity": 1}], "amount_minor": -500})
    checks.append(_result("negative_amount_rejected", neg.status_code in (400, 422), f"status={neg.status_code}"))

    # 14) جسم ضخم
    big = post("/orders", headers={**auth, "Idempotency-Key": uuid.uuid4().hex},
               json={"store_id": store_id, "items": [], "note": "A" * 2_000_000})
    checks.append(_result("oversized_body_rejected", big.status_code in (400, 413, 422),
                          f"status={big.status_code}"))

    # 15) CORS: أصل خارجي لا يحصل على صلاحية
    cors = c.options("/orders", headers={"Origin": "https://evil.example", "Access-Control-Request-Method": "POST"})
    acao = cors.headers.get("access-control-allow-origin")
    checks.append(_result("cors_not_wildcard", acao != "*", f"acao={acao} status={cors.status_code}"))

    # 16) حقن ترويسات في البريد
    hdr = post("/auth/login", json={"email": "a@b.c\r\nBcc: attacker@evil.example", "password": "x" * 12})
    # الرفض مقبول بأي رمز 4xx؛ المهم ألّا يُقبل الطلب ولا تُسرّب الترويسة المحقونة
    checks.append(_result("header_injection_rejected",
                          hdr.status_code < 500 and "attacker@evil.example" not in hdr.text,
                          f"status={hdr.status_code}"))

    # 17) تسريب معلومات في الأخطاء
    checks.append(_result("no_internal_leak", not leaks, f"leaks={leaks[:5]}"))

    # 18) استجابة سريعة بلا تعليق (مهلة)
    t0 = time.perf_counter()
    get("/health")
    checks.append(_result("latency_sane", (time.perf_counter() - t0) < 2.0,
                          f"{(time.perf_counter() - t0) * 1000:.1f}ms"))

    summary = {
        "base": base,
        "checks": checks,
        "passed": sum(1 for x in checks if x["ok"]),
        "failed": [x for x in checks if not x["ok"]],
        "timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
    }
    summary["verdict"] = "PASS" if not summary["failed"] else "FAIL"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({"verdict": summary["verdict"], "passed": summary["passed"],
                      "total": len(checks),
                      "failed": [f"{f['check']}: {f['detail']}" for f in summary["failed"]]}, ensure_ascii=False))
    return summary


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--base", required=True)
    ap.add_argument("--out", required=True)
    a = ap.parse_args()
    res = run(a.base, pathlib.Path(a.out))
    sys.exit(0 if res["verdict"] == "PASS" else 1)
