async (page) => {
 const base='http://127.0.0.1:8123';
 const pages=['home-full','catalog-full','category-full','product-full','cart-full','checkout-full','thankyou-full','account-full','login-full','about-full','contact-full','faq-full','blog-full','landing-full','404-full','maintenance-full','track-full'];
 const sizes=[[320,568],[375,667],[768,1024],[1024,768],[1280,800],[1440,900],[1920,1080]];
 const all=[];
 for(let run=1;run<=3;run++) {
  const results=[];
  for(const [width,height] of sizes) {
   await page.setViewportSize({width,height});
   for(const name of pages) {
    const errors=[]; const http=[];
    const onError=e=>errors.push(e.message); const onConsole=m=>{if(m.type()==='error')errors.push(m.text());};
    const onResponse=r=>{if(r.status()>=400)http.push(r.status()+' '+r.url());};
    page.on('pageerror',onError);page.on('console',onConsole);page.on('response',onResponse);
    await page.goto(`${base}/pages/${name}.html`);
    const state=await page.evaluate(()=>({lang:document.documentElement.lang,h1:!!document.querySelector('h1')?.getBoundingClientRect().height,overflow:Math.max(0,document.documentElement.scrollWidth-innerWidth)}));
    let violations=[];
    if(width===375){await page.addScriptTag({url:`${base}/audit-axe.js`});violations=await page.evaluate(async()=> (await axe.run(document,{runOnly:{type:'tag',values:['wcag2a','wcag2aa','wcag21a','wcag21aa','wcag22aa']}})).violations.map(v=>({id:v.id,impact:v.impact,nodes:v.nodes.map(n=>n.target)})));}
    results.push({name,width,height,...state,errors,http,violations});
    page.off('pageerror',onError);page.off('console',onConsole);page.off('response',onResponse);
   }
  }
  const failures=results.filter(x=>x.lang!=='ar'||!x.h1||x.overflow>1||x.errors.length||x.http.length||x.violations.length);
  const report={run,pages:pages.length,viewports:sizes.length,checks:results.length,failures,verdict:failures.length?'FAIL':'PASS',results};

  all.push(report);
 }
 return all;
}
