"""Build a source/evidence bundle from explicit project roots, never the tool envs."""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import zipfile

ROOT = Path(__file__).resolve().parents[1]
ROOT_FILES = {'.env.example', '.gitignore', '.gitleaks.toml', 'Makefile', 'pyproject.toml',
              'docker-compose.yml', 'docker-compose.prod.yml', 'SBOM.json', 'VERIFY.txt'}
ROOT_DIRS = {'backend', 'frontend', 'docs', 'infra', 'tools', 'tests', 'reports', 'e2e-artifacts'}
EXCLUDED = {'__pycache__', '.pytest_cache', '.mypy_cache', '.ruff_cache', 'node_modules',
            '.git', '.cache', '.local', '.venv', '.venv-semgrep', '.venv-runtime',
            '.playwright-cli', 'build', 'dist', 'coverage', 'htmlcov'}

def selected() -> list[Path]:
    out = []
    for path in ROOT.rglob('*'):
        rel = path.relative_to(ROOT)
        if not path.is_file() or path.is_symlink() or EXCLUDED.intersection(rel.parts):
            continue
        if path.name in {'.coverage', '.env', 'SHA256SUMS'} or path.suffix in {'.pyc', '.zip', '.key', '.pem'}:
            continue
        if len(rel.parts) == 1:
            if path.name not in ROOT_FILES and path.suffix != '.md':
                continue
        elif rel.parts[0] not in ROOT_DIRS:
            continue
        out.append(path)
    return sorted(out)

def stage(destination: Path) -> None:
    if destination.exists():
        shutil.rmtree(destination)
    destination.mkdir(parents=True)
    for path in selected():
        target = destination / path.relative_to(ROOT)
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(path, target)
    entries = sorted(p for p in destination.rglob('*') if p.is_file())
    # A self-describing inventory is outside its own list by design.
    inventory = {'scope': 'Package payload excluding this inventory and SHA256SUMS',
                 'files': [{'path': str(p.relative_to(destination)), 'sha256': hashlib.sha256(p.read_bytes()).hexdigest(),
                            'bytes': p.stat().st_size} for p in entries], 'file_count': len(entries)}
    inv = destination / 'reports/package-inventory.json'
    inv.write_text(json.dumps(inventory, indent=2) + '\n')
    entries = sorted(p for p in destination.rglob('*') if p.is_file())
    sums = ''.join(f'{hashlib.sha256(p.read_bytes()).hexdigest()}  {p.relative_to(destination)}\n' for p in entries)
    (destination / 'SHA256SUMS').write_text(sums)
    print(json.dumps({'staged_files': len(entries) + 1, 'path': str(destination)}))

def archive(source: Path, output: Path) -> None:
    with zipfile.ZipFile(output, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for p in sorted(source.rglob('*')):
            if p.is_file():
                z.write(p, p.relative_to(source))
    print(hashlib.sha256(output.read_bytes()).hexdigest(), output.name)

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--stage', type=Path)
    parser.add_argument('--archive-from', type=Path)
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    if args.stage:
        stage(args.stage)
    if args.archive_from and args.output:
        archive(args.archive_from, args.output)
