# ADR-014 — Financial evidence tiers
Date: 2026-10-20. Status: accepted evidence policy; provider settlement gate OPEN.

Unit arithmetic, real PostgreSQL accounting with HTTP MockTransport, and actual provider Sandbox transfers are three different evidence tiers. Only the last proves financial allocation at the provider. No official provider credentials were supplied and no real payments were made. All pi/tr/re identifiers in regression artifacts come from explicitly injected mocks and are NOT proof of money movement.

Separate Charges & Transfers keeps the platform charge on the platform and creates only the merchant net transfer. Do not also set transfer_data[destination]; it would combine destination-charge allocation with a second merchant transfer (critical regression test added). Platform fee stays processing until separate, appropriate provider balance/settlement evidence is reconciled. Current transfer.paid/status-based test protocol is mock-specific and must not be assumed an official Stripe settlement confirmation. Reconcile supported Stripe events, balance transactions, charge source transaction, available/pending balances, refunds/reversals, dispute liabilities, minimum transfer amounts and fees in official Sandbox before release.

The $70/$2/$68 split passes mocked integration; the mandatory official-Sandbox proof remains NOT MET. A retained platform amount is not an actual transfer to an administrator's bank. No production readiness assertion is authorized by mock success.

Additional correction: the old transport helper enabled MockTransport solely by an environment flag despite its docstring claiming test-only behavior. Startup configuration now rejects this flag in production, staging and development; the helper also guards the cached environment. Three fail-before/pass-after regression cases cover this boundary. Test configuration must never be used for a public deployment.

Distinct event IDs can describe the same transfer: deduplicating only webhook event ID was insufficient and could recognize fee income twice while the ledger still balanced. Lock transfer state and skip already-paid/terminal recognition. Regression `test_distinct_event_ids_for_same_transfer_do_not_rebook_fee` failed before the patch and passes after; it requires identical ledger rows after two distinct confirmations. Real-provider semantics remain unverified.
