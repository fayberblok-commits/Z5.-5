# ADR-013 — Suppress unnecessary server fingerprints
Date: 2026-10-20. Status: accepted.

Disable uvicorn Server header in the Docker command, Compose web command and live audit launcher; remove X-Powered-By in middleware. DAST tests assert absence. This is defense in depth, not a substitute for patching; reverse proxies may reintroduce headers and need separate checks.
