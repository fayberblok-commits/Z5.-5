# ADR-011 — Retention with PostgreSQL transactions
Date: 2026-10-20. Status: accepted.

Replace the sleeping file worker with real sweeps: delete expired/used links, close stale pending scans as error per tenant using RLS context, prune expired revoked JWT identifiers and aged idempotency records. Migration 0002 supplies permissions/indexes. Counts reflect database results; empty sweeps legitimately return zero. tests/integration/test_worker_files.py exercises real PostgreSQL and preservation of live rows. Retention windows require business approval; no external scanner pipeline is implied. See ADR-017 for the subsecond busy-loop correction.
