# ADR-016 — Startup configuration errors without input values
Date: 2026-10-20. Status: accepted.

Pydantic validation messages included rejected secret input; interpolating ValidationError into ConfigError could expose it in startup traces. Enable hide_input_in_errors and raise a generic ConfigError from None. HTTP remains generic 503. Regression tests generate an ephemeral invalid key, assert absence from both exception strings and absence of chained cause. Do not persist invalid inputs in failing-test artifacts; retain only failure names. Direct programmatic ValidationError.errors() can still contain input: operators must never log it.
