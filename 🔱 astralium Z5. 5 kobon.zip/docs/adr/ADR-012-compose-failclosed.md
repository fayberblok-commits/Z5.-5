# ADR-012 — Fail-closed configuration does not certify deployment
Date: 2026-10-20. Status: partial remediation.

Development Compose credentials require explicit environment inputs, without fallback values. Application/worker run non-root/read-only with dropped capabilities; restore docker-default AppArmor rather than unconfined in the production sketch. Remove the non-runnable AI service entrypoint. Configuration example holds empty mandatory secret fields.

Docker is absent: no build/start evidence, no image scan and no effective kernel confinement evidence. Mutable image tags, exposed development data ports, Vault dev mode, missing ClamAV service and WAF routing in the production sketch are open blockers. These files are NOT a production deployment recipe. Do not use source static scans as proof the containers work.
