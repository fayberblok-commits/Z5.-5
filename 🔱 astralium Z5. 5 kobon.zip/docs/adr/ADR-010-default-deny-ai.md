# ADR-010 — AI tool boundary is authorization, not a prompt filter
Date: 2026-10-20. Status: accepted locally; workload isolation pending.

Unknown tools denied. Normalize Unicode/separators before lookup. Sensitive operations require a human role, confirmation and step-up; blocked operations remain blocked. Injection pattern detection is supplementary and cannot guarantee arbitrary prompts harmless. At least 50 adversarial payloads exercised in tests/ai. Provider generation/cost demos are not evidence of production budgets or network isolation; deployment egress and real Tool API enforcement remain open.
