# ADR-009 — Dependency inventory and reproducible constraints
Date: 2026-10-20. Status: accepted, container verification pending.

Pin direct runtime dependencies in backend/requirements.txt; pyproject declares matching versions (Starlette is explicitly pinned in runtime requirements). Replace python-jose/ecdsa with PyJWT 2.15.1 and fixed HS256 verification with required claims. Generate backend/requirements.lock in an isolated runtime virtualenv, not the scanner's environment. Docker install uses those constraints. SBOM.json inventories the resolved Python runtime, not an unbuilt image or its OS packages. Runtime pip check passed. A packaging regression checks direct versions against SBOM; complete image provenance, hashes/signatures and platform-specific lock reproducibility remain release gates.

Semgrep requires older OpenTelemetry than FastAPI; isolate it in a separate venv with its bin directory first in PATH (the wrapper launches pysemgrep via PATH). Do not downgrade application dependencies to satisfy a scanner. Mypy is incremental, not globally strict. Evidence: reports/semgrep_run*.json, runtime-pip-check.txt, test_packaging.py, test_auth_security.py.
