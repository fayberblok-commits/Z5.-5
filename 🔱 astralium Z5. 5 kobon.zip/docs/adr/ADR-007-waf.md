# ADR-007 — WAF و CrowdSec
التاريخ: 2026-10-20
الحالة: مقبول
القرار: ModSecurity + OWASP CRS + CrowdSec كطبقة أمامية، حدود معدل لكل IP/مسار
البدائل: Cloudflare فقط → مرفوض: لا تحكم كامل
