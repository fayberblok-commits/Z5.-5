# ADR-017 — Worker subsecond waits
Date: 2026-10-20. Status: accepted.

`range(int(interval * 10))` rounds intervals below 0.1 seconds to zero, creating a busy loop that never observes a sleep-driven stop signal in tests. Use a monotonic deadline and bounded sleeps. Keep both existing loop tests and their assertions; supply their required real PostgreSQL fixture. The pre-fix test required SIGKILL at 4s (exit 137); seven worker tests pass after patch. Service entrypoint remains single-threaded; OS-level container shutdown and external scheduler integration are not tested.
