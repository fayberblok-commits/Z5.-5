# ADR-018 — Bounded raw input and payment state idempotency
Date: 2026-10-20. Status: implemented locally; official provider integration remains OPEN.

## Findings / root causes
- High: `/files/upload` called Request.body() before authentication, buffering the whole attacker-supplied stream. Chunked bodies bypassed the declared-length check; malformed or extreme Content-Length could produce a 500.
- Critical: `_on_payment_succeeded` always booked sale lines despite an UPDATE matching no rows. Two distinct successful notifications for one payment double-booked a balanced ledger.
- High: stale failure notifications unconditionally downgraded a paid order/payment and platform fee.
- Medium: signed malformed webhook arrays/null/nested shapes raised unhandled exceptions. Invalid signatures also opened database transactions, and the rejected-event insert was rolled back by the raised exception rather than actually persisted.

## Decision
Authenticate uploads before reading; close the DB transaction before awaiting network input; read under an incremental byte cap and a 30s total deadline; reject malformed/ambiguous framing and declared-length mismatch; map overflow to413, timeout408 and disconnect400. Revalidate session/role in the write transaction after reading. This is bounded in-memory buffering, NOT a zero-memory streaming pipeline, and upstream/server chunks may have already been buffered. JSON endpoints outside these raw-body routes still require a global/proxy request-body limit.

Webhook body is capped at1MiB. Reject missing signature before consuming the body and invalid HMAC before JSON/database access. Validate envelope/nested types and identifier lengths before processing. Do not pretend unauthenticated rejected-event content is a trusted audit record. HTTP/server metrics can count these rejections without persisting untrusted payloads or secrets.

Serialize successful payment transitions with a database row lock; perform sale side effects only from pending/processing. Ignore already-finalized success events. Conditionally transition payment failures only from pending/processing; a late failure cannot undo a completed payment. Failed/refunded/disputed recovery requires explicit provider reconciliation, not arbitrary state resurrection by an old event.

## Evidence
`tests/integration/test_round2_redteam.py`: before patches7 failures/2passes for first9 cases; malformed-webhook follow-up6failures/1pass. No tests deleted, assertions unchanged. `tests/test_http_body_limits.py` tests receive-level boundary, no extra reads after overflow, exact limit, framing ambiguity, disconnect, length mismatch and deadline. Related suite61pass after fixes before full gates. Reports in reports/round2/. All provider identifiers come from explicit HTTP mocks; no official Sandbox or real transfer is claimed.

## Not closed
No load proof for thousands of users, global JSON/HTTP server DoS guarantees, real OAuth/onboarding, official settlement/fees/refunds/reversals, real backup/restore, Vault, WebAuthn or file-purchase entitlement. No archive is approved as a final release.
