# ADR-015 — Authenticated private-file redemption
Date: 2026-10-20. Status: accepted (implementation, provider integration unverified).

A presigned S3 URL is a reusable bearer capability until expiry; recording a one-use database token does not constrain that URL. Issue only a relative POST redemption endpoint. Check session, tenant, recipient, expiry, unused state and clean scan status under a row lock; retrieve bounded private bytes before committing consumption. Return attachment/no-store, not a public storage URL or object key. Storage errors return 503 and roll back consumption; network interruption after commit may require a new token (at-most-once, not guaranteed delivery).

Tests: `test_download_does_not_expose_reusable_s3_capability`, `test_download_returns_private_bytes_not_object_key`, `test_object_store_failure_does_not_burn_download_token`; failures before patch retained without inputs in reports/. The old assertion requiring an exposed storage URL was replaced by exact equality to the authenticated path; all prior replay/expiry/tenant rejection assertions remain. This strengthens, not relaxes, file isolation.

Limitations: object-store integration still mocked; product/order entitlement and end-user purchase flows require further audit. Delivery buffers at most configured upload limit plus one byte per concurrent request. Bucket policy must deny public reads. No claim that magic-byte/heuristic filtering proves arbitrary PDFs/images harmless.
