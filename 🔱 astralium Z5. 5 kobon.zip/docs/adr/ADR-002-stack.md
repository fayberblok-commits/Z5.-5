# ADR-002 — اختيار المكدس
التاريخ: 2026-10-20
الحالة: مقبول
## السياق
حاجة لمكدس ناضج، آمن، قابل للتدقيق.
## القرار
Python 3.12 + FastAPI + Pydantic v2 + SQLAlchemy 2، PostgreSQL RLS، Redis، S3، Docker distroless.
## البدائل
- Node/NestJS → أقل نضجًا في التشفير الميداني
- Django → أثقل لمتعدد المستأجرين بلا حالة
## العواقب
- تحقق صارم Pydantic، معاملات ذرية، RLS حقيقي
