> **حزمة التسليم الحالية: `🔱 astralium Z5. 5 kobon.zip` — 2026-10-20.** المصدر الحالي مغلّف للتحميل، وليس إصدارًا معتمدًا للإنتاج. الاختبارات الأخيرة340×3، وDAST18/18×3، وحمل20VUs×20s×3؛ تقاريرها في `reports/final-delivery/`. العوائق O01–O12 ما زالت مفتوحة. هذه الملاحظة تعلو ملاحظات الجولات السابقة عن عدم إنشاء أرشيف، وهي محفوظة كسجل تاريخي.

> **تحديث متابعة 2026-10-20 — مصدر قيد التقوية، وليس تسليمًا نهائيًا.** أُضيف ADR-018 وإصلاحات قراءة الرفع تدريجيًا قبل استهلاك الجسم، والتحقق من Webhook قبل DB، ومنع قيد بيع مكرر بحدثين مختلفين ومنع إخفاق متأخر من إفساد دفعة ناجحة. آخر مجموعة كاملة: **340 اختبارًا ناجحًا ×3**؛ التغطية **88.08%–88.12%**، واختلاف السطر يعود إلى أسماء fuzz العشوائية في المساعد القديم، لا إلى اختلاف نتائج النجاح. بقيت العوائق O01–O12. تقارير الجولة الجديدة في `reports/round2/`؛ تقارير الواجهة والحمل وDAST السابقة تاريخية ولم تُعد في هذه المتابعة. **لم تُنشأ حزمة إطلاق جديدة**؛ الأرشيف السابق نُقل إلى `previous-audit/` ولا يمثل هذا المصدر المعدّل.

### أدلة المتابعة الحالية
- `reports/round2/full_run{1,2,3}.txt`:340 نجاحًا في كل تشغيل؛3warnings معروفة.
- `ruff_run*` و`mypy_run*` و`bandit_run*` و`semgrep_run*` و`gitleaks_run*` و`trivy_run*` و`pipaudit_run*` و`compileall_run*` داخل round2: نجاح×3 ضمن النطاقات المعلنة. Semgrep:201مسارًا، بلا findings/errors. Trivy على snapshot مصدر ثابت وليس image.
- `modified-source.json`: الملفات والأسطر وتجزئات الشيفرة المعدلة. `summary.json` ملخص آلي.
- Playwright/axe/DAST/k6 لم تُعد في هذه المتابعة؛ لا يجوز نسبة أدلة الجولة السابقة لهذه النسخة كقبول إطلاق.
- لا يوجد ZIP نهائي جديد؛ `previous-audit` تاريخي فقط. قرار الجاهزية لم يتغير.

# FINAL-QA-REPORT — Astralium Fibonix Z5.5
**2026-10-20 · حزمة 5.5.0-audit.1 · قرار: جاهز للتطوير فقط؛ غير جاهز للإنتاج أو Staging ببيانات حقيقية.**

## 1. ملخص تنفيذي
أُجريت إصلاحات فعلية في الشيفرة والاختبارات والترحيلات والتغليف، لا مراجعة ورقية فقط. في الجولة السابقة نجح 316 اختبارًا في كل واحدة من ثلاث تشغيلات متتالية آنذاك؛ تحديث الجولة الحالية أعلى التقرير هو المرجع الأحدث، وتغطية الأسطر تقارب 88%. مع ذلك توجد عيوب وعوائق عالية الخطورة مفتوحة، واختبارات ناجحة تثبت نماذج فقط. لم يُنجز كل نطاق الطلب الأصلي. لا يوجد إثبات مالي من مزود Sandbox رسمي؛ لذلك لم يتحقق شرط الجاهزية المالي الإلزامي.

الوثائق السابقة التي وصفت المشروع بأنه مكتمل أو جاهز ملغاة بهذا التقرير. المراجعة من وكيل واحد، وليست شهادة فريق تدقيق خارجي مستقل. لا ادعاء باكتشاف جميع الثغرات الممكنة.

## 2. عدد الملفات ونطاق الفحص والتجزئة
الأرشيف الموجود عند متابعة هذه الجولة: **170 ملفًا** جرى جرد مساراته. SHA-256 قبل استبداله:
`4411a7ee4eed9117cd9fe264c92dabed2c36e083698237c865a023c7148f769e`.
لا يثبت هذا أنه hash الأرشيف الأول قبل كل الجولات السابقة؛ إنه hash المدخل المتاح لهذه المتابعة.

جرد مساحة العمل قبل إتمام الوثائق: **293 ملفًا، 114 ملف Python**، مع الملفات المخفية والامتدادات في reports/workspace-inventory.json؛ لا يشمل بيئات الأدوات والكاش والـ ZIP. الرقم ليس ادعاء قراءة يدوية لكل بايت. عدد ملفات حزمة التسليم النهائي ومساراتها وتجزئاتها في reports/package-inventory.json داخل الأرشيف. أُجري فحص AST/imports ومراجعة وحدات حرجة ومسح ساكن؛ ليست تغطية يدوية متساوية لكل الوظائف.

## 3. الأدوات وإصداراتها
Python 3.13.16؛ pytest 9.0.3؛ pytest-cov 7.1.0؛ ruff 0.17.1؛ mypy 2.4.0؛ bandit 1.9.4؛ semgrep 1.181.0؛ gitleaks 8.30.1؛ pip-audit 2.10.1؛ Trivy 0.76.0؛ k6 2.3.0؛ Playwright CLI 0.1.22/Chromium؛ axe-core 4.10.2؛ PostgreSQL عبر pgembed 0.2.0؛ psycopg 3.3.6. التفاصيل الخام reports/tool-versions.json. Semgrep معزول لتعارض OpenTelemetry مع التطبيق؛ runtime-pip-check في بيئة runtime نظيفة ناجح. هذه ليست إصدارات Docker مثبتة.

## 4. الاختبارات المنفذة وطريقة التكرار
pytest كامل backend/tests مع coverage، ruff app/tests، mypy على 65 source files، bandit app، compileall app/tests، pip-audit runtime، Semgrep source rules وTrivy fs على snapshot مصدر مختار ثابت، كل منها ثلاث مرات متتالية. فحص YAML ومصادر COPY وdeclared imports وSBOM ضمن pytest. Gitleaks على payload مختار ثم على نسخة مستخرجة من الأرشيف (التفاصيل في أدلة الشحن).

PostgreSQL حقيقي مضمّن مع migrations ودور غير مالك وRLS؛ provider HTTP MockTransport؛ S3/scanner بدائل اختبار، واختبار غياب scanner يفشل الرفع بأمان. لا خدمات دفع/بريد/AI حقيقية استُدعيت. Playwright على HTML static؛ 17 صفحة ×7 أحجام ×3، وaxe على عرض375 لكل صفحة ×3؛ negative control كشف العيوب عمدًا ×3. DAST محلي 18 check ×3، وk6 20 مستخدمًا افتراضيًا لمدة20 ثانية ×3 على health/root.

## 5. النتائج والحدود الإحصائية
| المجموعة | النتيجة في التشغيلات الثلاثة | القيد |
|---|---|---|
| pytest + coverage | 316 ناجح في كل تشغيل؛ ~88% أسطر | 3 warnings، ليست branch/endpoint coverage شاملة |
| ruff / mypy | نجاح ×3 | mypy تدريجي؛ untyped bodies ليست كلها strict |
| bandit | لا findings ضمن app ×3 | وجود nosec محدود وموثق؛ ليس إثبات غياب ثغرات |
| pip-audit | لا ثغرات معروفة في المتطلبات وقت الفحص ×3 | يعتمد على قاعدة advisories والنطاق |
| Semgrep | لا findings ×3 في قواعد المصدر المحددة | التقرير يوضح الملفات التي لم تُحلل؛ ليس إثبات أمان |
| Trivy fs | لا vuln/secret/misconfig findings في targets المحللة ×3 | requirements/Dockerfile؛ ليس image/Compose security certification |
| Gitleaks payload/archive | راجع reports/gitleaks_run*.json وarchive-verification.json | نتيجة archive خارجية لتجنب hash دائري؛ لا OCR للصور |
| Playwright/axe | PASS ×3؛ لا violations ضمن tags والنطاق | صفحات ثابتة لا checkout رسمي أو قارئ شاشة |
| DAST | 18/18 ×3 | أداة محلية، ليست ZAP |
| k6 | checks100%، http_req_failed=0؛ p95=36.45/31.03/16.46ms | مسارات health/root وAPP_ENV=test فقط |

تحذيرات pytest: deprecated Starlette/httpx TestClient، XDG_RUNTIME_DIR fallback، datetime.utcnow في backup التجريبي. بقيت مسارات أقل تغطية، منها bootstrap_db 0% من التطبيق المقاس (تشغيله subprocess لا يحسبه coverage الأساسي)، rotate_keys نحو54%، ومسارات أعطال scanner/provider/Redis. لا نعتبر warnings نجاحًا إنتاجيًا.

## 6. سجل العيوب المكتشفة والمعدلة
الجدول التالي يضم 26 مجموعة إصلاح. التفاصيل المادية والأسطر الحالية ليست تعهدًا بإغلاق المتطلبات النظامية المرتبطة بها؛ مثلًا إزالة ID صوري لا تعني اكتمال الدفع. الدليل قبل الإصلاح متوفر صراحة للتراجعات الجديدة فقط؛ لم يُحفظ أثر fail-before لكل إصلاح سابق، ولذلك لا ندعي الالتزام الكامل بتلك القاعدة في التاريخ السابق.

| ID | الخطورة | العيب والسبب الجذري | التغيير الفعلي | اختبار/دليل | الموضع الحالي |
|---|---|---|---|---|---|
| D01 | حرج | قيم سرية/بيئة معبأة ضمن مواد سابقة؛ فصل الأسرار عن الحزمة غير كافٍ | استبعاد .env، نموذج بقيم سرية فارغة، منع defaults وفشل الإعدادات الناقصة | test_settings_have_no_default_secrets؛ gitleaks archive | `.gitignore:1` |
| D02 | عالٍ | عبارة SQL/one غير مكتملة كسرت استيراد التسوية | إصلاح fetchone/one والتحقق من الصف المفقود | pytest المالية + compileall | `backend/app/modules/payments/service.py:502` |
| D03 | عالٍ | استعمال one دون import أدى إلى NameError | إضافة الاستيراد الصحيح | اختبارات API/orders كاملة | `backend/app/main.py:23` |
| D04 | عالٍ | python-jose/ecdsa ضمن شجرة اعتماديات ذات نتائج تدقيق سابقة سلبية | استبدالهما بـ PyJWT 2.15.1 والتحقق المغلق من HS256 والclaims | test_no_vulnerable_jose_dependency؛ alg_none/foreign/expired/tampered؛ pip-audit | `backend/app/core/security.py:8` |
| D05 | متوسط | audit حمل حقل password شكليًا؛ نمط غير آمن قابل للنسخ | حذف الحقل وعدم تسجيل مادة اعتماد | test_register_audit_has_no_credential_material | `backend/app/modules/auth/service.py:82` |
| D06 | عالٍ | COPY كان يشير إلى ملف خارج build context | Dockerfile ينسخ requirements الموجودة | test_dockerfile_copy_sources_exist_and_hardening_present؛ build لم ينفذ | `backend/Dockerfile:14` |
| D07 | عالٍ | اعتماديات الصورة لا تطابق imports/runtime | requirements مثبتة وlock محلول وقيود تثبيت وصلاحية pip runtime | test_every_third_party_import_is_declared؛ runtime-pip-check | `backend/requirements.txt:4` |
| D08 | حرج | Compose التطوير احتوى كلمات مرور/توكنات افتراضية | استبدالها بـ required interpolation دون default | test_compose_has_no_default_credentials؛ prod sketch بقيت به فجوات | `docker-compose.yml:8` |
| D09 | عالٍ | AppArmor معطل بـ unconfined | استعادة docker-default في مسودة الإنتاج | test_prod_compose_does_not_weaken_apparmor؛ فعالية runtime غير مختبرة | `docker-compose.prod.yml:20` |
| D10 | متوسط | عامل الملفات حلقة نوم بلا عمل | صيانة PostgreSQL حقيقية وmigration 0002 | test_run_once_* + tests worker | `backend/app/workers/files.py:66` |
| D11 | عالٍ | أدوات AI غير المعروفة كانت مسموحة، تطبيع الحقن غير كافٍ | default-deny وتطبيع Unicode وحاجز بشري للعمليات الحساسة | tests/ai/test_isolation.py وtest_injection.py | `backend/app/modules/ai/tools.py:52` |
| D12 | منخفض | كشف Server/X-Powered-By | تعطيل ترويسة الخادم في أوامر التشغيل وإزالة fingerprint | DAST header check ×3 | `tools/serve_live.py:94` |
| D13 | حرج | Stripe/PayPal adapters قديمة تصطنع IDs وتوحي بنجاح مالي | إنشاء الدفع القديم يرفع NotImplementedError؛ المسار HTTP منفصل | اختبارات adapters والمال؛ PayPal ما زال غير منفذ | `backend/app/modules/payments/adapters.py:55` |
| D14 | متوسط | اختبار settings تأثر بمتغيرات متبقية؛ flake حقيقي | عزل كل settings keys وmock flag داخل helper | config suite + كامل المجموعة ×3 | `backend/tests/integration/test_config_failclosed.py:39` |
| D15 | منخفض | debug print لجسم webhook في اختبار مالي | إزالة الطباعة | فحص المصدر وتقارير الاختبار المنقحة | `backend/tests/integration/test_money_flow.py:51` |
| D16 | متوسط | وحدة AI service في Compose بلا entrypoint عامل | إزالة الخدمة غير القابلة للتشغيل بدل الادعاء بعزلها | test_every_compose_command_target_is_runnable | `docker-compose.yml:66` |
| D17 | متوسط | تقريب interval الصغير إلى صفر صنع busy-loop | انتظار monotonic bounded؛ الاحتفاظ باختباري الحلقة وربطهما بقاعدة اختبار | pre-fix SIGKILL exit137؛ 7 worker tests ناجحة | `backend/app/workers/files.py:114` |
| D18 | عالٍ | S3 presigned URL يعاد استخدامه رغم استهلاك jti في التطبيق | رابط POST داخلي مصادق عليه؛ bytes فقط؛ قفل/expiry/no-store؛ rollback و503 عند فشل S3 | regressions-before/storage-before ثم tests files بعد الإصلاح | `backend/app/main.py:528` |
| D19 | عالٍ | ValidationError يطبع rejected input وقد يسرب سرًا في startup | hide_input_in_errors وConfigError generic بلا chain | test_configuration_errors_do_not_echo_secret_inputs؛ fail-before محفوظ بلا input | `backend/app/core/config.py:88` |
| D20 | حرج | destination charge كامل ثم تحويل net مستقل قد يدفع للتاجر مرتين | PaymentIntent بلا transfer_destination في مسار Separate Charges & Transfers | test_separate_charges_do_not_also_create_destination_charge؛ fail-before/pass-after | `backend/app/modules/payments/service.py:106` |
| D21 | متوسط | SBOM قديم يختلف عن runtime ويحتوي صورًا غير متحققة | إعادة توليد CycloneDX لاعتماديات runtime المحلولة فقط | test_sbom_matches_direct_runtime_versions؛ lock وpip check | `SBOM.json:2` |
| D22 | متوسط | index احتوى اعتماد وصولية غير مسند وزرًا صوريًا وfavicon مفقودًا | تصنيف demo، إزالة الادعاء واستبدال الزر برابط معاينة وإضافة icon | test_frontend_index_labels_demo_and_has_favicon؛ browser snapshot | `frontend/src/index.html:1` |
| D23 | حرج | MockTransport كان مفعّلًا خارج test بمجرد env flag رغم تعليق يخالف التنفيذ | رفض الإقلاع في production/staging/development مع guard إضافي للنقل | test_mock_payment_transport_rejected_outside_test ×3 حالات fail-before/pass-after | `backend/app/core/config.py:148` |
| D24 | عالٍ | event-id dedupe وحده لا يمنع قيد رسوم مكرر لحدثين مختلفين لنفس التحويل | قفل حالة التحويل وتجاوز paid/terminal قبل fee recognition | test_distinct_event_ids_for_same_transfer_do_not_rebook_fee؛ distinct-event-before/after | `backend/app/modules/payments/service.py:321` |
| D25 | متوسط | وثائق سابقة تصف mock/stub ونتائج قديمة بأنها إطلاق مكتمل | إعادة كتابة الوثائق والجاهزية وتصنيف التنفيذ والعيوب المفتوحة | مطابقة report مع آثار الاختبارات الحالية؛ مراجعة بشرية غير مستقلة | `README.md:3` |

| D26 | متوسط | فحص Trivy تزامن مع compileall فدخل bytecode جديد في التشغيل الثالث وأطلق finding على JWT اختبار عدائي | تثبيت نطاق الفحص إلى payload immutable بلا كاش/تقارير مولدة؛ فحص gitleaks صارم منفصل لكل payload | reports/scan-scope-correction.json؛ Trivy source ×3 وassertions بعد الاستخراج | `tools/package_audit.py` |


### إصلاحات المتابعة (ADR-018)
| ID | الخطورة | السبب | الإصلاح | الدليل |
|---|---|---|---|---|
| R2-01 | عالٍ | الرفع يجمع الجسم قبل المصادقة وبلا حد أثناء الاستقبال | مصادقة قبل القراءة وإعادة تحقق قبل الحفظ، حد تدريجي و30s deadline، وعدم إبقاء معاملة DB أثناء الانتظار | test_anonymous_upload_is_rejected_without_reading_body؛ test_http_body_limits |
| R2-02 | متوسط | Content-Length مشوه أو ضخم يرفع ValueError/500 | فحص decimal/framing وطول النص قبل التحويل، 400/413 بدل500 | test_malformed_or_extreme_upload_length_never_500 |
| R2-03 | حرج | حدثا نجاح مختلفان يعيدان قيد البيع رغم عدم تغير payment | SELECT FOR UPDATE وانتقال مرة واحدة من pending/processing | test_same_payment_two_success_events_do_not_double_book |
| R2-04 | عالٍ | حدث فشل متأخر يخفض حالة دفعة ناجحة ويؤثر في الرسوم | UPDATE شرطي للحالة وعدم تغيير الآثار عند عدم حدوث انتقال | test_stale_payment_failure_does_not_downgrade_success |
| R2-05 | متوسط | جسم Webhook موقّع لكن بنيته null/list يؤدي إلى500 | تحقق envelope/أنواع data.object وأطوال event id/type | test_signed_malformed_webhook_is_400_not_500 |
| R2-06 | متوسط | التوقيع غير الصحيح يفتح DB، ومسار rejected audit السابق لا يُحفظ بسبب rollback | HMAC قبل JSON/DB، جسم محدود1MiB، وعدم ادعاء تسجيل رفض غير موثوق | test_invalid_webhook_signature_does_not_open_database |

قبل التعديل:7فشل/2نجاح ثم6فشل/1نجاح في مجموعة إضافية. بعد التعديل:61 اختبارًا مرتبطًا ناجحًا ثم340×3 للمجموعة كاملة. لا تثبت هذه الإصلاحات حالات مزود الدفع الحقيقية أو قبول آلاف المستخدمين، ولا تعالج أسعار Checkout من كتالوج موثوق أو استحقاقات الشراء أو النسخ الاحتياطي/Vault. حد القراءة هنا خاص بالرفع وWebhook؛ يلزم حد عام عند HTTP/proxy لغيرهما.

## 7. عيوب وعوائق مفتوحة مصنفة
| ID | خطورة | السبب/الحالة | المطلوب قبل الإغلاق |
|---|---|---|---|
| O01 | حرج | لا proof رسمي Sandbox؛ confirmation `transfer.paid`/status في المحاكي ليس إثبات API رسمي؛ transfer لا يساوي bank payout | تصميم/reconciliation رسمي وbalance transactions وwebhooks مدعومة، إثبات المزود مستقلًا |
| O02 | عالٍ | onboarding يقبل acct_ من العميل ويضبط حسابًا دون OAuth/capability verification رسمي | OAuth/Account Links/استرجاع حساب موثّق وربطه بالمتجر |
| O03 | حرج | scripts/backup.py يكتب نصًا ثابتًا وrestore يفحص ملفًا فقط؛ الاختبار ينجح لـ demo | pg_dump مشفر بمفتاح منفصل، استعادة فعلية لقاعدة جديدة، corruption/wrong-key/failure tests |
| O04 | عالٍ | core/vault.py قاموس ذاكرة وليس Vault/Transit | تكامل فعلي workload-auth وrotation وعدم تسرب الأسرار |
| O05 | عالٍ | مساعد files/service.py القديم به scanner صوري وMIME fallback؛ PayPal verification القديم غير رسمي | إزالته/عزله أو تنفيذه واختبار كل مستعمل؛ ليس مسار الرفع الأساسي |
| O06 | عالٍ | WebAuthn غير منفذ cryptographically؛ admin guard القديم يستقبل booleans ويخزن ذاكرة | ceremonies فعلية واختبارات challenge/origin/RP/replay + إدارة منفصلة |
| O07 | عالٍ | Compose مسودات بصور mutable/MinIO untagged، منافذ dev وWAF يمكن تجاوزه، Vault dev، خدمات ناقصة | digests متحققة وشبكات/egress/WAF وتشغيل container integration فعلي |
| O08 | عالٍ | AI/provider/mail/video والوظائف التجارية/GDPR نماذج أو ذاكرة؛ عزل الشبكة/تكلفة موزعة غير مثبتين | فصل workloads وTool API/schema/cost enforcement مستديم وإرسال/توليد Sandbox حقيقي عند الحاجة |
| O09 | عالٍ | ربط استحقاق الملف بطلب مدفوع/مستلم وعملية شراء عامة غير مكتملين؛ الملف قد يسجل بلا order_id | entitlement model واختبارات buyer داخل المتجر نفسه واسترجاع/إلغاء الشراء |
| O10 | عالٍ | refund/dispute/fees/reversal/available balances/minimum amounts مثبتة محليًا لا عند المزود؛ idempotency retention محدود | reconciliation بعد crash، retry بعد نافذة المزود، reverse transfers وسياسات الرسوم |
| O11 | متوسط | اختبار كل دور/مورد/إجراء عبر كل endpoints وشراء UI متصل وHA غير مكتمل | مصفوفة تغطية endpoints وواجهات فعلية متعددة العمليات/المتصفحات |
| O12 | متوسط | صورة Python3.12 غير مبنية، runtime lock محلول على3.13، أدلة fail-before التاريخية جزئية | container build/test وحفظ traces للفشل لكل تعديل لاحق |

حدث اختلاف في فحص Trivy بسبب تولد pyc بالتوازي مع compileall؛ صُنّف كعيب نطاق فحص وأُصلح بإعادة الفحص على snapshot ثابت. التقرير السابق للتشغيل الثالث احتوى finding واحدًا على JWT اختبار لا مفتاح مستخدم؛ لا نعتبره نجاحًا ونتجاهله. راجع scan-scope-correction.json والتشغيلات المعادة.

عدم وجود failing pytest حاليًا لا يغلق O01–O12؛ بعض الاختبارات نفسها تختبر demos فقط.

## 8. الأسباب الجذرية العامة
خلط demo مع تنفيذ تشغيلي، والاعتماد على وثائق بدل مراجعة مسار البيانات، وخلط قيد الدفتر مع تسوية المزود، وخلط event dedupe مع idempotency business action. كذلك تضارب المتطلبات ومصادر إعدادات متعددة، وضبط أمني في التعليقات لا في التنفيذ، وعدم عزل أدوات التدقيق عن runtime. ظهور دفتر متوازن لا يثبت أن التاجر لم يحصل على تحويلين أو أن العمولة وصلت المنصة.

## 9. الإصلاحات وحدود الإغلاق
الإصلاحات مكتوبة فعليًا في الملفات المذكورة. regression tests الخاصة بالملفات والأسرار وmock boundary وdouble payout وdistinct-event fee recognition فشلت قبل التعديل ثم نجحت. worker hang ثبت بمهلة/SIGKILL ثم نجح دون حذف الاختبارين. قيد paid لا يثبت money movement: بوابة المزود تبقى مفتوحة. لم نُبدّل assert ماليًا بفحص أضعف؛ تبدل assert URL التخزين إلى مساواة مسار authenticated بالضبط لأن التصميم السابق سبب الثغرة، مع بقاء assertions replay/expiry/tenant.

## 10. الاختبارات المضافة والأدلة قبل/بعد
راجع tests/ai/test_isolation.py، integration/test_worker_files.py، test_packaging.py، test_stripe_client.py، additions في auth_security/config_failclosed/files_security/money_flow. تقارير before تحتوي أسماء failures فقط دون input secrets: regressions-before، storage-before، double-payout-before، mock-guard-before، packaging-before، distinct-event-before؛ ملفات after والتشغيل الكامل تسند الإصلاح. لا تدل هذه الملفات على سلسلة TDD كاملة للإصلاحات من جولات سابقة.

## 11. الملفات المعدلة والقرارات
جدول D يربط المواضع والأسطر الحالية. `reports/changed-vs-input-archive.json` يقارن الملفات التي كانت موجودة في أرشيف هذه المتابعة؛ لا يمثل diff من بداية المشروع، والملفات الجديدة مدرجة في manifest النهائي. تغيرت main/core/config/security/db/auth/payment/file/worker modules، Docker/Compose/requirements/pyproject، اختبارات ومهاجرة 0002، الأدوات والأدلة والوثائق. ADR-009..017 تسجل pinning وAI deny وworker وCompose وheaders وpayment evidence والتنزيل والتنقيح والانتظار.

## 12. اختبار بيع 70 دولارًا
`test_sale_70_dollars_split_and_settlement` و`test_separate_charges_do_not_also_create_destination_charge`:
| البند | minor units USD | الدليل |
|---|---:|---|
| دفع المشتري | 7000 | أمر/PaymentIntent في MockTransport؛ PostgreSQL دائم خلال الاختبار |
| عمولة المنصة | 200 | platform_fees وقيد credit |
| حصة التاجر | 6800 | merchant_receivable وتحويل mock واحد |
| debit total/credit total | 7000/7000 عند قيد البيع | تحقق ledger فعلي، لا دالة ثابتة |
لا transfer_data[destination] في طلب charge، منعًا لإضافة تخصيص كامل آخر. لا أرقام حسابات أو سر Sandbox حقيقي، ولا ادعاء تحويل فعلي.

## 13. نتيجة عمولة المنصة 2 دولار وسياساتها
تبقى processing بعد successful payment/إنشاء transfer، وتُسجّل paid فقط بحدث تأكيد المحاكي في الاختبار. هذا اختبار state machine لا تأكيد مزود رسمي. منتجات مجانية: لا عمولة/دفع؛ أقل2$: العمولة min(200,gross) وقد يأخذ التاجر0؛ الكوبون يخفض gross. full refund يعيد العمولة وفق السياسة المحلية، partial refund يحتفظ بها، dispute يجمد التسوية. سياسة المزود الفعلية ونزاعاتها/reversal والرسوم لم تُثبت.

## 14. نتيجة حصة التاجر 68 دولارًا
6800 قبل رسوم البوابة في سيناريو gateway_fee=0. عند وجود رسوم بوابة بحسب السياسة المحلية تخصم من حصة التاجر؛ لذلك ليس الوعد68$ دائمًا. سيناريو multi-merchant هو تفكيك إلى أوامر كل متجر وعمولة لكل أمر؛ ليس إثبات atomic multi-merchant checkout رسمي. حساب gateway fees من بيانات مزود معتمدة يحتاج استكمالًا.

## 15. إثبات التسوية في Sandbox — غير متحقق
يوجد سجل settlements وتحويلات في PostgreSQL وطلبات HTTP mock تشبه واجهة Stripe. **لا يوجد إثبات تخصيص أو تحويل عمولة200 من Stripe/PayPal Sandbox رسمي، ولا مرجع transaction رسمي متحقق.** لا تُعد IDs pi_/tr_ التي يصنعها MockTransport أدلة مالية. الشرط الإلزامي في الطلب غير مستوفى. فصل charges/transfers يصحح عيبًا لكنه لا يغلق بروتوكول تأكيد رسوم المنصة. لا اتصال Live أو دفع1$ أو test حقيقي مزعوم.

## 16. إثبات منع التكرار وسلامة الكتابة — نطاق محلي
replayed webhook لا ينشئ transfer ثانيًا؛ مفتاح المزود ثابت لكل order؛ النقر المتكرر/create idempotency واختبار نفس المفتاح تُنفذ. أضيف اختبار أن event IDs مختلفين لنفس transfer لا يضيفان ledger recognition ثانيًا، بقفل حالة التحويل. distinct-event-before أثبت وجود عيب رغم توازن الدفتر ثم الإصلاح منع تكراره. ledger append-only/zero-diff والتحقق من tampering وkill-mid-write تُختبر على PostgreSQL حقيقي. لا ادعاء distributed exactly-once أو خلو حالات crash بين provider/DB خارج نافذة idempotency؛ O10 مفتوحة.

## 17. ما لم يُختبر أو لم يمكن تنفيذه
Docker absent، لذا لم ينجز build/start/image Trivy/hadolint/Compose effective config أو containerized Postgres/Redis/MinIO/Vault/ClamAV. لم تُشغّل ZAP؛ DAST المحلي بديل محدود لا يعادلها. لا official Sandbox credentials/confirmation، ولا بريد/AI حقيقي. لا Redis/MinIO/Vault/ClamAV end-to-end (غياب Docker ليس برهان استحالة كل بديل؛ البدائل لم تُجهز ضمن الجولة). لا حمل ساعة أو multi-replica أو restore فعلي أو kill أثناء provider call أو WebAuthn أو Firefox/WebKit أو تدقيق اختراق مستقل أو OCR شامل للصور. لا قياس شامل timing-enumeration تحت ضجيج شبكي. لا audit كامل للامتثال القانوني/الضرائب/الدول.

## 18. المخاطر المتبقية
O01–O12 تمنع بيانات/أموال حقيقية. يشمل ذلك فقد بيانات لغياب backup حقيقي، تضليل ثقة عند استخدام مساعد demo، نقص entitlement، تأكيد مالي غير مطابق للمزود، bypass WAF، انتحال fingerprint، prompt injection غير المعروف، حدود الذاكرة عند concurrent download، وسلطة DBA على audit. فحص supply chain لحظي لا يضمن عدم ظهور advisories لاحقًا. حذف secrets من المصدر لا يبطلها عند مزود خارجي؛ تدوير أي قيمة كانت مستعملة مسؤولية المالك.

## 19. القيود والافتراضات والتحقق من التسليم
هذه متابعة لأعمال سابقة وبيئة أعيد تهيئتها؛ لا نملك traces لكل fail-before سابق. PostgreSQL embedded حقيقي لكنه مؤقت للاختبار لا نسخة تشغيل دائمة للأعمال. runtime lock وSBOM لبيئة Python محددة، لا OS/container inventory. 3 runs لا تكشف كل flake ممكن؛ fixture نفسها لا تدعم pytest parallel. تصوير واجهات ثابتة لا يثبت integration. لم نضع أسرار حسابات حقيقية؛ قيم fixtures نصوص اختبار أو مولدة وقت التشغيل، ولا يجب نسخها إلى إعدادات فعلية.

أرشيف التسليم يُبنى بقائمة جذور صريحة تستبعد .env/venv/caches/DBs/tool binaries؛ تجزئته الخارجية في Astralium-Fibonix-Z5.5.zip.sha256، وداخل الأرشيف SHA256SUMS لكل payload. المسح بعد فك الأرشيف يُسجّل في reports/archive-verification.json **خارج** الأرشيف لتفادي circular hash. SHA وحده تحقق سلامة نقل لا توقيع مصدر. لا نبني أرشيفًا يحتوي نسخًا قديمة أخرى.

## 20. قرار الجاهزية والمرحلة التالية
**جاهز للتطوير فقط — غير جاهز لـ Staging ببيانات حقيقية، وغير جاهز للإنتاج.** الاختبارات المحلية الحالية ناجحة، لكن المشروع به عيوب مفتوحة معروفة وشروط مالية وتشغيلية جوهرية غير مستوفاة. لا تصح أي عبارة تفيد خلوه من المشاكل المفتوحة.

التالي: اعتماد flow مالي رسمي واختباره ببيانات Sandbox وإثبات allocation/reconciliation، ثم entitlement وbackup/Vault/WebAuthn والعزل والبنية المتكاملة، ثم Docker/ZAP/حمل طويل ومصفوفة endpoints واختبار مستقل. يعاد التحقق ثلاث مرات بعد كل إصلاح وتحدّث هذه الوثيقة؛ لا تُفتح المرحلة الإنتاجية بمجرد نجاح mocks.
